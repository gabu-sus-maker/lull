# Joins src/*.js into src/shell.html -> ../public/index.html (the file Cloudflare serves).
import glob, os
d = os.path.dirname(os.path.abspath(__file__))
shell = open(f'{d}/src/shell.html', encoding='utf-8').read()
js = '\n'.join(open(f, encoding='utf-8').read() for f in sorted(glob.glob(f'{d}/src/*.js')))
out = shell.replace('/*JS*/', js)
open(f'{d}/../public/index.html', 'w', encoding='utf-8').write(out)
print(len(out), 'bytes -> public/index.html')
