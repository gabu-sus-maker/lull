import asyncio
from playwright.async_api import async_playwright
OUT='/tmp/claude-0/-home-claude/080949e3-c506-5252-83b1-2c60697bff54/scratchpad/shots'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome')
        pg=await b.new_page(viewport={'width':1280,'height':720})
        errs=[]
        pg.on('console',lambda m: errs.append(m.type+': '+m.text) if m.type=='error' and 'ERR_TUNNEL' not in m.text else None)
        pg.on('pageerror',lambda e: errs.append('PAGEERR: '+str(e)))
        await pg.goto('file:///home/claude/lull/lull.html')
        await pg.wait_for_timeout(800)
        ev=pg.evaluate
        async def settle(maxn=60,key='e'):
            for i in range(maxn):
                st=await ev("()=>({cut:LULL.G.cut,modal:LULL.G.modal,dlg:!!UI.dlg,ph:LULL.G.phase,st:LULL.G.state})")
                if not st['cut'] and not st['modal'] and not st['dlg']: return st
                if st['dlg'] or st['modal'] in ('phone','note','cu'):
                    await pg.keyboard.press(key)
                await pg.wait_for_timeout(260)
            return await ev("()=>({cut:LULL.G.cut,modal:LULL.G.modal,dlg:!!UI.dlg,ph:LULL.G.phase})")
        async def act(x,y,d,label=None,key='e'):
            await ev(f"()=>{{const P=LULL.P;P.x={x};P.y={y};P.dir={d};P.fx=[0,-1,1,0][{d}];P.fy=[1,0,0,-1][{d}];}}")
            await pg.wait_for_timeout(120)
            t=await ev("()=>{const t=findTarget();return t?t.label:null}")
            await pg.keyboard.press('e')
            await pg.wait_for_timeout(200)
            st=await settle(key=key)
            print(f"  [{label}] target={t} -> phase={st.get('ph')}")
            return t
        await pg.keyboard.press('Enter')
        for i in range(40):
            await pg.wait_for_timeout(300)
            if await ev("()=>LULL.G.phase==='d1_wake'&&!LULL.G.cut&&!UI.dlg"):break
            if await ev("()=>!!UI.dlg"): await pg.keyboard.press('e')
        await pg.screenshot(path=f'{OUT}/f_d1start.png')
        print('phase',await ev("()=>LULL.G.phase"))
        await act(290,82,3,'bowl');await act(312,56,3,'kettle');await act(344,56,3,'radio');await act(226,124,3,'photo')
        await act(216,52,3,'mirror');await act(184,155,3,'phone')
        await act(104,172,0,'door');await pg.wait_for_timeout(2500);await settle()
        await act(664,190,3,'tunde');await act(952,173,3,'station');await pg.wait_for_timeout(5000);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await act(224,212,3,'priya');
        for x in (208,296,392):await act(x,95,3,'rack')
        await act(484,95,3,'micro');await pg.wait_for_timeout(500);await settle()
        await act(224,212,3,'priya2');await act(304,205,3,'dev');await act(344,302,3,'panel');await act(448,262,0,'gary')
        await act(72,222,0,'exit');await pg.wait_for_timeout(5500);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await act(184,155,3,'phone');await act(30,64,3,'bed');await pg.wait_for_timeout(5500);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await pg.wait_for_timeout(1500);await settle()
        await act(528,180,3,'hood');await act(224,212,3,'email');await act(72,222,0,'exit');await pg.wait_for_timeout(5500);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await act(392,190,3,'okafor');await act(496,522,3,'jogger');await pg.screenshot(path=f'{OUT}/f_police.png')
        await act(152,173,3,'home');await pg.wait_for_timeout(5500);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await pg.wait_for_timeout(1000);await settle()
        await act(320,118,3,'biscuit');await settle();await pg.wait_for_timeout(6000)
        print('ringing',await ev("()=>LULL.G.flags.ringing"))
        await act(184,155,3,'phone/ellie');await act(216,52,3,'mirror3');await act(226,124,3,'photo3')
        await act(104,172,0,'door');await pg.wait_for_timeout(2500);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await pg.screenshot(path=f'{OUT}/f_d3street.png')
        await act(664,190,3,'okafor3');await act(680,173,3,'shopdoor');await pg.wait_for_timeout(2500);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await act(200,150,3,'tunde3');await act(216,112,2,'water');await act(152,134,3,'okafor');
        await act(120,166,0,'leave');await pg.wait_for_timeout(2500);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await act(152,173,3,'home');await pg.wait_for_timeout(2500);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await act(30,64,3,'bed');await pg.wait_for_timeout(8000);await settle()
        print('phase',await ev("()=>LULL.G.phase"),await ev("()=>JSON.stringify(LULL.G.stats)"))
        await pg.screenshot(path=f'{OUT}/f_a1.png')
        await act(360,56,3,'drawer');await act(46,170,1,'toolbox');await act(312,108,3,'notes')
        await act(104,172,0,'door');await pg.wait_for_timeout(2500);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await act(680,173,3,'shopdoor');await pg.wait_for_timeout(2500);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await act(192,160,3,'water');await act(200,66,3,'rest');await pg.wait_for_timeout(9000)
        print('final state',await ev("()=>LULL.G.state"))
        await pg.screenshot(path=f'{OUT}/f_end.png')
        print('flags',await ev("()=>Object.keys(LULL.G.flags).filter(k=>k.startsWith('clue')).join(',')"))
        print('notes',await ev("()=>LULL.G.notes.length"))
        print('\n'.join(errs[:30]))
        await b.close()
asyncio.run(main())
