import asyncio,sys,json
from playwright.async_api import async_playwright
D='/tmp/claude-0/-home-claude/080949e3-c506-5252-83b1-2c60697bff54/scratchpad/shots/'
PATH=sys.argv[1] if len(sys.argv)>1 else 'A'   # A: refuse sharing, leave Farrow, leave Theo. B: share everything, free Farrow, take Theo
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome')
        pg=await b.new_page(viewport={'width':1280,'height':720})
        errs=[]
        pg.on('console',lambda m: errs.append(m.type+': '+m.text) if m.type=='error' and 'ERR_TUNNEL' not in m.text else None)
        pg.on('pageerror',lambda e: errs.append('PAGEERR: '+str(e)))
        await pg.goto('file:///home/claude/lull/lull.html');await pg.wait_for_timeout(800)
        ev=pg.evaluate
        choices=[]
        async def settle(maxn=80):
            for i in range(maxn):
                st=await ev("()=>({cut:LULL.G.cut,modal:LULL.G.modal,dlg:!!UI.dlg,ch:!!(UI.dlg&&UI.dlg.choices),txt:UI.dlg?UI.dlg.text:'',ph:LULL.G.phase,st:LULL.G.state,opts:UI.dlg&&UI.dlg.choices})")
                if not st['cut'] and not st['modal'] and not st['dlg']: return st
                if st['ch'] and choices:
                    await ev("()=>{const D=UI.dlg;D.shown=D.text.length;}")
                    await pg.wait_for_timeout(60)
                    c=choices.pop(0);print('     choose',c,'of',st['opts'])
                    await pg.keyboard.press('Digit'+str(c+1))
                elif st['dlg'] or st['modal'] in ('phone','note','cu'):
                    await pg.keyboard.press('e')
                await pg.wait_for_timeout(200)
            return await ev("()=>({cut:LULL.G.cut,modal:LULL.G.modal,dlg:!!UI.dlg,ph:LULL.G.phase,txt:UI.dlg?UI.dlg.text:''})")
        async def act(x,y,d,label,ch=None):
            nonlocal choices
            choices=list(ch or [])
            await ev(f"()=>{{const P=LULL.P;P.x={x};P.y={y};P.dir={d};P.fx=[0,-1,1,0][{d}];P.fy=[1,0,0,-1][{d}];LULL.G.stats.health=100;}}")
            await pg.wait_for_timeout(150)
            t=await ev("()=>{const t=findTarget();return t?t.label:null}")
            await pg.keyboard.press('e');await pg.wait_for_timeout(250)
            st=await settle()
            print(f"  [{label}] target={t} -> {st.get('ph')} {('LEFT:'+str(choices)) if choices else ''}")
            return t
        async def hold(key,ms):
            await pg.keyboard.down(key);await pg.wait_for_timeout(ms);await pg.keyboard.up(key)
        A=PATH=='A'
        # start from a1_shop with rest done -> sleep
        await ev("()=>{document.querySelector('#title').classList.add('hidden');LULL.Snd.stopSong();const G=LULL.G;G.state='play';G.flags.entered_a1_shop=1;G.sanityOn=true;G.showHum=true;G.lullAllowed=true;G.flags.canFight=true;G.flags.restA1=1;G.flags.torch=1;G.flags.crowbar=1;giveItem('torch');giveItem('crowbar');giveItem('water',2);LULL.P.battery=90;LULL.loadPhase('a1_shop',{});document.querySelector('#fade').style.opacity=0;}")
        await pg.wait_for_timeout(400)
        await act(200,80,3,'bedroll/sleep',[0]);await pg.wait_for_timeout(5000);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await act(120,166,0,'leave shop');await pg.wait_for_timeout(2200);await settle()
        await act(152,173,3,'home');await pg.wait_for_timeout(2200);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await act(226,124,3,'photo');await act(110,175,2,'paper');
        await act(104,172,0,'door');await pg.wait_for_timeout(2200);await settle()
        await act(10,505,1,'towpath west');await pg.wait_for_timeout(2200);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await pg.screenshot(path=D+'f2_canal.png')
        await act(1064,290,3,'kingfisher');await act(1474,290,3,'duchess')
        # wardens zone
        await ev("()=>{const P=LULL.P;P.x=360;P.y=330;}");await pg.wait_for_timeout(400);await settle()
        await act(296,340,3,'farrow',[0,2] if A else [0,0]);
        await pg.screenshot(path=D+'f2_farrow.png')
        await act(328,104,3,'station gate (no cutters)')
        # hospital: clear hollows for flow
        await ev("()=>{Object.assign(LULL.G.flags,{hb1:1,hb2:1,hb3:1});}")
        await act(900,104,3,'hospital gate');await pg.wait_for_timeout(2200);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await pg.screenshot(path=D+'f2_hosp.png')
        await act(176,32,3,'noticeboard')
        await act(40,222,3,'stairs down');await pg.wait_for_timeout(500)
        await act(104,430,3,'cutters')
        # loop corridor test
        await ev("()=>{const P=LULL.P;P.x=tx(25);P.y=ty(20)+4;P.dir=2;P.fx=1;P.fy=0;}")
        await hold('d',2200);await settle()
        print('  loops',await ev("()=>LULL.G.loopN"),'x',await ev("()=>Math.round(LULL.P.x)"))
        await hold('d',8000);await settle()
        await pg.screenshot(path=D+'f2_loop.png')
        print('  loops',await ev("()=>LULL.G.loopN"))
        await hold('a',3200);await pg.wait_for_timeout(400);await settle()
        print('  solved',await ev("()=>LULL.G.flags.loopSolved"),'pos',await ev("()=>[Math.round(LULL.P.x),Math.round(LULL.P.y)]"))
        await act(488,477,3,'insulin')
        await act(34,338,1,'stairs up');await pg.wait_for_timeout(500)
        await act(280,164,3,'mara (insulin)');await pg.wait_for_timeout(6000);await settle()
        await act(216,196,3,'theo 1');await act(216,196,3,'theo water',[1] if A else [0])
        await act(296,168,3,'halloran tea',[1] if A else [0])
        await act(88,250,3,'rest bench');await pg.wait_for_timeout(1500);await settle()
        await pg.screenshot(path=D+'f2_hosp2.png')
        await act(136,238,0,'leave hosp',[1] if A else [0]);await pg.wait_for_timeout(2200);await settle()
        print('phase',await ev("()=>LULL.G.phase"),'theoWith',await ev("()=>LULL.G.flags.theoWith"))
        await pg.screenshot(path=D+'f2_canal_night.png')
        await act(296,340,3,'cage at night')
        await act(328,104,3,'cut chain',[0]);await act(328,104,3,'enter station');await pg.wait_for_timeout(2200);await settle()
        print('phase',await ev("()=>LULL.G.phase"))
        await act(424,212,3,'tunnel radio')
        # traverse the tunnel westwards on foot (hollows removed)
        await ev("()=>{const G=LULL.G;G.map.ents=G.map.ents.filter(e=>e.kind!=='hollow');const P=LULL.P;P.x=tx(100);P.y=148;}")
        await hold('a',9000)
        x1=await ev("()=>Math.round(LULL.P.x)");print('  walked to x',x1,'(train east end',85*16,', west end',36*16,')')
        await pg.screenshot(path=D+'f2_tunnel.png')
        await hold('a',8000)
        print('  walked to x',await ev("()=>Math.round(LULL.P.x)"))
        await act(34,72,1,'bethnal green');await pg.wait_for_timeout(9000)
        print('final',await ev("()=>LULL.G.state"))
        print('flags',await ev("()=>JSON.stringify(Object.fromEntries(Object.entries(LULL.G.flags).filter(([k])=>k.startsWith('inf_')||k.startsWith('clue')||k.startsWith('theo')||k.startsWith('farrow'))))"))
        print('stats',await ev("()=>JSON.stringify(LULL.G.stats)"))
        print('\n'.join(errs[:20]))
        await b.close()
asyncio.run(main())
