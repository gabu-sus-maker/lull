import asyncio,sys,json
from playwright.async_api import async_playwright
D='/tmp/claude-0/-home-claude/080949e3-c506-5252-83b1-2c60697bff54/scratchpad/shots/'
MODE=sys.argv[1] if len(sys.argv)>1 else 'full'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome')
        pg=await b.new_page(viewport={'width':1280,'height':720})
        errs=[]
        pg.on('console',lambda m: errs.append(m.type+': '+m.text) if m.type=='error' and 'ERR_TUNNEL' not in m.text else None)
        pg.on('pageerror',lambda e: errs.append('PAGEERR: '+str(e)))
        await pg.goto('file:///home/claude/lull/lull.html');await pg.wait_for_timeout(800)
        ev=pg.evaluate
        choices=[];shot_rc=[0]
        async def settle(maxn=140):
            for i in range(maxn):
                st=await ev("()=>({cut:LULL.G.cut,modal:LULL.G.modal,dlg:!!UI.dlg,ch:!!(UI.dlg&&UI.dlg.choices),ph:LULL.G.phase,st:LULL.G.state,opts:UI.dlg&&UI.dlg.choices,txt:UI.dlg&&UI.dlg.text})")
                if st['modal']=='end': return st
                if not st['cut'] and not st['modal'] and not st['dlg']: return st
                if st['ch']:
                    await ev("()=>{const D=UI.dlg;D.shown=D.text.length;}");await pg.wait_for_timeout(60)
                    c=choices.pop(0) if choices else 0
                    while isinstance(c,str):
                        idx=next((k for k,o in enumerate(st['opts']) if c.lower() in o.lower()),None)
                        if idx is not None: c=idx;break
                        print('     (skip answer not offered:',c,')')
                        c=choices.pop(0) if choices else 0
                    print('     choose',c,'of',[o[:40] for o in st['opts']])
                    await pg.keyboard.press('Digit'+str(c+1))
                elif st['modal']=='recount' and not shot_rc[0]:
                    shot_rc[0]=1;await pg.wait_for_timeout(9000);await pg.screenshot(path=D+'f3_recount_'+MODE+'.png');await pg.keyboard.press('e')
                elif st['dlg'] or st['modal'] in ('phone','note','cu','recount'):
                    await pg.keyboard.press('e')
                await pg.wait_for_timeout(170)
            return await ev("()=>({cut:LULL.G.cut,modal:LULL.G.modal,dlg:!!UI.dlg,ph:LULL.G.phase,txt:UI.dlg?UI.dlg.text:''})")
        async def act(x,y,d,label,ch=None):
            nonlocal choices
            choices=list(ch or [])
            await ev(f"()=>{{const P=LULL.P;P.x={x};P.y={y};P.dir={d};P.fx=[0,-1,1,0][{d}];P.fy=[1,0,0,-1][{d}];LULL.G.stats.health=100;}}")
            await pg.wait_for_timeout(150)
            t=await ev("()=>{const t=findTarget();return t?t.label:null}")
            await pg.keyboard.press('e');await pg.wait_for_timeout(250)
            st=await settle()
            print(f"  [{label}] target={t} -> {st.get('ph')} {('LEFT:'+str(choices)) if choices else ''}")
            return t
        async def hold(key,ms):
            await pg.keyboard.down(key);await pg.wait_for_timeout(ms);await pg.keyboard.up(key)
        async def phase(): return await ev("()=>LULL.G.phase")
        # ---- base state: end of the Stage 2 tunnel
        base=dict(theo=True,infTheo=False,realVoice=('river' in MODE or 'tm' in MODE),hum=60)
        if 'tm' in MODE: base['hum']=92
        if 'deadtheo' in MODE: base['infTheo']=True
        await ev(f"""()=>{{document.querySelector('#title').classList.add('hidden');LULL.Snd.stopSong();const G=LULL.G;G.state='play';
          Object.assign(G.flags,{{canFight:1,torch:1,crowbar:1,restA1:1,maraMet:1,lena:0,farrowLeft:1,theoWater:{1 if base['infTheo'] else 0},inf_theo:{1 if base['infTheo'] else 0},theoWith:1,hTea:0,kills:3,clue_idcard:1,clue_ring:1,clue_notes:1,entered_a2_tunnel:1}});
          G.sanityOn=true;G.showHum=true;G.lullAllowed=true;G.stats={{health:90,hunger:70,thirst:70,sanity:70,hum:{base['hum']}}};
          giveItem('torch');giveItem('crowbar');giveItem('water',2);giveItem('cordial',1);LULL.P.battery=99;
          LULL.loadPhase('a2_tunnel',{{pos:[tx(3),ty(4)],dir:1}});document.querySelector('#fade').style.opacity=0;}}""")
        await pg.wait_for_timeout(500)
        await act(34,72,1,'bethnal green exit');await pg.wait_for_timeout(6000);await settle()
        print('phase',await phase(),'theo dead?',await ev("()=>!!LULL.G.flags.theoDead"))
        await pg.screenshot(path=D+'f3_platform.png')
        await act(34,72,1,'up to street');await pg.wait_for_timeout(2200);await settle()
        print('phase',await phase())
        # city: flower seller, pub, Poppy, rest
        await act(43*16+8,9*16+16+14,3,'flower seller')
        await ev("()=>{const P=LULL.P;P.x=17*16+8;P.y=14*16+14;}");await pg.wait_for_timeout(500);await settle()
        await act(21*16+8,12*16+16+6+16,3,'poppy',['ask your dad' if 'river' in MODE else 0])
        await act(20*16+8,13*16+16+6+14,3,'pub rest');await pg.wait_for_timeout(1500);await settle()
        await act(0*16+10,20*16+8,1,'west (blocked)')
        await act(73*16+8,16*16+10,3,'ellie building');await pg.wait_for_timeout(2200);await settle()
        print('phase',await phase())
        # ellie's flat
        await act(40,166,3,'answerphone',['play it'] if base['realVoice'] else ['skip'])
        await ev("()=>{const P=LULL.P;P.x=4*16+8;P.y=5*16+12;}");await pg.wait_for_timeout(500);await settle()
        await act(36,66,3,'bed note')
        await act(330,104,3,'letter')
        await act(216,52,3,'mirror')
        await act(272,58,3,'fridge photo')
        await pg.wait_for_timeout(3500)
        await pg.screenshot(path=D+'f3_ellie_morph.png')
        print('  flags',await ev("()=>JSON.stringify({kg:LULL.G.flags.knowsGate,kr:LULL.G.flags.knowsRiver,rv:LULL.G.flags.realVoice,em:[LULL.G.flags.em1,LULL.G.flags.em2,LULL.G.flags.em3]})"))
        await act(11*16+8,11*16+14,0,'leave flat');await pg.wait_for_timeout(2200);await settle()
        await act(10,20*16+8,1,'west');await pg.wait_for_timeout(5000);await settle()
        print('phase',await phase())
        # approach: walk west in steps, check the crowd
        for x in [110,98,86,74,62,50,40]:
            await ev(f"()=>{{const P=LULL.P;P.x=tx({x});P.y=ty(15);P.dir=1;P.fx=-1;P.fy=0;}}")
            await hold('a',1500)
        await ev("()=>{const P=LULL.P;P.x=tx(40);P.y=ty(15);P.dir=1;P.fx=-1;P.fy=0;}");await pg.wait_for_timeout(4000)
        n=await ev("()=>LULL.G.map.ents.filter(e=>e.kind==='calm').length")
        print('  calm distances:',await ev("()=>LULL.G.map.ents.filter(e=>e.kind==='calm').map(e=>Math.round(Math.hypot(e.x-LULL.P.x,e.y-LULL.P.y)))"))
        frozen=await ev("()=>{LULL.P.fx=1;LULL.P.fy=0;LULL.P.dir=2;return new Promise(r=>setTimeout(()=>r(LULL.G.map.ents.filter(e=>e.kind==='calm').map(e=>e.frozen).filter(Boolean).length),300));}")
        print('  calm following:',n,'frozen when faced:',frozen)
        await pg.screenshot(path=D+'f3_crowd.png')
        await ev("()=>{const P=LULL.P;P.x=tx(20);P.y=ty(12);P.dir=3;P.fx=0;P.fy=-1;}");await pg.wait_for_timeout(600);await settle()
        print('  at plaza; hold:',await ev("()=>JSON.stringify(LULL.G.crowdHold)"))
        await pg.wait_for_timeout(3000)
        await pg.screenshot(path=D+'f3_plaza.png')
        # gate
        end={'delivery':['ellie hale',0,'keep him','another way in'],'wall':['ellie hale',0,'send theo','go on','never open'],'river':['ellie hale','something','send theo','go on','doing the talking','the river'],'tm':['ellie hale','something','keep him','doing the talking','stay with me']}
        key=next(k for k in end if k in MODE)
        await act(tx(17)+6,ty(8)+20,3,'intercom',end[key])
        await pg.screenshot(path=D+f'f3_gate_{key}.png')
        st=await ev("()=>LULL.G.phase");print('after gate:',st,await ev("()=>LULL.G.flags.ending"))
        if key=='delivery':
            await ev("()=>{const P=LULL.P;P.x=tx(2);P.y=ty(17)+6;P.dir=0;P.fx=0;P.fy=1;}")
            await hold('s',600);await pg.wait_for_timeout(2500);await settle()
            await pg.wait_for_timeout(2000);await pg.screenshot(path=D+'f3_delivery.png')
            await settle(300)
        if key=='river':
            await pg.wait_for_timeout(4000);await settle()
            await pg.screenshot(path=D+'f3_river_start.png')
            t0=0
            print('  phase now',await phase(),'y',await ev("()=>Math.round(LULL.P.y)"))
            for i in range(60):
                await hold('s',2000);t0+=2
                if await ev("()=>!!UI.dlg"):await settle()
                y=await ev("()=>Math.round(LULL.P.y)")
                if i%5==0:print('    t',t0,'y',y,'prog',await ev("()=>(LULL.G.riverProg||0).toFixed(2)"))
                if await ev("()=>!!LULL.G.flags.riverIn"):break
            print('  reached the water after ~',t0,'s, y=',y)
            await pg.screenshot(path=D+'f3_river_end.png')
            await settle(300)
        if key=='tm':
            await pg.wait_for_timeout(4000);await settle(300)
        if key=='wall':
            await settle(300)
        await pg.wait_for_timeout(1500)
        await pg.screenshot(path=D+f'f3_end_{key}.png')
        print('FINAL modal',await ev("()=>LULL.G.modal"),'endings',await ev("()=>localStorage.getItem('lull_endings')"),'save phase',await ev("()=>JSON.parse(localStorage.getItem('lull_save')||'{}').phase"))
        print('\n'.join(errs[:20]))
        await b.close()
def tx(t): return t*16+8
def ty(t): return t*16+16
asyncio.run(main())
