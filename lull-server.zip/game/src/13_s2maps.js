// ================= STAGE 2 MAPS =================
function theoFollower(m,x,y){if(!G.flags.theoWith)return;const t=npc(m,x,y,'theo',{follow:1,scale:.8,speed:46,solid:false,ghost:1,clean:G.flags.inf_theo?0:1,interact:I('Theo',S.theoTalk)});G.theo=t;}
// ---------------- CANAL ----------------
function buildCanal(){
 const m=new GMap('canal',110,26,T.grass);m.outdoor=true;
 const night=!!G.flags.hospDone,f=G.flags;
 m.rect(0,0,110,4,T.roof);
 const r=RNG(77);
 for(let x=0;x<110;x++){m.set(x,4,r()<.5?T.brickWin:T.brick);m.set(x,5,r()<.3?T.brickWin:(r()<.3?T.shutter:T.brick));}
 for(let x=52;x<=61;x++){m.set(x,4,x%2?T.brickWinY:T.brickY);m.set(x,5,x%3?T.brickWinY:T.brickY);}
 m.set(56,5,T.gateIron);m.set(57,5,T.gateIron);
 for(let x=17;x<=23;x++){m.set(x,4,T.stationF);m.set(x,5,T.stationF);}
 m.set(20,5,f.gateCut?T.stationIn:T.stationGate);
 m.rect(0,6,110,3,T.pave);
 for(let x=0;x<110;x++)m.set(x,9,T.fenceP);
 m.rect(0,10,110,2,T.grass);
 m.rect(0,12,110,1,T.copingT);m.rect(0,13,110,4,T.water);m.rect(0,17,110,1,T.coping);
 m.rect(0,18,110,2,T.gravel);m.rect(0,20,110,2,T.grass);m.rect(0,22,110,4,T.hedge);
 for(const bx of [30,80]){m.rect(bx,9,2,1,T.pave);m.rect(bx,10,2,2,T.gravel);m.rect(bx,12,2,6,T.deck);}
 // Wardens' lock + barricade
 m.rect(10,13,2,4,T.lockBeam);m.rect(9,12,1,6,T.lockWall);m.rect(12,12,1,6,T.lockWall);
 for(let y=6;y<=21;y++){if(y>=13&&y<=16)continue;m.set(14,y,T.barTile);}
 // ambience
 m.ambient=night?{a:.9,c:'4,5,12'}:{a:.58,c:'16,18,24'};m.rain=night?.5:.3;m.fog=.08;
 m.snd={rain:m.rain*.5,wind:.1,drone:night?.12:.06};
 if(!night)m.grade={c:'rgba(120,130,140,.32)',op:'saturation'};
 // lamps
 const lamp=(x,y,flk)=>{const on=night&&flk!==false;m.prop('lamp',x,y,{on});if(on){const L=m.lights[m.lights.length-1];if(flk)L.flick=.8;}};
 [26,44,66,88,102].forEach((t,i)=>lamp(tx(t),ty(8)-2,i%2?true:false));
 [20,40,64,90,104].forEach((t,i)=>lamp(tx(t),ty(20)-2,i===1||i===3?true:false));
 [[36,11],[48,11],[74,11],[94,11],[26,21],[50,21],[68,21],[98,21]].forEach(([x,y])=>m.prop('tree',tx(x),ty(y)));
 m.prop('bench',tx(40),ty(7)-2);m.prop('bench',tx(70),ty(7)-2);
 // boats
 m.prop('boat',tx(92),ty(16)-2,{c:1,dirty:1,interact:I('Narrowboat “Duchess”',S.boatDuchess)});
 m.prop('boat',tx(66),ty(16)-2,{c:0,interact:I(()=>f.kingfisher?'Narrowboat “Kingfisher”':'Search the narrowboat',S.boatKingfisher)});
 m.prop('boat',tx(42),ty(16)-2,{c:2,dirty:1,interact:I('Narrowboat “Wren”',S.boatWren)});
 m.prop('boat',tx(5),ty(16)-2,{c:3});
 // Wardens' camp (west of the barricade)
 m.prop('tent',tx(3),ty(19),{c:'#4a5a3a'});m.prop('tent',tx(6),ty(8),{c:'#5a4a3a'});m.prop('tent',tx(2),ty(8),{c:'#3a4a5a'});
 m.prop('jerry',tx(7),ty(19)+2);m.prop('boxes',tx(5),ty(21));m.prop('pallets',tx(15),ty(18)+4);m.prop('pallets',tx(15),ty(7)+4);
 const brazOn=!(night&&f.farrowFree);
 m.prop('brazier',tx(9),ty(19)+4);if(brazOn){m.light(tx(9),ty(19),88,.85,'255,140,60',{flick:.25,gk:1.6});m.emitters.push({x:tx(9),y:ty(19)-8,w:4});}
 if(!night||!f.farrowFree){
  npc(m,tx(12)+4,ty(18)+12,'cole',{fixedDir:2,clean:1,interact:I('Cole',S.cole)});
  npc(m,tx(12),ty(7),'jas',{fixedDir:2,clean:1,interact:I('Warden',S.jas),barks:['Don’t come any closer.','He said stay back.'],barkR:70});
  npc(m,tx(8),ty(18)+10,'warden3',{fixedDir:2,clean:1});
 }else{
  npc(m,tx(12)+4,ty(18)+12,'jas',{fixedDir:2,smile:true,infected:1,interact:I('Warden',S.jasNight)});
  m.ents.push(new Sleeper(tx(6),ty(19)+4,'cole',{pose:'lie',smile:true,interact:I('Cole',S.sleeperGeneric)}));
 }
 // the cage
 const caged=!f.farrowFree;
 m.prop('cage',tx(18),ty(19)+2,{v:caged?'':'open',interact:I(caged?'The cage':'The open cage',S.farrow)});
 if(caged){if(night)m.ents.push(new Sleeper(tx(18),ty(19)-2,'farrow',{pose:'lie',smile:true,interact:I('Farrow',S.farrowDead)}));
  else npc(m,tx(18),ty(19)-2,'farrow',{fixedDir:0,smile:true,infected:1,interact:I('The man in the cage',S.farrow)});}
 // sleepers
 m.ents.push(new Sleeper(tx(40),ty(7)-1,'p1',{pose:'sit',smile:true,dir:0,interact:I('Someone on the bench',S.sleeperGeneric)}));
 m.ents.push(new Sleeper(tx(58),ty(19)-2,'p3',{pose:'lie',smile:true,interact:I('Someone on the towpath',S.sleeperGeneric)}));
 m.ents.push(new Sleeper(tx(98),ty(7),'p5',{pose:'lie',smile:true,interact:I('Someone on the path',S.sleeperGeneric)}));
 // Hollowed
 const H=(x,y,flag,o)=>{if(!f[flag])m.ents.push(new Hollow(x,y,Object.assign({flag},o)));};
 H(tx(86),ty(19),'hc1',{guard:80,drop:{item:'ring',flag:'pk_ring'},truth:'t3',lines:['Get back!','Please — my wife, she’s asleep in there—','STAY AWAY!']});
 H(tx(70),ty(7),'hc2',{guard:80,drop:{item:'filter',flag:'pk_filter'},truth:'t1'});
 H(tx(46),ty(19),'hc3',{guard:70,truth:'t2'});
 H(tx(25),ty(7),'hc4',{guard:70,drop:{item:'bar',flag:'pk_bar1'},truth:'p4'});
 H(tx(28),ty(8),'hc5',{guard:70,truth:'t1'});
 // pickups
 const PK=(x,y,it,flag)=>{if(!f[flag])m.ents.push(new Pickup(x,y,it,1,{flag}));};
 PK(tx(100),ty(21),'water','pk_cw1');PK(tx(60),ty(8),'bandage','pk_cband');PK(tx(34),ty(19),'batt','pk_cbatt');PK(tx(72),ty(21),'crisps','pk_ccr');
 // exits / zones
 m.exit(109,18,'Back towards Bow',S.canalEast);m.exit(109,19,'Back towards Bow',S.canalEast);
 m.exit(56,5,'Mile End Hospital',S.hospEnter);m.exit(57,5,'Mile End Hospital',S.hospEnter);
 m.exit(20,5,f.gateCut?'Down into Mile End station':'Mile End station',S.stationGate);
 m.zone(tx(15),ty(6),tx(23)-tx(15),ty(22)-ty(6),S.wardensMeet);
 m.zone(tx(52),ty(6),tx(62)-tx(52),ty(3),()=>{if(!f.hospSeen){f.hospSeen=1;murmur('Mile End Hospital. Someone has painted on the gate: WE ARE CLEAN. KEEP OUT.');}});
 theoFollower(m,P.x+10,P.y);
 m.finalize();return m;
}
// ---------------- HOSPITAL ----------------
function buildHospital(){
 const m=new GMap('hosp',36,34,T.void);
 const rows=[
 'WWWNNWWWWWNNWWWWWWWNNWWWWNNWWWWNNWWW'];
 for(let j=1;j<=14;j++)rows.push('W'+'h'.repeat(16)+((j===7||j===8)?'d':'W')+'h'.repeat(17)+'W');
 rows.push('WWWWWWWWEWWWWWWWWWWWWWWWWWWWWWWWWWWW');
 rows.push(' '.repeat(36));
 rows.push('B'.repeat(36));rows.push('B'.repeat(36));
 for(let j=19;j<=21;j++)rows.push('B'+(j===20?'U':'c')+'c'.repeat(33)+'B');
 rows.push('BBBBBBBDBBBBBBBBBBBDBBBBBBBBBBDBBBBB');
 for(let j=23;j<=31;j++)rows.push('B'+'c'.repeat(12)+'B'+'c'.repeat(11)+'B'+'l'.repeat(9)+'B');
 rows.push('B'.repeat(36));rows.push(' '.repeat(36));
 m.ascii(rows,{W:'HW',N:'HWin',h:'hlino',d:'doorwayL',E:'exitH',B:'BW',c:'bconc',U:'stairsUpT',D:'bconc',l:'hlino'});
 m.set(2,13,T.stairsDn);
 const f=G.flags;m.safe=()=>P.y<ty(16);
 m.ambient={a:.86,c:'6,8,14'};m.snd={room:.06,drone:.06,rain:.03};
 // ground floor
 m.light(tx(4),ty(3),70,.6,'255,205,150');m.light(tx(12),ty(11),60,.45,'255,205,150');
 m.light(tx(22),ty(4),80,.8,'255,210,160');m.light(tx(30),ty(4),80,.8,'255,210,160');m.light(tx(26),ty(11),80,.75,'255,210,160');
 m.prop('recdesk',tx(8),ty(4)+4);m.prop('chairs',tx(5),ty(9));m.prop('chairs',tx(11),ty(9));m.prop('chairs',tx(5),ty(12));
 m.prop('vending',tx(15),ty(2)+6,{on:false});m.prop('trolley',tx(3),ty(6));m.prop('plant',tx(1),ty(2)+4);
 m.prop('nboard',tx(11),16,{interact:I('Noticeboard',S.noticeboard)});
 [20,24,28,32].forEach((x,i)=>m.prop('hbed',tx(x),ty(3)+6,{c:['#8aa6c0','#a0b8a0','#c0a0a0','#8aa6c0'][i]}));
 m.prop('table',tx(26),ty(12)+2);m.prop('chair',tx(24)+4,ty(12));m.prop('chair',tx(28)-4,ty(12));
 m.prop('bench',tx(5),ty(13)+12,{interact:I('Bench',S.hospRest)});
 const mara=npc(m,f.insulin?tx(22):tx(17)+8,f.insulin?ty(11):ty(8),'mara',{fixedDir:f.insulin?0:1,clean:1,interact:I('Mara',S.mara)});G.mara=mara;
 if(!f.insulin){npc(m,tx(18)+8,ty(6),'theo',{fixedDir:1,pose:'sit',scale:.8,clean:f.inf_theo?0:1,interact:I('A boy',S.theoTalk)});
  npc(m,tx(32),ty(6)+6,'halloran',{fixedDir:0,pose:'sit',clean:1,interact:I('An old man',S.halloran)});}
 else{if(!f.theoWith&&!f.theoStay)npc(m,tx(13),ty(10),'theo',{fixedDir:3,scale:.8,clean:f.inf_theo?0:1,interact:I('Theo',S.theoTalk)});
  else if(f.theoStay)npc(m,tx(24),ty(6),'theo',{fixedDir:0,pose:'sit',scale:.8,clean:f.inf_theo?0:1,interact:I('Theo',S.theoTalk)});
  npc(m,tx(18)+8,ty(8),'halloran',{fixedDir:1,clean:f.inf_halloran?0:1,interact:I('Mr Halloran',S.halloran)});}
 const dg=new Dog(tx(25),ty(7),{mode:'hide',interact:I('Biscuit',S.biscuitHosp)});m.ents.push(dg);G.dog=dg;
 // basement
 m.light(tx(1),ty(19)+4,30,.5,'60,255,120',{gk:1.6});m.light(tx(30),ty(22)+6,24,.4,'60,255,120',{gk:1.6});
 const cl=m.light(tx(12),ty(19)+2,70,.6,'210,230,255',{flicker:5.3});m.corrLight=cl;
 m.prop('pipes',tx(4),ty(18)-1);m.prop('pipes',tx(32),ty(18)-1);
 m.prop('toolsBench',tx(6),ty(24)+2);m.prop('boxes',tx(11),ty(25));m.prop('boxes',tx(16),ty(24));m.prop('boxes',tx(22),ty(27));m.prop('trolley',tx(18),ty(30));
 [27,29,31,33].forEach(x=>m.prop('pshelf',tx(x),ty(23)+8,{v:x%4?'':'empty'}));m.prop('bench3',tx(30),ty(28));m.prop('sfridge',tx(34),ty(26),{on:false});
 if(!hasItem('cutters')&&!f.gateCut)m.ents.push(new Pickup(tx(6),ty(25)+4,'cutters',1,{flag:'pk_cut'}));
 if(!hasItem('insulin')&&!f.insulin)m.ents.push(new Pickup(tx(30),ty(28)+3,'insulin',1,{flag:'pk_ins',onTake:()=>{UI.objective('Bring the insulin to Mara.');}}));
 if(!f.pk_hw)m.ents.push(new Pickup(tx(32),ty(30),'water',1,{flag:'pk_hw'}));
 const H=(x,y,flag,o)=>{if(!f[flag])m.ents.push(new Hollow(x,y,Object.assign({flag,guard:60},o)));};
 H(tx(18),ty(27),'hb1',{truth:'t2',drop:{item:'bar',flag:'pk_bar2'}});H(tx(22),ty(25),'hb2',{truth:'t3'});H(tx(9),ty(28),'hb3',{truth:'p4'});
 // the looping corridor
 m.overlay=(c,ox,oy)=>drawCorridorWriting(c,ox,oy);
 m.tick=dt=>corridorTick(m,dt);
 m.exit(8,15,'Out to the canal',S.hospLeave);
 m.exit(2,13,'Stairs down to the basement',S.hospDown);
 m.exit(1,20,'Stairs up',S.hospUp);
 theoFollower(m,P.x+10,P.y);
 m.finalize();return m;
}
function drawCorridorWriting(c,ox,oy){
 const n=G.loopN||0,solved=G.flags.loopSolved;const y=ty(18)-5-oy;
 c.save();c.textBaseline='middle';c.globalAlpha=.55;
 c.font='bold 5px "Space Mono",monospace';c.fillStyle='#d8dcd0';c.fillRect(tx(10)-14-ox,y-4,30,8);c.fillStyle='#2a6a3a';c.fillText('PHARMACY →',tx(10)-12-ox,y);
 c.globalAlpha=.6+.25*Math.sin(G.time*3);
 if(!solved&&n>=2){c.font='9px "Caveat",cursive';c.fillStyle='rgba(150,30,24,.9)';c.save();c.translate(tx(15)-ox,y);c.rotate(-.04);c.fillText('DON’T LISTEN',0,0);c.restore();}
 if(!solved&&n>=3){c.font='10px "Caveat",cursive';c.fillStyle='rgba(160,28,22,.95)';c.save();c.translate(tx(22)-ox,y+1);c.rotate(.05);c.fillText('TURN AROUND',0,0);c.restore();}
 if(!solved&&n>=4){c.font='8px "Caveat",cursive';c.fillStyle='rgba(160,28,22,.9)';c.fillText('it isn’t you',tx(9)-ox,y+3);c.fillText('TURN AROUND',tx(3)-ox,y);}
 c.restore();
}
function corridorTick(m,dt){
 const f=G.flags;if(f.loopSolved)return;
 const inCorr=P.y>ty(18)&&P.y<=ty(21);if(!inCorr)return;
 G.loopN=G.loopN||0;
 if(P.x>tx(27)){
  const shift=tx(27)-tx(5);P.x-=shift;G.cam.x-=shift;G.loopN++;
  for(const e of m.ents)if(e.loopBody)e.x-=0;
  const n=G.loopN;Snd.play('glitch');
  if(n===1){murmur('Keep going. The pharmacy is just ahead.',4);if(!m.ents.some(e=>e.loopBody))m.ents.push(new Sleeper(tx(20),ty(20)+4,'p2',{pose:'lie',smile:true,loopBody:1}));}
  if(n===2){murmur('Keep going. It’s just a little further.',4);G.stats.sanity=Math.max(0,G.stats.sanity-4);}
  if(n===3){murmur('Don’t turn around. Keep going.',4);G.stats.sanity=Math.max(0,G.stats.sanity-5);G.glitch=.3;UI.thought('turn around',2);}
  if(n>=4){murmur('Keep going. Keep going. Keep going.',4);G.stats.sanity=Math.max(0,G.stats.sanity-6);if(m.corrLight)m.corrLight.on=false;G.glitch=.5;const b=m.ents.find(e=>e.loopBody);if(b){b.pose='sit';b.x=tx(14)+n*8;}}
 }
 if(G.loopN>=1&&P.x<tx(5)&&P.fx<0){
  f.loopSolved=1;f.clue_loop=1;UI.flash('#fff',.9,.8);Snd.play('sting');
  m.ents=m.ents.filter(e=>!e.loopBody);if(m.corrLight)m.corrLight.on=true;
  P.x=tx(29);P.y=ty(21)-2;P.dir=0;P.fx=0;P.fy=1;G.cam.x=P.x;G.cam.y=P.y;
  G.timers.push({t:.6,fn:()=>murmur('The corridor is shorter than you remember.',4)});
 }
}
// ---------------- TUNNEL ----------------
function buildTunnel(){
 const m=new GMap('tunnel',124,14,T.void);const f=G.flags;
 m.rect(0,0,124,7,T.TW);m.rect(0,11,124,1,T.TW);
 for(let x=0;x<124;x++){m.set(x,7,T.ballast);m.set(x,8,T.trackA);m.set(x,9,T.trackB);m.set(x,10,T.ballast);}
 for(const [a,b] of [[0,16],[106,124]]){m.rect(a,0,b-a,2,T.voidS);m.rect(a,2,b-a,1,T.PW);m.rect(a,3,b-a,3,T.plat);m.rect(a,6,b-a,1,T.platEdge);}
 m.set(122,3,T.stairsUpT);m.set(122,4,T.stairsUpT);m.set(1,3,T.stairsUpT);m.set(1,4,T.stairsUpT);
 // stalled train x36..84
 m.rect(36,7,49,1,T.trainW);m.rect(36,10,49,1,T.trainW);m.rect(36,8,49,2,T.trainFl);
 for(const gx of [52,68]){m.rect(gx,8,1,2,T.trainGap);}
 // maintenance alcove
 m.rect(26,11,3,2,T.bconc);m.set(25,11,T.BW);m.set(25,12,T.BW);m.set(29,11,T.BW);m.set(29,12,T.BW);m.rect(25,13,5,1,T.BW);
 m.ambient={a:.97,c:'1,2,5'};m.snd={drone:.16,room:.08,wind:.04};
 // platform lights + nameboards
 m.light(tx(114),ty(4),84,.55,'200,215,235',{flick:.5});m.light(tx(7),ty(4),84,.5,'200,215,235',{flick:.6});
 m.prop('nameplate',tx(113),ty(2)-2,{});m.prop('nameplate',tx(6),ty(2)-2,{});
 m.prop('bench',tx(110),ty(4)-2);m.prop('bench',tx(10),ty(4)-2);
 // emergency lights
 for(let x=20;x<104;x+=12){m.prop('elight',tx(x),ty(6)-2);m.light(tx(x),ty(7)+4,56,.5,'255,60,40',{flick:.35,gk:1.4});}
 m.light(tx(60),ty(8)+8,70,.45,'200,225,255',{flicker:9.7});
 // seats & sleepers in the train
 const styles=['p1','p2','p3','p4','p5','t1','t2','t3','jogger','p2','p3'];let si=0;
 for(const cx of [38,44,54,62,70,78]){m.prop('tseat',tx(cx)+8,ty(7)+8);m.prop('tseat',tx(cx)+8,ty(9));
  if(cx!==62){m.ents.push(new Sleeper(tx(cx)+2,ty(7)+9,styles[si++%styles.length],{pose:'sit',smile:true,dir:0,interact:I('A passenger',S.trainSleeper)}));}
  if(cx%3!==0)m.ents.push(new Sleeper(tx(cx)+14,ty(9)-1,styles[si++%styles.length],{pose:'sit',smile:true,dir:3,interact:I('A passenger',S.trainSleeper)}));}
 const H=(x,y,flag,o)=>{if(!f[flag])m.ents.push(new Hollow(x,y,Object.assign({flag,guard:70},o)));};
 H(tx(96),ty(9),'ht1',{truth:'t2',lines:['Who’s there?!','STAY BACK!','Leave us alone!']});
 H(tx(58),ty(8)+4,'ht2',{truth:'t1',guard:50,lines:['Get out of here!','Please, please—','DON’T COME IN!']});
 H(tx(64),ty(8)+6,'ht3',{truth:'t3',guard:50,drop:{item:'water',flag:'pk_tw'}});
 H(tx(22),ty(9),'ht4',{truth:'p4',drop:{item:'bar',flag:'pk_bar3'}});
 const PK=(x,y,it,flag)=>{if(!f[flag])m.ents.push(new Pickup(x,y,it,1,{flag}));};
 PK(tx(27),ty(12)+2,'water','pk_tw2');PK(tx(28),ty(12)-2,'batt','pk_tb');PK(tx(74),ty(8)+4,'peaches','pk_tp');
 spot(m,tx(26),ty(12)-2,'Radio',S.tunnelRadio);
 m.exit(122,3,'Back up to the canal',S.tunnelBack);m.exit(122,4,'Back up to the canal',S.tunnelBack);
 m.exit(1,3,'Bethnal Green — way out',S.tunnelEnd);m.exit(1,4,'Bethnal Green — way out',S.tunnelEnd);
 theoFollower(m,P.x+10,P.y);
 m.finalize();return m;
}
Object.assign(BUILD,{canal:buildCanal,hosp:buildHospital,tunnel:buildTunnel});
