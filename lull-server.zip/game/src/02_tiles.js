// ================= TILES =================
const TL=[],T={};
function R(x,c,X,Y,w=1,h=1){x.fillStyle=c;x.fillRect(X,Y,w,h);}
function tile(name,o){const id=TL.length;TL.push(Object.assign({name,id,solid:false,opaque:false,wall:false,step:'hard',exit:false},o));T[name]=id;return id;}
function speck(x,r,cols,n,x0=0,y0=0,w=16,h=16){for(let i=0;i<n;i++)R(x,cols[(r()*cols.length)|0],x0+((r()*w)|0),y0+((r()*h)|0));}
function brick(x,r,base){
 R(x,'#2a1f1c',0,0,16,16);
 const cols=base||['#4f332c','#5a3a31','#46302a','#5f4036','#4a2f29'];
 for(let row=0;row<4;row++){const off=row%2?-4:0;for(let bx=off;bx<16;bx+=8){const c=cols[(r()*cols.length)|0];R(x,c,bx+1,row*4,7,3);if(r()<.3)R(x,'#6a483c',bx+1+((r()*6)|0),row*4,1,1);}}
 speck(x,r,['#3a2622','#6b4a3e'],6);
}
function sash(x,r,lit,v){
 R(x,'#b9b1a1',3,1,10,13);R(x,'#d2cbbb',3,1,10,1);
 if(lit){R(x,'#e3b263',4,2,8,10);R(x,'#f4d08a',5,3,3,4);R(x,'#b67a3a',4,2,2,10);R(x,'#b67a3a',10,2,2,10);}
 else{R(x,'#0f141a',4,2,8,10);R(x,'#1f2a34',4,2,8,1);R(x,'#26323d',5,3,1,3);R(x,'#1a232c',9,8,2,1);if(v===2){R(x,'#3a3f4a',4,2,2,10);R(x,'#3a3f4a',10,2,2,10);}}
 R(x,'#b9b1a1',4,7,8,1);R(x,'#9a9282',2,13,12,2);R(x,'#7f7869',2,15,12,1);
}
// void
tile('void',{solid:true,opaque:true,draw(x){R(x,'#000',0,0,16,16);}});
// ---- ground ----
tile('asph',{step:'road',draw(x,r){R(x,'#1e2228',0,0,16,16);speck(x,r,['#262b32','#181b20','#22262d'],34);if(r()<.3){let cx=(r()*16)|0,cy=(r()*16)|0;for(let i=0;i<7;i++){R(x,'#14171b',cx,cy);cx+=r()<.6?1:0;cy+=r()<.5?1:-1;}}}});
tile('asphDash',{step:'road',draw(x,r){TL[T.asph].draw(x,r);R(x,'#7d8186',2,13,12,2);speck(x,r,['#1e2228','#5a5e63'],6,2,13,12,2);}});
tile('asphYelT',{step:'road',draw(x,r){TL[T.asph].draw(x,r);R(x,'#8f7631',0,2,16,1);R(x,'#8f7631',0,4,16,1);speck(x,r,['#1e2228','#6c5a28'],5,0,2,16,3);}});
tile('asphYelB',{step:'road',draw(x,r){TL[T.asph].draw(x,r);R(x,'#8f7631',0,11,16,1);R(x,'#8f7631',0,13,16,1);speck(x,r,['#1e2228','#6c5a28'],5,0,11,16,3);}});
const paveDraw=(x,r)=>{for(let sy=0;sy<2;sy++)for(let sx=0;sx<2;sx++){R(x,['#454a51','#494e55','#41464c','#4c5158'][(r()*4)|0],sx*8,sy*8,8,8);}R(x,'#34383e',0,0,16,1);R(x,'#34383e',0,8,16,1);R(x,'#34383e',0,0,1,16);R(x,'#34383e',8,0,1,16);speck(x,r,['#53585f','#3d4147'],12);if(r()<.2){let cx=(r()*16)|0,cy=(r()*16)|0;for(let i=0;i<5;i++){R(x,'#2f3338',cx,cy);cx+=1;cy+=r()<.5?1:0;}}};
tile('pave',{draw:paveDraw});
tile('paveCB',{draw(x,r){paveDraw(x,r);R(x,'#6b7178',0,11,16,2);R(x,'#80868c',0,11,16,1);R(x,'#15181b',0,13,16,3);}});
tile('paveCT',{draw(x,r){paveDraw(x,r);R(x,'#15181b',0,0,16,2);R(x,'#6b7178',0,2,16,2);R(x,'#80868c',0,2,16,1);}});
tile('grass',{step:'grass',draw(x,r){R(x,'#2a3a2d',0,0,16,16);speck(x,r,['#33473a','#22302a','#2e4232'],40);for(let i=0;i<10;i++){const X=(r()*16)|0,Y=(r()*15)|0;R(x,'#3c5440',X,Y,1,2);}if(r()<.15)R(x,'#8a8a6a',(r()*14)|0,(r()*14)|0);}});
tile('gravel',{step:'gravel',draw(x,r){R(x,'#3d3832',0,0,16,16);speck(x,r,['#4d473f','#2f2b26','#57504a','#45403a'],46);}});
tile('coping',{draw(x,r){R(x,'#56595c',0,0,16,12);R(x,'#3d4043',0,0,1,12);R(x,'#3d4043',8,0,1,12);R(x,'#6a6d70',0,0,16,1);speck(x,r,['#4b4e51','#626568'],10,0,0,16,11);R(x,'#202427',0,12,16,4);R(x,'#161a1d',0,14,16,2);}});
tile('copingT',{draw(x,r){R(x,'#161a1d',0,0,16,2);R(x,'#56595c',0,2,16,12);R(x,'#3d4043',0,2,1,12);R(x,'#3d4043',8,2,1,12);speck(x,r,['#4b4e51','#626568'],10,0,3,16,11);R(x,'#3d3832',0,14,16,2);}});
tile('water',{solid:true,anim:true,draw(x,r,v){R(x,'#111d24',0,0,16,16);const rr=RNG(77);for(let i=0;i<6;i++){const y=(rr()*16)|0,xx=((rr()*16)|0)+v*2;R(x,'#1a2f38',xx%16,y,4,1);if(rr()<.5)R(x,'#24414b',(xx+5)%16,(y+3)%16,2,1);}speck(x,r,['#0d171d'],8);}});
tile('wood',{step:'wood',draw(x,r){for(let y=0;y<16;y+=4){let X=-((r()*10)|0);while(X<16){const L=8+((r()*10)|0);R(x,['#5b4331','#634936','#553e2e','#6a4f39'][(r()*4)|0],X,y,L,4);R(x,'#3b2b1f',X+L-1,y,1,4);X+=L;}R(x,'#3b2b1f',0,y+3,16,1);}speck(x,r,['#4a3626','#71553e'],8);}});
tile('carpet',{step:'soft',draw(x,r){R(x,'#3b3237',0,0,16,16);speck(x,r,['#43393f','#342c31','#4a3f45'],60);}});
tile('ktile',{step:'tile',draw(x,r){for(let i=0;i<2;i++)for(let j=0;j<2;j++)R(x,(i+j)%2?'#4a463f':'#6b665c',i*8,j*8,8,8);speck(x,r,['#5a564e','#3f3c36','#77726a'],10);}});
tile('btile',{step:'tile',draw(x,r){R(x,'#7a8285',0,0,16,16);for(let i=0;i<4;i++)for(let j=0;j<4;j++)R(x,r()<.1?'#8e979a':'#9aa3a5',i*4,j*4,3,3);}});
tile('lino',{step:'tile',draw(x,r){R(x,'#7c8883',0,0,16,16);speck(x,r,['#86928d','#737f7a','#6d7974'],30);R(x,'#717d78',0,0,16,1);R(x,'#717d78',0,0,1,16);}});
tile('conc',{draw(x,r){R(x,'#43464a',0,0,16,16);speck(x,r,['#4b4e52','#3c3f43','#505357'],34);if(r()<.25)R(x,'#36393c',0,(r()*16)|0,16,1);}});
tile('shopfl',{step:'tile',draw(x,r){for(let i=0;i<2;i++)for(let j=0;j<2;j++)R(x,(i+j)%2?'#6a6b63':'#75766d',i*8,j*8,8,8);R(x,'#5d5e57',0,0,16,1);R(x,'#5d5e57',0,8,16,1);R(x,'#5d5e57',0,0,1,16);R(x,'#5d5e57',8,0,1,16);speck(x,r,['#808178','#62635b'],8);}});
tile('stairs',{draw(x,r){for(let y=0;y<16;y+=4){R(x,'#5a5e62',0,y,16,3);R(x,'#2c2f33',0,y+3,16,1);R(x,'#6e7276',0,y,16,1);}speck(x,r,['#4c5054'],8);}});
tile('grate',{step:'metal',draw(x,r){R(x,'#3a3f43',0,0,16,16);for(let i=0;i<16;i+=3)for(let j=0;j<16;j+=3)R(x,'#1c1f22',i+1,j+1,2,2);R(x,'#4b5055',0,0,16,1);}});
tile('doorway',{step:'wood',draw(x,r){TL[T.wood].draw(x,r);R(x,'#3a2b20',0,6,16,4);R(x,'#4e3a2b',0,6,16,1);}});
tile('doorwayL',{step:'tile',draw(x,r){TL[T.lino].draw(x,r);R(x,'#5d6965',0,6,16,4);R(x,'#8b9792',0,6,16,1);}});
tile('doorwayS',{step:'tile',draw(x,r){TL[T.shopfl].draw(x,r);R(x,'#4a4b45',0,6,16,4);}});
// ---- fences / hedges ----
const rails=(x,r)=>{for(let i=1;i<16;i+=3){R(x,'#121417',i,1,1,13);R(x,'#2c3036',i,0,1,1);}R(x,'#16181b',0,3,16,1);R(x,'#16181b',0,11,16,1);R(x,'#000',0,14,16,1);};
tile('fence',{solid:true,draw(x,r){TL[T.grass].draw(x,r);rails(x,r);}});
tile('fenceP',{solid:true,draw(x,r){paveDraw(x,r);rails(x,r);}});
tile('rail',{solid:true,draw(x,r){TL[T.conc].draw(x,r);R(x,'#c9a43a',0,4,16,2);R(x,'#8f7429',0,6,16,1);for(let i=2;i<16;i+=7)R(x,'#a88a33',i,4,2,10);}});
tile('hedge',{solid:true,opaque:true,step:'soft',draw(x,r){R(x,'#18241b',0,0,16,16);for(let i=0;i<14;i++){const X=(r()*16)|0,Y=(r()*16)|0;R(x,['#223325','#2b3f2e','#1c2b1f','#34503a'][(r()*4)|0],X-2,Y-2,4,3);}R(x,'#0d140f',0,14,16,2);}});
// ---- auto-face walls (top + face where floor below) ----
tile('P',{solid:true,opaque:true,wall:true,top(x,r){R(x,'#121418',0,0,16,16);speck(x,r,['#16191d','#0f1114'],10);},face(x,r){R(x,'#6f685e',0,8,16,1);R(x,'#857d71',0,9,16,5);speck(x,r,['#8c8478','#7d766b'],8,0,9,16,5);R(x,'#d0c8b9',0,13,16,2);R(x,'#9a9284',0,15,16,1);}});
tile('Q',{solid:true,opaque:false,wall:true,top(x,r){TL[T.P].top(x,r);R(x,'#3a4650',2,6,12,2);},face(x,r){TL[T.P].face(x,r);R(x,'#d8d2c4',2,8,12,6);R(x,'#3f5060',3,9,10,4);R(x,'#5d7385',3,9,10,1);R(x,'#7d93a3',4,10,2,1);R(x,'#d8d2c4',8,9,1,4);}});
tile('C',{solid:true,opaque:true,wall:true,top(x,r){R(x,'#17191c',0,0,16,16);speck(x,r,['#1c1f22','#121417'],10);},face(x,r){R(x,'#4a4e52',0,8,16,1);R(x,'#5b6064',0,9,16,7);R(x,'#4a4e52',7,9,1,7);speck(x,r,['#63686c','#53585c'],8,0,9,16,7);R(x,'#3a3d40',0,15,16,1);}});
tile('V',{solid:true,opaque:false,wall:true,top(x,r){TL[T.C].top(x,r);R(x,'#2c3a44',0,6,16,2);},face(x,r){TL[T.C].face(x,r);R(x,'#8d9396',0,9,16,5);R(x,'#3b4b56',0,10,16,3);R(x,'#5f7584',0,10,16,1);R(x,'#8d9396',8,10,1,3);}});
tile('exitP',{solid:false,opaque:true,wall:true,exit:true,step:'wood',top(x,r){TL[T.P].top(x,r);},face(x,r){TL[T.P].face(x,r);R(x,'#2a1e16',3,7,10,9);R(x,'#5a4130',4,8,8,8);R(x,'#4b3627',5,9,6,3);R(x,'#4b3627',5,13,6,2);R(x,'#c9a85a',10,12,1,1);}});
tile('exitC',{solid:false,opaque:true,wall:true,exit:true,step:'metal',top(x,r){TL[T.C].top(x,r);},face(x,r){TL[T.C].face(x,r);R(x,'#202326',3,7,10,9);R(x,'#6f777c',4,8,8,8);R(x,'#5b6267',4,11,8,1);R(x,'#2c6b45',5,9,4,1);R(x,'#c9cdd0',10,12,1,2);}});
// ---- exterior buildings (explicit facades) ----
tile('roof',{solid:true,opaque:true,wall:true,top(x,r){R(x,'#262a31',0,0,16,16);for(let y=0;y<16;y+=4){R(x,'#1e2127',0,y+3,16,1);const off=(y/4)%2?3:0;for(let X=off;X<16;X+=6)R(x,'#1e2127',X,y,1,3);}speck(x,r,['#2d323a','#22252b','#30353d'],12);},face(x,r){R(x,'#0e1013',0,12,16,2);R(x,'#3a3f46',0,14,16,1);R(x,'#17191c',0,15,16,1);}});
tile('brick',{solid:true,opaque:true,draw(x,r){brick(x,r);}});
tile('brickY',{solid:true,opaque:true,draw(x,r){brick(x,r,['#8a7a5a','#7e6f52','#958562','#6f6248']);}});
tile('brickWin',{solid:true,opaque:true,draw(x,r,v){brick(x,r);sash(x,r,false,v);}});
tile('brickWinY',{solid:true,opaque:true,draw(x,r,v){brick(x,r,['#8a7a5a','#7e6f52','#958562','#6f6248']);sash(x,r,false,v);}});
tile('brickWinLit',{solid:true,opaque:true,draw(x,r,v){brick(x,r);sash(x,r,true,v);}});
const doorCols=['#1b1d22','#5e2622','#243a52','#2b4232'];
const doorDraw=(x,r,v,base)=>{brick(x,r,base);R(x,'#c3bba9',3,0,10,16);R(x,'#2a3038',4,1,8,2);R(x,'#c3bba9',8,1,1,2);const c=doorCols[v%4];R(x,c,4,3,8,13);R(x,'rgba(255,255,255,.08)',5,4,3,5);R(x,'rgba(255,255,255,.08)',8,4,3,5);R(x,'rgba(0,0,0,.25)',5,10,6,4);R(x,'#c9a85a',10,9,1,1);R(x,'#c9a85a',7,6,2,1);R(x,'#55585c',2,15,12,1);};
tile('brickDoor',{solid:false,opaque:true,exit:true,draw(x,r,v){doorDraw(x,r,v);}});
tile('brickDoorX',{solid:true,opaque:true,draw(x,r,v){doorDraw(x,r,v);}});
tile('brickDoorY',{solid:true,opaque:true,draw(x,r,v){doorDraw(x,r,v,['#8a7a5a','#7e6f52','#958562','#6f6248']);}});
tile('shopSign',{solid:true,opaque:true,draw(x,r,v){brick(x,r);R(x,'#1f3a30',0,7,16,9);R(x,'#2c5243',0,7,16,1);R(x,'#12241d',0,15,16,1);const rr=RNG(v*13+5);for(let i=0;i<5;i++)R(x,'#e8dcb0',2+i*3,10,2,3);if(v%2)R(x,'#c8402e',1,9,1,5);}});
tile('shopFront',{solid:true,opaque:false,draw(x,r,v){R(x,'#24262a',0,0,16,16);R(x,'#c9b98c',1,1,14,13);for(let i=0;i<5;i++)R(x,['#b04a3a','#d9c060','#4a7a5a','#3a5a8a','#e0e0d0'][(r()*5)|0],2+((r()*11)|0),3+((r()*9)|0),2,3);R(x,'#e8dcb4',2,2,3,1);R(x,'#3a3c40',0,14,16,2);R(x,'#24262a',8,1,1,13);}});
tile('shopFrontDark',{solid:true,opaque:true,draw(x,r){R(x,'#24262a',0,0,16,16);R(x,'#141a20',1,1,14,13);R(x,'#22303a',2,2,6,1);R(x,'#3a3c40',0,14,16,2);R(x,'#24262a',8,1,1,13);}});
tile('shopFrontBroken',{solid:true,opaque:false,draw(x,r){R(x,'#24262a',0,0,16,16);R(x,'#0c1014',1,1,14,13);R(x,'#3c4a55',2,2,3,2);R(x,'#3c4a55',11,5,2,4);for(let i=0;i<4;i++){let cx=8,cy=7;for(let j=0;j<5;j++){cx+=[-1,0,1][(r()*3)|0];cy+=[-1,1][i%2];R(x,'#5a6a75',cx,cy);}}R(x,'#3a3c40',0,14,16,2);}});
tile('shopDoor',{solid:false,opaque:false,exit:true,draw(x,r,v){R(x,'#24262a',0,0,16,16);R(x,v?'#141a20':'#c9b98c',2,1,12,15);R(x,'#24262a',7,1,2,15);R(x,'#9aa0a5',6,8,1,2);R(x,'#9aa0a5',9,8,1,2);R(x,'#55585c',1,15,14,1);}});
tile('shopDoorBroken',{solid:false,opaque:false,exit:true,draw(x,r){R(x,'#24262a',0,0,16,16);R(x,'#0a0d10',2,1,12,15);R(x,'#4a5a65',2,1,3,3);R(x,'#4a5a65',11,10,3,5);R(x,'#55585c',1,15,14,1);}});
tile('shutter',{solid:true,opaque:true,draw(x,r){R(x,'#4c5157',0,0,16,16);for(let y=1;y<16;y+=2)R(x,'#3b3f44',0,y,16,1);R(x,'#2a2d31',0,14,16,2);if(r()<.6){const c=pick(['#9a3a4a','#3a7a9a','#d0d0c0','#7aa04a']);let X=(r()*8)|0,Y=4+((r()*6)|0);for(let i=0;i<9;i++){R(x,c,X,Y);X+=1;Y+=[-1,0,1][(r()*3)|0];}}}});
tile('stationF',{solid:true,opaque:true,draw(x,r){R(x,'#5f6468',0,0,16,16);speck(x,r,['#686d71','#565a5e'],14);R(x,'#2f8a83',0,3,16,2);R(x,'#d9dcdc',0,5,16,1);R(x,'#3a3e42',0,15,16,1);}});
tile('stationIn',{solid:false,opaque:false,exit:true,draw(x,r){R(x,'#5f6468',0,0,16,16);R(x,'#2f8a83',0,3,16,2);R(x,'#0a0c0e',1,6,14,10);R(x,'#2a2e33',2,10,12,1);R(x,'#2a2e33',2,13,12,1);}});
tile('stationShut',{solid:true,opaque:true,draw(x,r){R(x,'#5f6468',0,0,16,16);R(x,'#2f8a83',0,3,16,2);R(x,'#4c5157',1,6,14,10);for(let y=7;y<16;y+=2)R(x,'#3b3f44',1,y,14,1);}});
tile('wallTop',{solid:true,opaque:true,draw(x,r){R(x,'#3e4146',0,0,16,16);speck(x,r,['#46494e','#35383c'],14);R(x,'#55585d',0,0,16,1);}});
// derived tile sets
const STEP_OF=id=>TL[id].step;
// tile image cache
const TIMG=[],TIMGF=[];
function buildTiles(){
 TL.forEach(t=>{TIMG[t.id]=[];TIMGF[t.id]=[];
  for(let v=0;v<4;v++){
   const [c,x]=mkC(16,16);const r=RNG(t.id*977+v*131+7);
   if(t.wall){t.top(x,r,v);TIMG[t.id][v]=c;const [c2,x2]=mkC(16,16);x2.drawImage(c,0,0);t.face(x2,RNG(t.id*31+v),v);TIMGF[t.id][v]=c2;}
   else{t.draw(x,r,v);TIMG[t.id][v]=c;}
  }});
}
