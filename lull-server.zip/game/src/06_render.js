// ================= RENDER =================
const cv=$('#game'),ctx=cv.getContext('2d');ctx.imageSmoothingEnabled=false;
const [lightC,lx]=mkC(W,H),[bufC,bx]=mkC(W,H),[redC,rdx]=mkC(W,H),[cyC,cyx]=mkC(W,H),[truC,trx]=mkC(W,H);
let GRAIN=[],GRAINP=[],VIG=null,FOG=null,FOGP=null,FOGPT=null;
// render scale: world units are 16px tiles; the canvas is RS times larger
let RS=1,CW=W,CH=H,LS=1;
const q=v=>Math.round(v*RS)/RS;
function setRes(){
 const pref=store('lull_res')||'hd';
 const dpr=window.devicePixelRatio||1;
 const want=pref==='retro'?1:pref==='med'?2:clamp(Math.round((UI.w||innerWidth)*dpr/W),2,4);
 RS=want;CW=W*RS;CH=H*RS;
 LS=Math.max(1,RS/2);
 for(const c of [cv,bufC,redC,cyC,truC]){c.width=CW;c.height=CH;}lightC.width=W*LS;lightC.height=H*LS;
 for(const x of [ctx,lx,bx,rdx,cyx,trx])x.imageSmoothingEnabled=false;
 {const [c,x]=mkC(CW,CH);const g=x.createRadialGradient(CW/2,CH/2,CH*.28,CW/2,CH/2,CH*.95);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,1)');x.fillStyle=g;x.fillRect(0,0,CW,CH);VIG=c;}
 if(FOG){FOGP=ctx.createPattern(FOG,'repeat');FOGPT=trx.createPattern(FOG,'repeat');}
 GRAINP=GRAIN.map(g=>ctx.createPattern(g,'repeat'));
 cv.style.imageRendering=RS>1?'auto':'pixelated';
}
function buildFx(){
 for(let f=0;f<4;f++){const [c,x]=mkC(256,256);const id=x.createImageData(256,256);for(let i=0;i<id.data.length;i+=4){const v=Math.random()*255|0;id.data[i]=id.data[i+1]=id.data[i+2]=v;id.data[i+3]=255;}x.putImageData(id,0,0);GRAIN.push(c);}
 {const S=128,[c,x]=mkC(S,S);const id=x.createImageData(S,S);const r=RNG(5);const grid=[];const G2=8;for(let i=0;i<G2*G2;i++)grid.push(r());
  const at=(i,j)=>grid[((j%G2+G2)%G2)*G2+((i%G2+G2)%G2)];
  for(let y=0;y<S;y++)for(let X=0;X<S;X++){const fx=X/S*G2,fy=y/S*G2,i=Math.floor(fx),j=Math.floor(fy),u=fx-i,v=fy-j,su=u*u*(3-2*u),sv=v*v*(3-2*v);
   const n=lerp(lerp(at(i,j),at(i+1,j),su),lerp(at(i,j+1),at(i+1,j+1),su),sv);const k=(y*S+X)*4;id.data[k]=150;id.data[k+1]=165;id.data[k+2]=180;id.data[k+3]=Math.max(0,(n-.35))*255*1.4|0;}
  x.putImageData(id,0,0);FOG=c;FOGP=ctx.createPattern(c,'repeat');}
}
const rainDrops=[];for(let i=0;i<240;i++)rainDrops.push({x:rand(W),y:rand(H),l:rand(4,9),s:rand(260,360)});
function camOff(){let ox=G.cam.x-W/2,oy=G.cam.y-H/2;const m=G.map;
 if(m.w*16<=W)ox=(m.w*16-W)/2;else ox=clamp(ox,0,m.w*16-W);
 if(m.h*16<=H)oy=(m.h*16-H)/2;else oy=clamp(oy,0,m.h*16-H);
 return [q(ox+G.shakeX),q(oy+G.shakeY)];}
function lightLevelAt(x,y){
 const m=G.map;let l=1-m.ambient.a;
 for(const L of m.lights){if(!L.on)continue;const d=dist(x,y,L.x,L.y);if(d<L.r&&losClear(m,L.x,L.y,x,y))l+=L.i*(1-d/L.r);}
 if(P.torch)l+=.75;return l;}
function losClear(m,x0,y0,x1,y1){const d=dist(x0,y0,x1,y1),n=Math.ceil(d/4);for(let i=1;i<n;i++){const t=i/n;if(m.opaqueAt(lerp(x0,x1,t),lerp(y0,y1,t)))return false;}return true;}
function polyPath(c,pts,ox,oy){c.beginPath();c.moveTo(pts[0]-ox,pts[1]-oy);for(let i=2;i<pts.length;i+=2)c.lineTo(pts[i]-ox,pts[i+1]-oy);c.closePath();}
function tileImgAt(m,i,j,wf){const id=m.tile(i,j),t=TL[id];const v=m.v[j*m.w+i];
 if(t.anim)return TIMG[id][(wf+i+j*3)%4];
 if(t.wall){const b=TL[m.tile(i,j+1)];return(t.exit||(!b.wall&&b.id!==0))?TIMGF[id][v]:TIMG[id][v];}
 return TIMG[id][v];}
function buildTileCache(m){const [c,x]=mkC(m.w*16,m.h*16);m.tc=c;m.tcx=x;m.anims=[];m.wf=-1;
 for(let j=0;j<m.h;j++)for(let i=0;i<m.w;i++){x.drawImage(tileImgAt(m,i,j,0),i*16,j*16);if(TL[m.tile(i,j)].anim)m.anims.push([i,j]);}
 // doormats in front of interior exit doors
 for(let j=1;j<m.h;j++)for(let i=0;i<m.w;i++){const t=TL[m.tile(i,j)];if(t.exit&&t.wall&&!TL[m.tile(i,j-1)].solid){const X=i*16,Y=(j-1)*16;x.fillStyle='#2a1d16';x.fillRect(X+1,Y+8,14,8);x.fillStyle='#5a4030';x.fillRect(X+2,Y+9,12,6);x.fillStyle='#6e5038';for(let k=0;k<12;k+=2)x.fillRect(X+2+k,Y+9,1,6);x.fillStyle='#3a2a20';x.fillRect(X+2,Y+12,12,1);}}}
function drawTiles(c,m,ox,oy){
 if(!m.tc)buildTileCache(m);
 const wf=(G.time*2.5|0);if(wf!==m.wf){m.wf=wf;for(const [i,j] of m.anims)m.tcx.drawImage(tileImgAt(m,i,j,wf),i*16,j*16);}
 const MW=m.w*16,MH=m.h*16,sx=Math.max(0,ox),sy=Math.max(0,oy),ex=Math.min(MW,ox+W),ey=Math.min(MH,oy+H);
 if(ex>sx&&ey>sy)c.drawImage(m.tc,sx,sy,ex-sx,ey-sy,sx-ox,sy-oy,ex-sx,ey-sy);
}
function drawProp(c,p,ox,oy){
 if(p.hidden)return;const d=p.d,img=propDrawImg(p);const X=(q(p.x-d.w/2)-ox),Y=(q(p.y-d.h)-oy);
 if(X>W||Y>H||X+d.w<0||Y+d.h<0)return;
 c.drawImage(img,X,Y,d.w,d.h);
 if(d.dyn||p.o.dyn)drawDyn(c,p,X,Y);
}
const mirrorHist=[];
function drawDyn(c,p,X,Y){
 if(p.name==='tank'){const a=G.time*.12+(p.o.ph||0);const cx=X+42,cy=Y+42;c.strokeStyle='#5a5f63';c.lineWidth=3;c.beginPath();c.moveTo(cx,cy);c.lineTo(cx+Math.cos(a)*35,cy+Math.sin(a)*35);c.stroke();c.strokeStyle='#c9a43a';c.lineWidth=1;c.beginPath();c.moveTo(cx,cy-1);c.lineTo(cx+Math.cos(a)*35,cy+Math.sin(a)*35-1);c.stroke();
  c.fillStyle='rgba(60,90,85,.35)';for(let i=0;i<5;i++){const r=8+((G.time*4+i*6)%26);c.fillRect(cx+Math.cos(i*1.7)*r,cy+Math.sin(i*1.7)*r,2,1);}}
 if(p.name==='tv'&&p.o.on){c.fillStyle=`rgba(${120+Math.random()*60|0},${150+Math.random()*60|0},${190+Math.random()*40|0},.8)`;c.fillRect(X+2,Y+1,16,10);c.fillStyle='rgba(255,255,255,.15)';c.fillRect(X+2,Y+1+((G.time*20)%10|0),16,1);}
 if(p.name==='telly'&&p.o.on){c.fillStyle=`rgba(${90+Math.random()*80|0},${110+Math.random()*60|0},${150+Math.random()*50|0},.55)`;c.fillRect(X+1,Y+1,20,8);}
 if((p.name==='police'||p.name==='ambulance')&&p.o.flash){const on=(G.time*4|0)%2;c.fillStyle=on?'#4a7aff':'#1a2a6a';c.fillRect(X+(p.name==='police'?15:20),Y+(p.name==='police'?4:5),p.name==='police'?3:4,2);c.fillStyle=on?'#1a2a6a':'#4a7aff';c.fillRect(X+(p.name==='police'?18:24),Y+(p.name==='police'?4:5),p.name==='police'?3:4,2);}
 if(p.name==='mirror'){const d=dist(P.x,P.y,p.x,p.y+14);if(d<40&&lightLevelAt(p.x,p.y+10)>.3){const lag=G.flags.mirrorLag?14:0;const h=mirrorHist[Math.min(mirrorHist.length-1,lag)]||{dir:P.dir,moving:false,anim:0};
   const md=[3,2,1,0][h.dir];c.save();c.beginPath();c.rect(X+1,Y+1,10,10);c.clip();c.globalAlpha=.75;drawHum(c,'rowan',md,'idle',0,{smile:G.mirrorSmile},X-2+(h.x?clamp(Math.round((h.x-p.x)/6),-3,3):0),Y+1);c.globalAlpha=1;c.restore();c.fillStyle='rgba(120,150,170,.25)';c.fillRect(X+1,Y+1,10,10);}}
}
function drawShadow(c,x,y,w){c.fillStyle='rgba(0,0,0,.32)';c.beginPath();c.ellipse(x,y,w,w*.4,0,0,7);c.fill();}
function drawPlayer(c,ox,oy){
 const p=P;if(p.hidden)return;
 if(p.iT>0&&p.hurtT<=0&&((G.time*20|0)%2)&&p.dodgeT<=0)return;
 let pose=p.pose||(p.swing>=0?'swing':p.moving?'walk':'idle');
 const fr=pose==='walk'?((p.anim|0)%4)+1:0;
 const X=(q(p.x)-ox),Y=(q(p.y)-oy);
 drawShadow(c,X,Y-1,5);
 if(pose==='lie'){drawHum(c,playerStyle(),0,'lie',0,{closed:1,smile:G.lull?1:0},X-12,Y-10);return;}
 if(p.dodgeT>0)c.globalAlpha=.7;if(G.sink)c.globalAlpha=Math.max(0,1-G.sink);
 drawHum(c,playerStyle(),p.dir,pose,fr,{},X-8,Y-24);c.globalAlpha=1;
 // weapon
 const w=G.equip;if(w&&p.swing<0){const col=w==='crowbar'?'#7d8287':'#b8bcc0';c.fillStyle=col;
  if(p.dir===0)c.fillRect(X+5,Y-12,1,8);else if(p.dir===1)c.fillRect(X-3,Y-11,1,7);else if(p.dir===2)c.fillRect(X+2,Y-11,1,7);else c.fillRect(X-6,Y-18,1,8);}
 if(p.swing>=0){const t=p.swing/.26,a=Math.atan2(p.fy,p.fx),r=weapon().reach;c.save();c.translate(X,Y-8);c.strokeStyle=`rgba(230,235,240,${.55*(1-t)})`;c.lineWidth=2;c.beginPath();c.arc(0,0,r*.85,a-1+t*.6,a+.2+t*1.2);c.stroke();
  const wa=a-.9+t*1.9;c.strokeStyle=w==='crowbar'?'#8a9095':w==='knife'?'#c8ccd0':'#c79b7d';c.lineWidth=w?2:3;c.beginPath();c.moveTo(Math.cos(wa)*4,Math.sin(wa)*4);c.lineTo(Math.cos(wa)*(w?r*.8:9),Math.sin(wa)*(w?r*.8:9));c.stroke();c.restore();}
}
function drawEntities(c,m,ox,oy){
 const list=[];
 for(const p of m.props)if(p.layer===1&&!p.d.wall)list.push(p);
 for(const e of m.ents)if(!e.hidden)list.push(e);
 if(G.extraBodies)for(const e of G.extraBodies)list.push(e);
 list.push(P);
 list.sort((a,b)=>a.y-b.y);
 for(const e of list){
  if(e===P)drawPlayer(c,ox,oy);
  else if(e.kind==='prop')drawProp(c,e,ox,oy);
  else{if(e.kind!=='pickup'&&e.kind!=='sleeper'&&e.kind!=='spot'&&e.kind!=='veh'&&!(e.kind==='hollow'&&e.dead))drawShadow(c,(q(e.x)-ox),(q(e.y)-oy-1),e.kind==='dog'?6:5);e.draw(c,ox,oy);}
 }
}
function drawParticles(c,ox,oy){
 for(const p of G.parts){c.globalAlpha=clamp(p.life/p.max,0,1);c.fillStyle=p.col;c.fillRect((q(p.x)-ox),(q(p.y)-oy),p.s,p.s);}c.globalAlpha=1;}
function updateParticles(dt){
 for(const p of G.parts){p.life-=dt;p.vy+=(p.g||0)*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.fly){p.vx+=rand(-200,200)*dt;p.vy+=rand(-200,200)*dt;p.vx*=.95;p.vy*=.95;}if(p.g&&p.y>(p.floor||1e9))p.vy=0;}
 G.parts=G.parts.filter(p=>p.life>0);if(G.parts.length>600)G.parts.splice(0,G.parts.length-600);
 // emitters (fire)
 const m=G.map;if(m)for(const e of m.emitters){e.t=(e.t||0)-dt;if(e.t<=0){e.t=e.rate||.03;G.parts.push({x:e.x+rand(-e.w,e.w),y:e.y+rand(-2,2),vx:rand(-6,6),vy:rand(-40,-20),life:rand(.4,.9),max:.9,col:pick(e.cols||['#ffb347','#ff7a2a','#ffd27a','#c0401a']),s:pick([1,1,2]),ember:1});if(Math.random()<.15)G.parts.push({x:e.x+rand(-e.w,e.w),y:e.y-6,vx:rand(-4,4),vy:rand(-14,-8),life:2,max:2,col:'rgba(30,30,32,.4)',s:3});}}
}
function drawRain(c,dt){
 const m=G.map;if(!m.outdoor||!m.rain)return;const n=Math.floor(rainDrops.length*m.rain);
 c.strokeStyle=RS>1?'rgba(170,190,210,.42)':'rgba(165,185,205,.32)';c.lineWidth=RS>1?.42:1;c.beginPath();
 for(let i=0;i<n;i++){const d=rainDrops[i];if(!G.paused){d.y+=d.s*dt;d.x-=d.s*dt*.12;}if(d.y>H){d.y=-10;d.x=rand(-20,W+40);}if(d.x<-10)d.x+=W+20;c.moveTo(d.x,d.y);c.lineTo(d.x+d.l*.12,d.y-d.l);}
 c.stroke();
 c.fillStyle='rgba(170,190,210,.35)';const sw=RS>1?1.25:2,sh=RS>1?.5:1;for(let i=0;i<n*.12;i++){const x=rand(W),y=rand(H);c.fillRect(q(x),q(y),sw,sh);}
}
function drawLighting(c,m,ox,oy){
 const a=m.ambient.a*(G.lull?G.lull.amb:1);
 lx.setTransform(LS,0,0,LS,0,0);lx.globalCompositeOperation='source-over';lx.clearRect(0,0,W,H);lx.fillStyle=`rgba(${m.ambient.c},${a})`;lx.fillRect(0,0,W,H);
 lx.globalCompositeOperation='destination-out';
 const glows=[];
 for(const L of m.lights){if(!L.on)continue;if(L.x+L.r<ox||L.x-L.r>ox+W||L.y+L.r<oy||L.y-L.r>oy+H)continue;
  let I=L.i;if(L.flick)I*=1-L.flick*(Math.random()<.08?rand(.4,1):rand(0,.15));if(L.flicker)I*=(Math.sin(G.time*L.flicker)*.5+.5)>.15?1:.25;
  if(L.pulse)I*=.75+.25*Math.sin(G.time*L.pulse);
  const X=L.x-ox,Y=L.y-oy;const g=lx.createRadialGradient(X,Y,0,X,Y,L.r);g.addColorStop(0,`rgba(0,0,0,${I})`);g.addColorStop(.5,`rgba(0,0,0,${I*.6})`);g.addColorStop(1,'rgba(0,0,0,0)');
  lx.fillStyle=g;if(L.poly)polyPath(lx,L.poly,ox,oy);else{lx.beginPath();lx.arc(X,Y,L.r,0,7);}lx.fill();glows.push([L,I]);}
 // torch
 let tpoly=null;
 if(P.torch&&!P.hidden){const a0=Math.atan2(P.fy,P.fx),ex=P.x,ey=P.y-7;tpoly=castPoly(m,ex,ey,128,a0-.48,a0+.48,36);const X=ex-ox,Y=ey-oy;
  const bf=P.battery<15?(Math.random()<.1?.3:1):1;
  const g=lx.createRadialGradient(X,Y,0,X,Y,128);g.addColorStop(0,`rgba(0,0,0,${.98*bf})`);g.addColorStop(.6,`rgba(0,0,0,${.75*bf})`);g.addColorStop(1,'rgba(0,0,0,0)');lx.fillStyle=g;polyPath(lx,tpoly,ox,oy);lx.fill();
  const g2=lx.createRadialGradient(X,Y,0,X,Y,30);g2.addColorStop(0,'rgba(0,0,0,.6)');g2.addColorStop(1,'rgba(0,0,0,0)');lx.fillStyle=g2;lx.beginPath();lx.arc(X,Y,30,0,7);lx.fill();}
if(!P.hidden){const X=P.x-ox,Y=P.y-8-oy;const g=lx.createRadialGradient(X,Y,0,X,Y,20);g.addColorStop(0,'rgba(0,0,0,.32)');g.addColorStop(1,'rgba(0,0,0,0)');lx.fillStyle=g;lx.beginPath();lx.arc(X,Y,20,0,7);lx.fill();}
 const rpolys=G.coop?remoteTorches(lx,m,ox,oy):null;
 lx.globalCompositeOperation='source-over';
 c.imageSmoothingEnabled=true;c.drawImage(lightC,0,0,W,H);c.imageSmoothingEnabled=false;
 // colour glows
 c.save();c.beginPath();c.rect(-ox,-oy,m.w*16,m.h*16);c.clip();c.globalCompositeOperation='lighter';
 for(const [L,I] of glows){if(!L.c)continue;const X=L.x-ox,Y=L.y-oy;const g=c.createRadialGradient(X,Y,0,X,Y,L.r*.85);g.addColorStop(0,`rgba(${L.c},${.2*I*(L.gk||1)})`);g.addColorStop(1,`rgba(${L.c},0)`);c.fillStyle=g;if(L.poly)polyPath(c,L.poly,ox,oy);else{c.beginPath();c.arc(X,Y,L.r,0,7);}c.fill();
  if(L.head){const hy=Y+L.head;const g2=c.createRadialGradient(X,hy,0,X,hy,10);g2.addColorStop(0,`rgba(${L.c},${.7*I})`);g2.addColorStop(1,`rgba(${L.c},0)`);c.fillStyle=g2;c.fillRect(X-10,hy-10,20,20);
   if(m.rain&&m.outdoor){const g3=c.createRadialGradient(X,Y+4,0,X,Y+4,26);g3.addColorStop(0,`rgba(${L.c},${.12*I})`);g3.addColorStop(1,`rgba(${L.c},0)`);c.fillStyle=g3;c.save();c.translate(X,Y+4);c.scale(.5,1.4);c.beginPath();c.arc(0,0,26,0,7);c.fill();c.restore();}}}
 if(rpolys)for(const [rp,X,Y] of rpolys){const g=c.createRadialGradient(X,Y,0,X,Y,128);g.addColorStop(0,'rgba(255,236,200,.1)');g.addColorStop(1,'rgba(255,236,200,0)');c.fillStyle=g;polyPath(c,rp,ox,oy);c.fill();}
 if(tpoly){const X=P.x-ox,Y=P.y-7-oy;const g=c.createRadialGradient(X,Y,0,X,Y,128);g.addColorStop(0,'rgba(255,236,200,.13)');g.addColorStop(1,'rgba(255,236,200,0)');c.fillStyle=g;polyPath(c,tpoly,ox,oy);c.fill();}
 for(const s of m.shafts){const X=s.x-ox,Y=s.y-oy;const g=c.createLinearGradient(X,Y,X+s.dx,Y+s.dy);g.addColorStop(0,`rgba(${s.c},${s.a})`);g.addColorStop(1,`rgba(${s.c},0)`);c.fillStyle=g;c.beginPath();c.moveTo(X,Y);c.lineTo(X+s.w,Y);c.lineTo(X+s.w+s.dx,Y+s.dy);c.lineTo(X+s.dx,Y+s.dy);c.closePath();c.fill();}
 for(const p of G.parts)if(p.ember){c.globalAlpha=clamp(p.life/p.max,0,1)*.8;c.fillStyle=p.col;c.fillRect((q(p.x)-ox),(q(p.y)-oy),p.s,p.s);}c.globalAlpha=1;
 c.restore();c.globalCompositeOperation='source-over';
 return tpoly;
}
function drawScene(c,truth){
 const m=G.map;const [ox,oy]=camOff();G._ox=ox;G._oy=oy;
 c.setTransform(RS,0,0,RS,0,0);c.imageSmoothingEnabled=false;
 const prevTruth=G.truthNow;if(truth){G.truthNow=true;G._truthPass=true;}
 c.fillStyle='#000';c.fillRect(0,0,W,H);
 drawTiles(c,m,ox,oy);
 for(const d of m.decals)d(c,ox,oy);
 for(const p of m.props)if(p.layer===0||p.d.wall)drawProp(c,p,ox,oy);
 drawEntities(c,m,ox,oy);
 drawParticles(c,ox,oy);
 drawRain(c,truth?0:G.dt);
 const tpoly=drawLighting(c,m,ox,oy);
 if(m.overlay)m.overlay(c,ox,oy);
 // phantoms (drawn over darkness — eyes in the dark)
 for(const f of G.phantoms){const X=(q(f.x)-ox),Y=(q(f.y)-oy);const a=clamp(Math.min(f.t,f.life-f.t)*3,0,1)*.85;c.globalAlpha=a;drawHollowImg(c,0,X-10,Y-29,false);c.fillStyle='#d8d2c4';c.fillRect(X-1,Y-24,1,1);c.fillRect(X+1,Y-24,1,1);c.globalAlpha=1;}
 {const fp=c===trx?FOGPT:FOGP;if(m.fog&&fp){c.save();c.imageSmoothingEnabled=true;c.globalAlpha=m.fog;c.translate(-((ox*.9+G.time*6)%128),-((oy*.9+G.time*2)%128));c.fillStyle=fp;c.fillRect(0,0,W+256,H+256);c.restore();c.imageSmoothingEnabled=false;}}
 if(m.grade){c.globalCompositeOperation=m.grade.op||'soft-light';c.fillStyle=m.grade.c;c.fillRect(0,0,W,H);c.globalCompositeOperation='source-over';}
 if(truth){c.globalCompositeOperation='saturation';c.fillStyle='hsl(0,0%,50%)';c.globalAlpha=.7;c.fillRect(0,0,W,H);c.globalAlpha=1;c.globalCompositeOperation='multiply';c.fillStyle='#6f7a74';c.fillRect(0,0,W,H);c.globalCompositeOperation='source-over';}
 G.truthNow=prevTruth;G._truthPass=false;
 return tpoly;
}
function fxSlices(n,maxOff){ctx.save();ctx.setTransform(1,0,0,1,0,0);bx.setTransform(1,0,0,1,0,0);bx.globalCompositeOperation='source-over';bx.drawImage(cv,0,0);
 for(let i=0;i<n;i++){const y=irand(0,CH-4*RS),h=irand(1,16)*RS,o=irand(-maxOff,maxOff)*RS;ctx.drawImage(bufC,0,y,CW,h,o,y,CW,h);}ctx.restore();}
function fxRGB(off){off*=RS;ctx.save();ctx.setTransform(1,0,0,1,0,0);bx.setTransform(1,0,0,1,0,0);bx.drawImage(cv,0,0);
 for(const [x,col] of [[rdx,'#ff0000'],[cyx,'#00ffff']]){x.setTransform(1,0,0,1,0,0);x.globalCompositeOperation='source-over';x.drawImage(bufC,0,0);x.globalCompositeOperation='multiply';x.fillStyle=col;x.fillRect(0,0,CW,CH);x.globalCompositeOperation='source-over';}
 ctx.fillStyle='#000';ctx.fillRect(0,0,CW,CH);ctx.drawImage(redC,-off,0);ctx.globalCompositeOperation='lighter';ctx.drawImage(cyC,off,0);ctx.globalCompositeOperation='source-over';ctx.restore();}
function fxBlocks(n){for(let i=0;i<n;i++){ctx.fillStyle=pick(['rgba(255,40,60,.5)','rgba(40,255,240,.4)','rgba(255,255,255,.6)','rgba(0,0,0,.9)']);ctx.fillRect(irand(0,W),irand(0,H),irand(4,40),irand(1,6));}}
function render(){
 if(!G.map){ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#000';ctx.fillRect(0,0,CW,CH);return;}
 const s=G.stats.sanity,L=G.lull;
 if(L){
  drawScene(ctx,false);
  // golden calm
  ctx.globalCompositeOperation='soft-light';ctx.fillStyle=`rgba(255,196,120,${.6*L.warm})`;ctx.fillRect(0,0,W,H);
  ctx.globalCompositeOperation='lighter';ctx.fillStyle=`rgba(255,200,140,${.07*L.warm})`;ctx.fillRect(0,0,W,H);ctx.globalCompositeOperation='source-over';
  if(L.tear>0||L.full){drawScene(trx,true);
   if(L.full){ctx.drawImage(truC,0,0,W,H);}
   else{const n=Math.floor(L.tear*14);for(let i=0;i<n;i++){const y=irand(0,H-6),h=irand(2,10+L.tear*30);ctx.drawImage(truC,0,y*RS,CW,h*RS,irand(-3,3),y,W,h);}}}
  if(L.rgb>0)fxRGB(Math.round(L.rgb*4));
  if(L.slice>0)fxSlices(Math.floor(L.slice*10),Math.round(L.slice*22));
 }else{
  drawScene(ctx,false);
 }
 if(G.warm>0&&!L){ctx.globalCompositeOperation='soft-light';ctx.fillStyle=`rgba(255,196,120,${.65*G.warm})`;ctx.fillRect(0,0,W,H);ctx.globalCompositeOperation='lighter';ctx.fillStyle=`rgba(255,200,140,${.08*G.warm})`;ctx.fillRect(0,0,W,H);ctx.globalCompositeOperation='source-over';}
 // post: desaturate with low sanity
 {const k=G.sanityOn&&!L&&G.state==='play'?clamp((70-s)/70,0,1)*.65:0;const f=k>0.01?`saturate(${(1-k).toFixed(2)}) contrast(${(1+k*.15).toFixed(2)})`:'';if(cv.style.filter!==f)cv.style.filter=f;}
 // vignette
 const vig=.55+(G.sanityOn&&!L?clamp((60-s)/60,0,1)*.4:0)+(L?L.close:0);ctx.globalAlpha=clamp(vig,0,1);ctx.drawImage(VIG,0,0,W,H);if(L&&L.close>.5){ctx.globalAlpha=(L.close-.5)*2;ctx.drawImage(VIG,0,0,W,H);ctx.drawImage(VIG,0,0,W,H);}ctx.globalAlpha=1;
 // low health
 const hp=G.stats.health;if(G.state==='play'&&hp<35&&!L){ctx.globalCompositeOperation='multiply';ctx.fillStyle=`rgba(255,${120+hp*3|0},${120+hp*3|0},${.5*(1-hp/35)*(.75+.25*Math.sin(G.time*5))})`;ctx.fillRect(0,0,W,H);ctx.globalCompositeOperation='source-over';}
 if(G.redFlash>0){ctx.fillStyle=`rgba(120,0,0,${G.redFlash*.5})`;ctx.fillRect(0,0,W,H);}
 // sanity glitches
 if(G.glitch>0){const k=G.glitchK||1;if(Math.random()<.7)fxRGB(irand(1,3)*k|0||1);fxSlices(irand(2,6),irand(4,18)*k|0);if(Math.random()<.35)fxBlocks(irand(2,8));if(Math.random()<.12){ctx.globalCompositeOperation='difference';ctx.fillStyle='#fff';ctx.fillRect(0,0,W,H);ctx.globalCompositeOperation='source-over';}}
 // scanline wobble at very low sanity
 if(G.sanityOn&&!L&&s<22){const n=Math.floor((22-s)/4);fxSlices(n,2);}
 // grain
 {ctx.save();ctx.setTransform(1,0,0,1,0,0);const gs=Math.max(1,RS/2);ctx.translate(-irand(0,255)*gs,-irand(0,255)*gs);ctx.scale(gs,gs);ctx.globalAlpha=.07+(G.sanityOn?clamp((50-s)/50,0,1)*.07:0);ctx.globalCompositeOperation=RS>1?'source-over':'overlay';if(RS>1)ctx.globalAlpha*=.45;ctx.fillStyle=GRAINP[(G.time*24|0)%4];ctx.fillRect(0,0,CW/gs+300,CH/gs+300);ctx.restore();}
 if(G.whiteFlash>0){ctx.fillStyle=`rgba(255,250,240,${G.whiteFlash})`;ctx.fillRect(0,0,W,H);}
}
