// ================= ELDERFLOWER CORDIAL (sanity item) + radio alcove =================
ITEMS.cordial={name:'Elderflower cordial',icon:'cordial',desc:'A small bottle of homemade elderflower cordial, the handwritten label half peeled off. It tastes like June. Steadies the mind (+18 sanity).',use:{sanity:18,thirst:5},sfx:'drink'};
ICONDRAW.cordial=x=>{R(x,'#5a4030',7,0,3,2);R(x,'#d8dcd0',7,2,3,2);R(x,'rgba(220,235,225,.6)',5,4,7,11);R(x,'#d8d070',5,7,7,8);R(x,'#ece6a0',6,7,2,7);R(x,'#b8b050',10,8,2,7);R(x,'#f4f0e4',5,9,7,4);R(x,'#ffffff',7,10,1,1);R(x,'#ffffff',8,11,1,1);R(x,'#ffffff',9,10,1,1);R(x,'#7a9a5a',8,12,1,1);R(x,'rgba(255,255,255,.7)',6,5,1,2);};
def('radioShelf',{w:20,h:20,box:[-9,-6,18,6],draw(x){R(x,'#3a3e44',1,8,18,12);R(x,'#4c5258',1,8,18,1);R(x,'#2a2d32',2,14,16,1);R(x,'#2a2d32',3,19,2,1);R(x,'#2a2d32',15,19,2,1);
 R(x,'#c8a040',2,2,7,7);R(x,'#e8c860',2,2,7,1);R(x,'#1a1a1a',3,4,5,3);R(x,'#3a3a3a',4,5,3,1);R(x,'#9a9a9a',7,0,1,3);
 R(x,'#3a3a3a',11,3,6,6);R(x,'#ffd890',12,4,4,4);R(x,'#fff2c8',13,5,2,2);R(x,'#2a2a2a',11,2,6,1);}});
// helper used by the map builders
function cordialAt(m,x,y,flag){if(!G.flags[flag])m.ents.push(new Pickup(x,y,'cordial',1,{flag}));}
// wrap map builders to place cordials (positions chosen on open floor)
{const wrapB=(k,fn)=>{const old=BUILD[k];BUILD[k]=function(){const m=old();fn(m);return m;};};
 wrapB('flat',m=>{if(is('a1_flat','a2_flat'))cordialAt(m,330,72,'pk_cord3');});
 wrapB('street',m=>{if(is('a1_street','a2_street'))cordialAt(m,tx(50),ty(19)-3,'pk_cord1');});
 wrapB('shop',m=>{if(is('a1_shop','a2_shop'))cordialAt(m,tx(9),ty(8)+4,'pk_cord2');});
 wrapB('canal',m=>{cordialAt(m,tx(78),ty(19)+2,'pk_cord4');cordialAt(m,tx(32),ty(7),'pk_cord5');});
 wrapB('hosp',m=>{cordialAt(m,tx(33),ty(11),'pk_cord6');cordialAt(m,tx(3),ty(30),'pk_cord7');});
 wrapB('tunnel',m=>{cordialAt(m,tx(110),ty(5),'pk_cord8');cordialAt(m,tx(46),ty(8)+6,'pk_cord9');
  // emergency radio alcove: visible radio + lantern, and a small warm light
  m.ents=m.ents.filter(e=>!(e.kind==='spot'&&e.interact&&labelOf(e.interact)==='Radio'));
  m.ents.filter(e=>e.kind==='pickup'&&(e.flag==='pk_tw2'||e.flag==='pk_tb')).forEach(e=>{e.x=tx(28);e.y=e.flag==='pk_tw2'?202:188;});
  m.prop('radioShelf',tx(26)+2,206,{interact:I('Emergency radio',S.tunnelRadio)});
  const L=m.light(tx(26)+8,196,52,.75,'255,205,140',{flick:.06,gk:1.3});L.poly=castPoly(m,L.x,L.y,L.r,0,Math.PI*2,72);
 });}
