// ================= STAGE 3 ART =================
// ---------- tiles ----------
tile('cobble',{step:'hard',draw(x,r){R(x,'#36322e',0,0,16,16);for(let j=0;j<4;j++)for(let i=0;i<5;i++){const ox=j%2?-2:0;R(x,['#55504a','#5c564e','#4d4843','#615a51'][(r()*4)|0],i*4+ox,j*4,3,3);R(x,'rgba(255,255,255,.05)',i*4+ox,j*4,3,1);}speck(x,r,['#6a635a','#3f3b37'],6);}});
const glassDraw=(x,r,v,lit)=>{R(x,'#1c2530',0,0,16,16);const base=['#2c3b4a','#33465a','#283646','#2f4052'][v%4];
 for(let j=0;j<2;j++)for(let i=0;i<2;i++){R(x,base,i*8+1,j*8+1,7,7);R(x,sh(base,1.25),i*8+1,j*8+1,7,1);if(lit&&r()<.35)R(x,'#d8c48a',i*8+2,j*8+3,5,4);}
 x.fillStyle='rgba(180,210,230,.12)';x.beginPath();x.moveTo(0,16);x.lineTo(6,0);x.lineTo(10,0);x.lineTo(4,16);x.fill();R(x,'#10161c',0,0,16,1);R(x,'#10161c',0,8,16,1);R(x,'#10161c',0,0,1,16);R(x,'#10161c',8,0,1,16);};
tile('glassF',{solid:true,opaque:true,draw(x,r,v){glassDraw(x,r,v,false);}});
tile('glassL',{solid:true,opaque:true,draw(x,r,v){glassDraw(x,r,v,true);}});
tile('glassDoor',{solid:true,opaque:true,draw(x,r){R(x,'#1c2530',0,0,16,16);R(x,'#3a4a58',2,2,12,14);R(x,'#151c22',3,3,4,13);R(x,'#151c22',9,3,4,13);R(x,'#9aa8b4',7,8,2,2);R(x,'#55606a',1,15,14,1);}});
const brutDraw=(x,r)=>{R(x,'#64605a',0,0,16,16);for(let i=0;i<16;i+=2)R(x,i%4?'#5c5852':'#6c6862',i,0,1,16);speck(x,r,['#56524c','#726e68','#4c4844'],22);};
tile('brut',{solid:true,opaque:true,draw(x,r){brutDraw(x,r);R(x,'#4a4742',0,15,16,1);}});
tile('brutWin',{solid:true,opaque:true,draw(x,r,v){brutDraw(x,r);R(x,'#3e3b37',0,4,16,7);R(x,'#141618',1,5,14,5);R(x,'#22282e',1,5,14,1);if(v===1)R(x,'#d8b878',3,6,4,3);R(x,'#4a4742',0,15,16,1);}});
tile('brutTop',{solid:true,opaque:true,draw(x,r){R(x,'#2c2a27',0,0,16,16);R(x,'#34322e',0,0,16,1);R(x,'#34322e',0,8,16,1);R(x,'#252321',8,0,1,16);speck(x,r,['#302e2a','#262420'],12);}});
tile('podium',{draw(x,r){R(x,'#57534d',0,0,16,16);R(x,'#4c4843',0,0,16,1);R(x,'#4c4843',0,0,1,16);speck(x,r,['#5f5b55','#4f4b46'],20);}});
tile('gateSteel',{solid:true,opaque:false,draw(x,r){R(x,'#1a1c1e',0,0,16,16);R(x,'#2c3034',0,0,16,2);R(x,'#3c4248',0,0,16,1);for(let i=1;i<16;i+=3){R(x,'#4a5056',i,2,2,14);R(x,'#6a7076',i,2,1,14);}R(x,'#3c4248',0,8,16,2);R(x,'#2c3034',0,14,16,2);}});
tile('rampShut',{solid:true,opaque:true,draw(x,r){R(x,'#3a3d40',0,0,16,16);for(let y=1;y<16;y+=2)R(x,'#2c2f32',0,y,16,1);R(x,'#d8b040',0,13,16,1);R(x,'#1a1a1a',0,14,16,2);}});
tile('rampDn',{exit:true,step:'road',draw(x,r){R(x,'#121416',0,0,16,16);for(let y=0;y<16;y+=4)R(x,'#1a1d20',0,y,16,2);R(x,'#d8b040',2,2,3,1);R(x,'#d8b040',11,2,3,1);R(x,'#d8b040',6,8,4,1);R(x,'rgba(0,0,0,.4)',0,8,16,8);}});
tile('tunW',{solid:true,opaque:true,wall:true,top(x,r){R(x,'#24221f',0,0,16,16);speck(x,r,['#2a2824','#1e1c1a'],10);},face(x,r){for(let i=0;i<16;i+=4)for(let j=8;j<16;j+=2)R(x,((i+j)/2)%3?'#c8c4b6':'#bcb8aa',i,j,4,2);R(x,'#8a8676',0,8,16,1);R(x,'rgba(40,36,30,.35)',0,12,16,4);speck(x,r,['#9a9686','#7a7666'],10,0,9,16,7);}});
tile('mud',{step:'soft',draw(x,r){R(x,'#3e382e',0,0,16,16);speck(x,r,['#463f34','#353027','#4e463a','#2e2a23'],50);for(let i=0;i<3;i++)R(x,'#6a6458',(r()*14)|0,(r()*14)|0,2,1);}});
tile('shingle',{step:'gravel',draw(x,r){R(x,'#4a463e',0,0,16,16);for(let i=0;i<28;i++){R(x,['#6a655c','#5a554c','#7a756a','#3e3a33'][(r()*4)|0],(r()*15)|0,(r()*15)|0,2,1);}}});
tile('thames',{solid:true,anim:true,draw(x,r,v){R(x,'#2e3632',0,0,16,16);const rr=RNG(31);for(let i=0;i<6;i++){const y=(rr()*16)|0,xx=((rr()*16)|0)+v*2;R(x,'#3c4640',xx%16,y,5,1);if(rr()<.5)R(x,'#56605a',(xx+6)%16,(y+4)%16,2,1);}}});
tile('thamesS',{anim:true,step:'soft',draw(x,r,v){R(x,'#38403a',0,0,16,16);const rr=RNG(41);for(let i=0;i<5;i++){const y=(rr()*16)|0,xx=((rr()*16)|0)+v*2;R(x,'#4a544c',xx%16,y,5,1);}speck(x,r,['#4a463e'],6);}});
tile('embank',{solid:true,opaque:false,draw(x,r){R(x,'#6a6a64',0,0,16,16);for(let j=0;j<16;j+=4){const o=(j/4)%2?4:0;for(let i=-4;i<16;i+=8)R(x,'#5a5a54',i+o,j,1,4);R(x,'#5a5a54',0,j,16,1);}R(x,'#2e2e2a',0,0,16,2);R(x,'#8a8a84',0,2,16,1);}});
tile('planter',{solid:true,opaque:false,draw(x,r){R(x,'#7a6a58',0,0,16,16);R(x,'#3a2e22',1,1,14,14);for(let i=0;i<14;i++)R(x,['#2e5a32','#3a7040','#24482a','#4a8048'][(r()*4)|0],1+((r()*12)|0),1+((r()*12)|0),3,3);if(r()<.3)R(x,'#d8a0c0',(r()*12+2)|0,(r()*12+2)|0,2,2);}});
tile('pathC',{step:'tile',draw(x,r){for(let i=0;i<2;i++)for(let j=0;j<2;j++)R(x,(i+j)%2?'#8a5a42':'#94644a',i*8,j*8,8,8);R(x,'#6a4232',0,0,16,1);R(x,'#6a4232',0,8,16,1);R(x,'#6a4232',0,0,1,16);R(x,'#6a4232',8,0,1,16);speck(x,r,['#a06e52','#7e5038'],8);}});
tile('pondC',{solid:true,anim:true,draw(x,r,v){R(x,'#1e3a32',0,0,16,16);const rr=RNG(17);for(let i=0;i<4;i++){const y=(rr()*16)|0,xx=((rr()*16)|0)+v;R(x,'#2e5248',xx%16,y,4,1);}R(x,'#3a7a40',3,3,4,3);R(x,'#3a7a40',10,10,3,3);R(x,'#e8c0d0',4,4,1,1);}});
tile('glassRoof',{solid:true,opaque:true,draw(x,r){R(x,'#3a4448',0,0,16,16);R(x,'#5a666a',0,0,16,1);R(x,'#5a666a',0,0,1,16);R(x,'rgba(160,200,210,.25)',1,1,15,15);}});
tile('carpetB',{step:'soft',draw(x,r){R(x,'#2e3a4e',0,0,16,16);speck(x,r,['#344256','#283446','#3a485e'],60);}});
tile('carpetR',{step:'soft',draw(x,r){R(x,'#5a3a44',0,0,16,16);speck(x,r,['#62424c','#52343e','#6a4a54'],60);}});
tile('kwhite',{step:'tile',draw(x,r){R(x,'#c8ccc8',0,0,16,16);R(x,'#b0b4b0',0,0,16,1);R(x,'#b0b4b0',0,8,16,1);R(x,'#b0b4b0',0,0,1,16);R(x,'#b0b4b0',8,0,1,16);speck(x,r,['#d4d8d4','#babeba'],10);}});
tile('pubFront',{solid:true,opaque:true,draw(x,r,v){R(x,'#1e3a2e',0,0,16,16);R(x,'#2a4e3e',0,0,16,2);R(x,'#c8a44a',0,2,16,1);if(v%2){R(x,'#c8a44a',3,5,2,2);R(x,'#c8a44a',9,5,3,2);}R(x,'#16302a',0,12,16,4);R(x,'#2a4e3e',0,12,16,1);}});
tile('pubWin',{solid:true,opaque:false,draw(x,r){R(x,'#1e3a2e',0,0,16,16);R(x,'#c8a44a',0,1,16,1);R(x,'#e8b868',2,3,12,10);R(x,'#ffd8a0',4,5,4,4);for(let i=2;i<14;i+=4)R(x,'#1e3a2e',i,3,1,10);R(x,'#1e3a2e',2,8,12,1);R(x,'#16302a',0,13,16,3);}});
tile('pubDoor',{solid:false,opaque:true,step:'wood',draw(x,r){R(x,'#1e3a2e',0,0,16,16);R(x,'#c8a44a',0,1,16,1);R(x,'#3a2418',3,3,10,13);R(x,'#5a3a26',4,4,8,12);R(x,'#ffd8a0',6,5,4,3);R(x,'#c8a44a',10,10,1,1);}});
tile('flatF',{solid:true,opaque:true,draw(x,r,v){R(x,'#a89a7a',0,0,16,16);for(let j=0;j<16;j+=3){const o=(j/3)%2?3:0;for(let i=-3;i<16;i+=6)R(x,'#988a6c',i+o,j,1,3);R(x,'#988a6c',0,j,16,1);}R(x,'#2a3038',2,3,12,9);R(x,'#3a4a58',3,4,10,7);R(x,'#5a7088',3,4,10,1);if(v===2)R(x,'#d8c08a',4,6,4,4);R(x,'#8a7c60',1,12,14,2);}});
tile('flatDoorX',{solid:false,opaque:true,exit:true,draw(x,r){R(x,'#a89a7a',0,0,16,16);R(x,'#3a3f46',2,2,12,14);R(x,'#5a6a78',3,3,10,12);R(x,'#3a4a58',3,3,10,6);R(x,'#c8ccd0',11,10,1,2);R(x,'#d8dcd0',4,0,8,2);R(x,'#2a2a2a',5,0,6,1);}});
// ---------- props ----------
const DEADF=['#6a4a3a','#7a5a48','#5a4a4a','#8a6a5a','#6a5a5a','#4a3a30','#9a7a6a'];
def('stall',{w:44,h:24,box:[-20,-10,40,10],draw(x){R(x,'#4a3a2a',2,14,40,6);R(x,'#5e4a36',2,14,40,1);R(x,'#3a2e22',3,20,2,4);R(x,'#3a2e22',39,20,2,4);
 for(let i=0;i<5;i++){const bx=4+i*8;R(x,'#5a6066',bx,8,7,7);R(x,'#7a8086',bx,8,7,1);for(let k=0;k<7;k++)R(x,DEADF[(i+k)%7],bx+((k*3)%6),2+((k*5)%6),2,3);R(x,'#3a4a2a',bx+2,6,1,3);R(x,'#3a4a2a',bx+5,5,1,4);}}});
def('grave',{w:12,h:16,box:[-5,-3,10,3],draw(x,o){const t=o.v==='1';R(x,'#5a5a56',2,t?2:4,8,12);R(x,'#6e6e6a',2,t?2:4,8,1);if(t){R(x,'#5a5a56',3,0,6,2);}else if(o.v==='2'){R(x,'#5a5a56',5,0,2,4);R(x,'#5a5a56',3,1,6,2);}R(x,'#3e3e3a',4,7,4,1);R(x,'#3e3e3a',4,9,3,1);R(x,'#3a4a2a',1,14,10,2);}});
def('buckets',{w:20,h:16,box:[-8,-4,16,4],draw(x){for(let i=0;i<2;i++){const bx=1+i*10;R(x,'#5a6066',bx,8,8,8);R(x,'#7a8086',bx,8,8,1);for(let k=0;k<6;k++)R(x,DEADF[(i*3+k)%7],bx+((k*3)%7),1+((k*4)%7),2,3);}}});
def('flood',{w:14,h:32,box:[-3,-3,6,3],light:{dy:-22,r:165,c:'235,240,255',i:1,head:-24},draw(x,o){R(x,'#1a1c1e',6,8,2,22);R(x,'#1a1c1e',2,28,10,2);R(x,'#1a1c1e',3,26,2,2);R(x,'#1a1c1e',9,26,2,2);R(x,'#2a2e32',1,0,12,8);R(x,'#3a3e42',1,0,12,1);R(x,o.on?'#f4f8ff':'#4a4e52',2,2,10,4);}});
def('intercom',{w:12,h:24,box:[-3,-3,6,3],draw(x){R(x,'#3a3e44',5,10,2,14);R(x,'#2a2e34',1,0,10,12);R(x,'#4a4e54',1,0,10,1);R(x,'#141618',3,2,6,4);R(x,'#3a7a4a',3,7,2,2);R(x,'#9a9a92',6,7,3,1);R(x,'#9a9a92',6,9,3,1);}});
def('wire',{w:36,h:12,box:[-17,-5,34,5],draw(x){x.strokeStyle='#8a8e92';x.lineWidth=1;for(let i=0;i<5;i++){x.beginPath();x.ellipse(4+i*7,6,5,5,0,0,7);x.stroke();}R(x,'#5a5e62',0,10,36,1);}});
def('answerphone',{w:20,h:20,box:[-9,-6,18,6],draw(x){R(x,'#5a4230',1,8,18,6);R(x,'#6e523c',1,8,18,1);R(x,'#3f2e22',2,14,2,6);R(x,'#3f2e22',16,14,2,6);R(x,'#1e2024',3,3,14,6);R(x,'#2e3238',3,3,14,1);R(x,'#c03a2a',5,5,2,2);R(x,'#8aa',9,5,6,1);R(x,'#8aa',9,7,4,1);}});
def('bigplant',{w:36,h:42,box:[-6,-5,12,5],draw(x){R(x,'#7a5a42',12,32,12,10);R(x,'#8e6a4e',12,32,12,1);const r=RNG(9);for(let i=0;i<26;i++){const a=r()*Math.PI*2,d=4+r()*14;const cx=18+Math.cos(a)*d,cy=18+Math.sin(a)*d*.8;x.fillStyle=['#2e5a32','#3a7040','#24482a','#4a8a4a'][(r()*4)|0];x.beginPath();x.ellipse(cx,cy,5,2.5,a,0,7);x.fill();}}});
def('fern',{w:22,h:16,draw(x){const r=RNG(3);for(let i=0;i<14;i++){const a=-Math.PI+r()*Math.PI,d=3+r()*8;x.fillStyle=['#3a7040','#2e5a32','#4a8048'][(r()*3)|0];x.fillRect((11+Math.cos(a)*d)|0,(13+Math.sin(a)*d)|0,3,2);}}});
def('campbed',{w:30,h:14,box:[-14,-10,28,9],draw(x,o){R(x,'#4a5a3a',1,3,28,8);R(x,'#5a6a48',1,3,28,1);R(x,'#2e3226',2,11,2,3);R(x,'#2e3226',26,11,2,3);R(x,o.c||'#7a5a6a',8,4,20,6);R(x,'#d8d4c8',2,4,6,5);}});
def('pubbar',{w:64,h:26,box:[-31,-14,62,13],draw(x){R(x,'#4a2e1e',1,6,62,8);R(x,'#6a4430',1,6,62,1);R(x,'#3a2418',1,14,62,12);for(let i=6;i<62;i+=12)R(x,'#4a2e1e',i,16,8,8);for(let i=0;i<4;i++){R(x,'#c8a44a',14+i*8,0,2,7);R(x,'#e8d8b0',13+i*8,0,4,2);}R(x,'#d8c890',46,4,4,3);R(x,'#7a3a2a',52,3,3,4);}});
def('pubtable',{w:20,h:16,box:[-7,-6,14,6],draw(x){R(x,'#4a2e1e',3,2,14,7);R(x,'#6a4430',3,2,14,1);R(x,'#3a2418',9,9,2,7);R(x,'#3a2418',6,14,8,2);R(x,'#d8b060',5,3,3,4);}});
def('lantern',{w:8,h:12,draw(x,o){R(x,'#2a2a2a',2,0,4,2);R(x,'#3a3a3a',1,2,6,8);R(x,o.on?'#ffd890':'#4a4030',2,3,4,6);R(x,'#2a2a2a',1,10,6,2);}});
def('dome',{w:120,h:118,box:[-56,-34,112,34],draw(x){const s='#c8c2b0',sD='#a8a290',sL='#dcd6c4';
 R(x,sD,6,84,108,34);R(x,s,6,84,108,2);for(let i=10;i<112;i+=8){R(x,s,i,88,4,26);R(x,sL,i,88,1,26);}
 R(x,sD,22,60,76,26);R(x,s,22,60,76,2);for(let i=26;i<96;i+=7)R(x,s,i,64,3,20);
 x.fillStyle='#6a7a78';x.beginPath();x.ellipse(60,60,36,40,0,Math.PI,0);x.fill();x.fillStyle='#7a8a88';x.beginPath();x.ellipse(56,58,26,34,0,Math.PI,Math.PI*1.6);x.fill();
 for(let i=0;i<9;i++){const a=Math.PI+i*Math.PI/8;x.strokeStyle='#5a6a68';x.beginPath();x.moveTo(60,60);x.lineTo(60+Math.cos(a)*36,60+Math.sin(a)*40);x.stroke();}
 R(x,s,52,14,16,10);R(x,sL,52,14,16,1);for(let i=54;i<68;i+=4)R(x,sD,i,16,1,8);R(x,'#c8a44a',58,2,4,12);R(x,'#d8b860',57,0,6,3);}});
def('pubsign',{w:16,h:20,wall:true,draw(x){R(x,'#2a2a2a',7,0,2,4);R(x,'#1e3a2e',1,4,14,14);R(x,'#c8a44a',1,4,14,1);R(x,'#c8a44a',1,17,14,1);R(x,'#e8e0d0',5,8,6,5);R(x,'#ffd890',7,9,2,3);}});
// HD versions of key props
hd2('stall',(x,o)=>{R(x,'#4a3a2a',4,28,80,12);R(x,'#5e4a36',4,28,80,2);R(x,'#3a2e22',6,40,4,8);R(x,'#3a2e22',78,40,4,8);
 for(let i=0;i<5;i++){const bx=8+i*16;R(x,'#5a6066',bx,16,14,14);R(x,'#8a9096',bx,16,14,2);R(x,'#4a5056',bx+12,18,2,12);const rr=RNG(i*7+2);
  for(let k=0;k<9;k++){const fx=bx+1+((rr()*11)|0),fy=2+((rr()*12)|0);R(x,'#3a4a2a',fx+1,fy+3,1,16-fy);R(x,DEADF[(i+k)%7],fx,fy,3,3);R(x,sh(DEADF[(i+k)%7],.75),fx+1,fy+2,2,1);}}});
hd2('flood',(x,o)=>{R(x,'#1a1c1e',12,16,4,44);R(x,'#2a2e32',12,16,1,44);R(x,'#1a1c1e',4,56,20,4);R(x,'#1a1c1e',6,52,4,4);R(x,'#1a1c1e',18,52,4,4);
 R(x,'#2a2e32',2,0,24,16);R(x,'#4a4e52',2,0,24,2);R(x,o.on?'#f4f8ff':'#4a4e52',4,4,20,8);if(o.on){R(x,'#ffffff',6,5,16,6);}for(let i=4;i<24;i+=4)R(x,'#2a2e32',i,4,1,8);});
hd2('intercom',(x,o)=>{R(x,'#3a3e44',10,20,4,28);R(x,'#4a4e54',10,20,1,28);R(x,'#22262c',2,0,20,24);R(x,'#4a4e54',2,0,20,2);R(x,'#0e1012',5,3,14,10);R(x,'#1a2a3a',6,4,12,8);R(x,'#3a7a4a',6,16,4,4);R(x,'#7ad08a',7,17,2,2);for(let j=15;j<22;j+=2)R(x,'#7a7e84',12,j,7,1);});
hd2('answerphone',(x,o)=>{R(x,'#5a4230',2,16,36,12);R(x,'#6e523c',2,16,36,2);R(x,'#3f2e22',4,28,4,12);R(x,'#3f2e22',32,28,4,12);
 R(x,'#1e2024',6,4,28,13);R(x,'#3a3e44',6,4,28,2);R(x,'#c03a2a',9,8,4,4);R(x,'#ff6a5a',10,9,2,2);R(x,'#3a4a3a',16,8,14,5);R(x,'#8ad08a',17,9,3,3);R(x,'#8aa0a0',22,10,6,1);R(x,'#141618',26,14,6,2);});
hd2('bigplant',(x,o)=>{R(x,'#7a5a42',24,64,24,20);R(x,'#9a7656',24,64,24,2);R(x,'#5a4030',24,82,24,2);const r=RNG(9);for(let i=0;i<60;i++){const a=r()*Math.PI*2,d=6+r()*28;const cx=36+Math.cos(a)*d,cy=36+Math.sin(a)*d*.8;x.fillStyle=['#2e5a32','#3a7040','#24482a','#4a8a4a','#5a9a52'][(r()*5)|0];x.beginPath();x.ellipse(cx,cy,10,4,a,0,7);x.fill();x.strokeStyle='rgba(20,40,20,.5)';x.beginPath();x.moveTo(cx-Math.cos(a)*8,cy-Math.sin(a)*3);x.lineTo(cx+Math.cos(a)*8,cy+Math.sin(a)*3);x.stroke();}});
hd2('dome',(x,o)=>{x.save();x.scale(2,2);x.imageSmoothingEnabled=true;PROP.dome.draw(x,o);x.restore();});
// ---------- characters ----------
Object.assign(STY,{
 ellie:{skin:'#d2a688',hair:'#7a4a2a',hs:'long',coat:'#8a4a5a',coat2:'#6e3a48',pants:'#2a2a34',shoe:'#1a1a1a'},
 margaret:{skin:'#e2c0a8',hair:'#cfcfd8',hs:'bun',coat:'#4a5a7a',coat2:'#3a4862',pants:'#3a3a44',shoe:'#2a2020'},
 guard:{skin:'#b08060',hair:'#1a1a1a',hs:'cap',coat:'#1e2228',coat2:'#15181c',pants:'#1e2228',shoe:'#0e0e0e',hivis:1},
 desmond:{skin:'#7a4a34',hair:'#2a2a2a',hs:'short',coat:'#5a3a2a',coat2:'#472d20',pants:'#2a2a30',shoe:'#1a1a1a',beard:'#3a3a3a'},
 poppy:{skin:'#c89070',hair:'#3a2216',hs:'pony',coat:'#c87a9a',coat2:'#a8607e',pants:'#3a3a5a',shoe:'#e0e0e0'},
 c1:{skin:'#d8b096',hair:'#3a2a1e',hs:'short',coat:'#3a3f48',coat2:'#2c3038',pants:'#2c3038',shoe:'#121212'},
 c2:{skin:'#8a5a40',hair:'#121212',hs:'long',coat:'#2a3a5a',coat2:'#1e2c46',pants:'#1e2c46',shoe:'#3a1a1a'},
 c3:{skin:'#e0b8a0',hair:'#b8b8b8',hs:'short',coat:'#7a6a4a',coat2:'#625538',pants:'#4a4a50',shoe:'#2a2420'},
 c4:{skin:'#c49a7c',hair:'#5a3a22',hs:'pony',coat:'#4a6a5a',coat2:'#3a5448',pants:'#2a2e38',shoe:'#d8d8d8'},
 c5:{skin:'#6a4430',hair:'#101010',hs:'hood',coat:'#3a3a40',coat2:'#2c2c32',pants:'#22252a',shoe:'#e0e0e0'},
 c6:{skin:'#e4c0a6',hair:'#c8a060',hs:'bun',coat:'#9a4a3a',coat2:'#7a3a2e',pants:'#2a2a30',shoe:'#1a1a1a'},
});
Object.assign(WHO_COL,{ELLIE:'#d9a0b8',GUARD:'#9aa8b8',DESMOND:'#c8a070',POPPY:'#e8b0c8',MARGARET:'#a8b8d8',ROWAN:'#f4efe2',INTERCOM:'#9aa8b8',ANSWERPHONE:'#8f9aa6'});
Object.assign(VOICE,{ELLIE:1.4,GUARD:.8,DESMOND:.75,POPPY:1.7,MARGARET:1.2,INTERCOM:.85,ROWAN:1});
