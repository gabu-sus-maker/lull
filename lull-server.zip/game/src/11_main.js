Story.firstHollow=(h)=>S.firstHollow(h);Story.onKill=(h)=>S.onKill(h);
// ================= GAME STATE =================
const G={state:'boot',map:null,phase:null,flags:{},stats:{health:100,hunger:80,thirst:75,sanity:88,hum:0},inv:[],equip:null,notes:[],
 cut:false,modal:null,paused:false,time:0,dt:0,cam:{x:0,y:0},shake:0,shakeX:0,shakeY:0,hitstop:0,parts:[],bubbles:[],timers:[],waiters:[],phantoms:[],
 humNear:0,truthT:0,truthCD:6,truthNow:false,glitch:0,glitchCD:8,redFlash:0,whiteFlash:0,lull:null,lullAllowed:false,sanityOn:false,showHum:false,
 decay:{hunger:.008,thirst:.012},objective:'',hudVisible:true,clock:'',dog:null};
function resetGame(){Object.assign(G,{flags:{},stats:{health:100,hunger:78,thirst:72,sanity:88,hum:0},inv:[],equip:null,notes:[],cut:false,modal:null,paused:false,lull:null,lullAllowed:false,sanityOn:false,showHum:false,objective:'',timers:[],waiters:[],phantoms:[],extraBodies:null,glitch:0});P.battery=0;P.torch=false;Script.kill();}
// ================= INTERACTION =================
function labelOf(it){return typeof it.label==='function'?it.label():it.label;}
function findTarget(){
 const m=G.map,px=P.x+P.fx*10,py=P.y-5+P.fy*10;let best=null,bd=20;
 {const k=Math.floor(px/16)+','+Math.floor(py/16),k2=Math.floor(P.x/16)+','+Math.floor((P.y-14)/16);const kk=m.exits[k]?k:(P.dir===3&&m.exits[k2]?k2:null);
  if(kk){const ex=m.exits[kk];const [a,b2]=kk.split(',').map(Number);best={x:a*16+8,y:b2*16+18,label:ex.label,fn:()=>Script.run(ex.fn)};bd=kk===k?-6:2;}}
 for(const p of m.props){if(!p.interact||p.hidden)continue;let d;
  if(p.box){const cx=clamp(px,p.box.x0,p.box.x1),cy=clamp(py,p.box.y0,p.box.y1);d=dist(px,py,cx,cy);}else d=dist(px,py,p.x,p.y-4);
  if(p.d.wall)d=dist(px,py,p.x,p.y+10);
  if(d<bd){bd=d;best={x:p.x,y:p.box?p.box.y1:p.y,label:labelOf(p.interact),fn:p.interact.fn};}}
 for(const e of m.ents){if(!e.interact||e.dead||e.hidden)continue;const d=dist(px,py,e.x,e.y-5)-(e.kind==='npc'?6:0);if(d<bd+(e.kind==='npc'?4:0)){bd=d;best={x:e.x,y:e.y,label:labelOf(e.interact),fn:e.interact.fn};}}
 return best;}
// ================= STATS / SANITY =================
function updateStats(dt){
 const s=G.stats;if(G.lull)return;if(G.cut||(!G.coop&&G.modal&&G.modal!=='inv'))return;
 s.hunger=Math.max(0,s.hunger-G.decay.hunger*dt);s.thirst=Math.max(0,s.thirst-G.decay.thirst*dt);
 if(s.thirst<=0)hurtPlayer(.55*dt,'thirst',true);if(s.hunger<=0)hurtPlayer(.3*dt,'hunger',true);
 if(G.sanityOn){let drain=.012;const L=lightLevelAt(P.x,P.y-6);G.lightHere=L;
  if(L<.3)drain+=.5*(1-L/.3);
  let near=0;for(const e of G.map.ents){if(e.kind==='sleeper'&&dist(e.x,e.y,P.x,P.y)<44)near++;if(e.kind==='hollow'&&!e.dead&&(e.state==='chase'||e.state==='wind')&&dist(e.x,e.y,P.x,P.y)<90)drain+=.25;}
  drain+=Math.min(2,near)*.22;
  drain*=1-s.hum/170;
  if((typeof G.map.safe==='function'?G.map.safe():G.map.safe)&&L>.35)drain-=.35;
  s.sanity=clamp(s.sanity-drain*dt,0,100);}
 if(G.showHum){const target=G.sanityOn?100:30;if(s.hum<target)s.hum=Math.min(target,s.hum+(G.sanityOn?.012:.03)*dt);}
 if(G.sanityOn&&s.sanity<=0&&G.lullAllowed&&!G.lull&&G.state==='play'&&!G.cut)startLull();
 if(s.health<=0&&G.state==='play')die(G.lastCause||'hollow');
}
function spawnPhantom(){for(let i=0;i<8;i++){const a=rand(7),d=rand(85,140),x=P.x+Math.cos(a)*d,y=P.y+Math.sin(a)*d;if(blocked(G.map,x,y,4,4,null))continue;if(lightLevelAt(x,y-8)>.35)continue;G.phantoms.push({x,y,t:0,life:rand(1.5,3.5)});return;}}
function updateSanityFx(dt){
 G.glitch-=dt;G.truthT-=dt;
 for(const f of G.phantoms){f.t+=dt;if(P.torch){const a=Math.atan2(f.y-P.y,f.x-P.x)-Math.atan2(P.fy,P.fx);const aa=Math.abs(Math.atan2(Math.sin(a),Math.cos(a)));if(aa<.45&&dist(f.x,f.y,P.x,P.y)<130)f.t=Math.max(f.t,f.life-.15);}}
 G.phantoms=G.phantoms.filter(f=>f.t<f.life);
 if(!G.sanityOn||G.lull||G.state!=='play'){G.truthNow=G.lull?G.truthNow:false;return;}
 const s=G.stats.sanity;
 if(s<55){G.glitchCD-=dt;if(G.glitchCD<=0){G.glitch=rand(.08,.2+(55-s)/180);G.glitchK=1+(55-s)/30;G.glitchCD=rand(3,12)*(s/55)+1.2;Snd.play('glitch');if(Math.random()<.45)UI.hudGlitch(.45);}}
 if(s<45){G.truthCD-=dt;if(G.truthCD<=0){G.truthT=rand(.07,.16)+(45-s)/220;G.truthCD=rand(3,9)*(s/45)+1.4;if(Math.random()<.5){G.glitch=Math.max(G.glitch,G.truthT);}if(s<30&&Math.random()<.4)Snd.play('flies');}}
 G.truthNow=G.truthT>0;
 if(s<50&&Math.random()<dt*.09*(1-s/50))spawnPhantom();
 if(s<40&&Math.random()<dt*.07)Snd.play('whisper');
 if(s<25&&Math.random()<dt*.05)Snd.play('step',{s:'road',v:.6});
 if(s<20&&Math.random()<dt*.04)UI.thought(pick(['this isn’t right','wake up','it’s lying','LOOK']),1.6);
 Snd.dronePitch(.9+s/1000);
}
// ================= THE LULL =================
function startLull(){
 G.lull={t:0,warm:0,amb:1,tear:0,full:0,rgb:0,slice:0,close:0,slow:.7,truthHud:false,scramble:0,ev:{},hb:0,flashT:0,bodyT:13};
 Script.kill();UI.closeDlg();P.torch=false;P.swing=-1;G.glitch=0;G.phantoms=[];G.truthNow=false;
 G.whiteFlash=1;Snd.set('drone',0,.5);Snd.set('rain',.04,1);Snd.set('wind',0,1);Snd.set('static',0,.2);Snd.set('fire',0,1);Snd.humPitch(1);
 Snd.song(MEL_LULL,96,{v:.06});
 G.extraBodies=[];murmur('There.',3);
}
function updateLull(dt){
 const L=G.lull;L.t+=dt;const t=L.t;const ev=k=>{if(L.ev[k])return false;L.ev[k]=1;return true;};
 G.whiteFlash=Math.max(0,G.whiteFlash-dt*.6);
 L.warm=clamp(t/3,0,1);L.amb=lerp(1,.42,clamp(t/4,0,1));
 G.stats.sanity=0;
 if(t>3&&ev('a'))murmur('Isn’t that better?',4);
 if(t>7&&ev('b'))murmur('Everything is fine now. You don’t have to be afraid any more.',5);
 if(t>13&&ev('c'))murmur('You can rest soon. Everyone is resting.',4.5);
 // bodies appear, lying peacefully all around
 if(t>10&&t<50){L.bodyT-=dt;if(L.bodyT<=0){L.bodyT=rand(.5,1.3)*(t>34?.5:1);for(let i=0;i<8;i++){const a=rand(7),d=rand(26,110),x=P.x+Math.cos(a)*d,y=P.y+Math.sin(a)*d;if(!blocked(G.map,x,y,6,3,null)&&x>8&&y>8&&x<G.map.w*16-8&&y<G.map.h*16-8){G.extraBodies.push(new Sleeper(x,y,pick(['p1','p2','p3','p4','p5','t1','t2','t3','jogger']),{pose:Math.random()<.85?'lie':'sit',smile:true,dir:0}));break;}}}}
 if(t>16&&t<16.1)L.full=1;else if(t>16.1&&t<16.3)L.full=0;
 if(t>16&&ev('hud1')){L.truthHud=true;setTimeout(()=>{if(G.lull)L.truthHud=false;},250);}
 if(t>20&&ev('d'))murmur('Everything is fine.',3);
 if(t>22&&ev('fig1'))G.phantoms.push({x:P.x+P.fx*110,y:P.y+P.fy*80+10,t:0,life:2.2});
 if(t>25)Snd.seq&&(Snd.seq.detRate=7);
 if(t>27&&ev('e')){murmur('Everything is fine.',3);UI.thought('this isn’t fine',3);}
 if(t>30&&t<54){L.tear=clamp((t-30)/20,0,.6);L.scramble=clamp((t-30)/40,0,.35);}
 if(t>30&&t<54){L.flashT-=dt;if(L.flashT<=0){L.flashT=rand(1.4,3)*(t>40?.6:1);L.full=1;L.fullT=rand(.06,.14)+(t>44?.25:0);}}
 if(L.full&&L.fullT!==undefined){L.fullT-=dt;if(L.fullT<=0){L.full=0;L.fullT=undefined;}}
 if(t>31&&ev('w1'))Snd.play('whisper');
 if(t>34&&ev('f')){UI.murmur(corrupt('Everything is fine. Everything is fine. Everything is',.12),4);}
 if(t>36&&ev('fig2')){for(let i=0;i<5;i++){const a=i/5*7+rand(.4),d=rand(95,130);G.phantoms.push({x:P.x+Math.cos(a)*d,y:P.y+Math.sin(a)*d,t:0,life:rand(5,9)});}}
 if(t>36&&t<50&&Math.random()<dt*1.2)Snd.play('step',{s:'road',v:.7});
 if(t>38&&ev('g'))UI.thought('WAKE UP',2.2);
 if(t>40&&t<54){L.rgb=clamp((t-40)/10,0,.5);L.slice=clamp((t-40)/12,0,.35);if(Math.random()<dt*.5)Snd.play('whisper');}
 if(t>40){L.hb-=dt;if(L.hb<=0){L.hb=t<52?1.1:1.9;Snd.play('heart');}}
 if(t>44&&ev('h')){murmur('You should lie down.',4);L.slow=.35;}
 if(t>48&&ev('i'))UI.thought('get up get up GET UP',2);
 if(t>50){L.close=clamp((t-50)/9,0,1);}
 if(t>52&&ev('j')){P.pose='lie';murmur('There. Rest now.',4);}
 if(t>54){L.tear=lerp(L.tear,0,dt*2);L.rgb=lerp(L.rgb,0,dt*2);L.slice=lerp(L.slice,0,dt*2);L.full=0;L.scramble=0;}
 if(t>54&&ev('k')){Snd.stopSong();Snd.play('box',{f:523.25,v:.05,det:-40});}
 if(t>56&&ev('k2'))Snd.play('box',{f:440,v:.04,det:-80});
 if(t>57&&ev('l'))murmur('Goodnight.',3);
 if(t>59.5&&ev('m')){UI.fade(1,1.6);Snd.set('hum',0,1.5);}
 if(t>61.5&&ev('n')){G.lull=null;G.extraBodies=null;die('lull');}
}
// ================= DEATH =================
function die(cause){
 if(G.state!=='play')return;G.state='dead';P.torch=false;Script.kill();UI.closeDlg();Snd.stopSong();
 if(cause!=='lull'){Snd.play('death');UI.fade(1,1.8);}
 UI.hudOn(false);UI.prompt(null);
 const t={hollow:['ROWAN DIED.','Killed in the dark.'],thirst:['ROWAN DIED.','Dehydration.'],hunger:['ROWAN DIED.','Starvation.'],lull:['ROWAN FELL ASLEEP.','Smiling.']}[cause]||['ROWAN DIED.',''];
 setTimeout(()=>{UI.fade(0,.01);UI.modal(`<div class="death" style="text-align:center"><h1>${t[0]}</h1><p>${t[1]}</p><div class="menu" id="dm"></div></div>`,'death');$('#modal').style.background='#000';
  UI.menu([{t:'Continue from last safe point',id:'c'},{t:'Quit to title',id:'q'}],0,id=>{$('#modal').style.background='';UI.closeModal();if(id==='c'){Game.fromCheckpoint();}else Game.toTitle();},'#dm');},cause==='lull'?600:2000);
}
// ================= TITLE / GAME =================
const Game={
 toTitle(){Script.kill();G.state='title';G.lull=null;G.extraBodies=null;G.paused=false;UI.closeModal();UI.closeDlg();UI.hudOn(false);UI.prompt(null);UI.objective('');$('#card').classList.remove('on');
  G.phase='title';loadPhase('title');P.hidden=true;G.cam.x=tx(10);G.cam.y=ty(14);UI.fade(0,1.2);
  Snd.set('hum',0,1);Snd.set('rain',.4,2);Snd.set('drone',.07,2);Snd.dronePitch(1);Snd.song(MEL_TITLE,62,{v:.045});
  const sv=store('lull_save');
  const t=$('#title');t.classList.remove('hidden');t.innerHTML=`<h1 id="tt">LULL</h1><div class="sub">A London story</div><div class="menu" id="tm"></div><div class="ver">THE COMPLETE STORY · FOUR ENDINGS</div>`;
  const items=[{t:'New game',id:'n'},{t:'Continue',id:'c',dis:!sv},{t:'Controls',id:'k'},{t:'Graphics: '+resLabel(),id:'g'}];if(Game.extraTitle)items.splice(2,0,...Game.extraTitle());
  UI.menu(items,sv?1:0,id=>{
   if(Game.onTitlePick&&Game.onTitlePick(id))return;
   if(id==='k'){UI.controls();UI.onModalClose=()=>Game.titleMenu();return;}
   if(id==='g'){toggleRes();Game.toTitle();UI._menu.sel=UI._menu.items.findIndex(i=>i.id==='g');UI.menuDraw();return;}
   t.classList.add('hidden');Snd.stopSong();
   if(id==='n'){resetGame();storeDel('lull_save');G.state='play';Story.goto('d1_wake',{});}
   if(id==='c'){resetGame();UI.fade(1,.5,()=>{Story.restore(sv);UI.fade(0,.9);});}},'#tm');
  this._tm=UI._menu;},
 titleMenu(){if(G.state!=='title')return;UI._menu=this._tm;UI.menuDraw();},
 fromCheckpoint(){const cp=G.checkpointData||store('lull_save');if(!cp){Game.toTitle();return;}UI.fade(1,.01);G.state='play';Story.restore(cp);UI.fade(0,1);},
};
// ================= MAIN LOOP =================
function update(dt){
 G.time+=dt;G.dt=dt;Snd.update(dt);
 // timers
 if(!G.paused&&G.state!=='dead'){const ts=G.timers;G.timers=[];for(const tm of ts){tm.t-=dt;if(tm.t<=0)tm.fn();else G.timers.push(tm);}
  const ws=G.waiters;G.waiters=[];for(const w of ws){if(w.cond())w.fn();else G.waiters.push(w);}}
 if(UI.cu)UI.cuDraw(dt);
 if(UI._rstep)UI._rstep(dt);
 if(NetUI.open)NetUI.tick(dt);
 if(G.state==='title'){UI.menuKeys();if(G.modal==='ctrl'&&Input.hit('ok'))UI.closeModal();G.cam.x+=dt*9;if(G.cam.x>tx(54))G.cam.x=tx(8);G.map&&G.map.ents.forEach(e=>e.update&&e.update(dt));updateParticles(dt);if(Math.random()<dt*.3){$('#tt')&&$('#tt').classList.remove('g');void($('#tt')||{}).offsetWidth;$('#tt')&&$('#tt').classList.add('g');}return;}
 if(G.state==='dead'||G.state==='end'){UI.menuKeys();return;}
 if(G.coop)NetGame.preInput(dt);
 if(G.modal==='pause'){UI.menuKeys();if(Input.hit('pause')){UI.closeModal();G.paused=false;}if(!G.coop)return;}
 else if(G.modal==='ctrl'){if(Input.hit('ok')||Input.hit('pause'))UI.closeModal();if(!G.coop)return;}
 if(G.modal==='inv'){UI.invKeys();}
 else if(G.modal==='note'){UI.noteKeys();}
 else if(G.modal==='phone'){if(Input.hit('ok')){Input.eat('ok');UI.closeModal();}}
 UI.updDlg(dt);
 if(G.hitstop>0){G.hitstop-=dt;return;}
 if(canAct()){
  if(Input.hit('inv'))UI.inv();else if(Input.hit('note'))UI.notebook();else if(Input.hit('pause'))UI.pause();
  else for(let i=0;i<5;i++)if(Input.hit('s'+(i+1))&&G.inv[i])useItem(G.inv[i].id);}
 G.humNear=0;
 // short grace after any conversation/announcement so nothing hits you the instant it closes
 {const busy=!!(G.cut||(G.modal&&G.modal!=='inv'));if(G.wasBusy&&!busy)P.graceT=1.2;G.wasBusy=busy;P.graceT-=dt;}
 updatePlayer(dt);
 if(G.coop)NetGame.tick(dt);
 unstick(dt);
 for(const e of G.map.ents.slice())e.update(dt);
 if(G.map.tick)G.map.tick(dt);
 if(G.extraBodies)for(const e of G.extraBodies)e.update(dt);
 // zones
 for(const z of G.map.zones){if(z.done)continue;if(P.x>z.x&&P.x<z.x+z.w&&P.y>z.y&&P.y<z.y+z.h&&!G.cut){if(z.once)z.done=true;const r=z.fn();if(r&&r.next)Script.run(r);}}
 // interaction
 // walking into a doorway uses it
 {const k=Math.floor(P.x/16)+','+Math.floor((P.y-1)/16);const ex=G.map.exits[k];if(ex&&canAct()&&!G.lull&&P.moving&&!Script.busy()){if(G.lastExit!==k){G.lastExit=k;Script.run(ex.fn);}}else if(!ex)G.lastExit=null;}
 const tgt=canAct()&&!G.lull&&!P.pose&&!Script.busy()?findTarget():null;UI.prompt(tgt);
 if(tgt&&Input.hit('interact')&&!Script.busy()){Input.eat('interact');tgt.fn();}
 if(G.flags.ringing&&!G.flags.ellie_call){G.ringT-=dt;if(G.ringT<=0){Snd.play('ring',{n:1});G.ringT=3.2;}}
 updateStats(dt);updateSanityFx(dt);if(G.lull)updateLull(dt);
 updateParticles(dt);
 // camera
 const k=1-Math.exp(-dt*5);G.cam.x=lerp(G.cam.x,P.x+P.fx*12,k);G.cam.y=lerp(G.cam.y,P.y-10+P.fy*8,k);
 G.shake=Math.max(0,G.shake-dt*18);G.shakeX=G.shake?rand(-G.shake,G.shake):0;G.shakeY=G.shake?rand(-G.shake,G.shake):0;
 G.redFlash=Math.max(0,G.redFlash-dt*1.5);if(!G.lull)G.whiteFlash=Math.max(0,G.whiteFlash-dt*2);
 mirrorHist.unshift({dir:P.dir,x:P.x});if(mirrorHist.length>20)mirrorHist.pop();
 // sound
 const hv=G.showHum?(G.lull?.11:.012+G.stats.hum/100*.045+G.humNear*.05):0;Snd.set('hum',hv,.6);
 if(G.showHum&&!G.lull)Snd.humPitch(1+G.humNear*.04);
 UI.hud();UI.bubbles();for(const b of G.bubbles)b.t-=dt;
}
let last=performance.now();
function frame(now){const dt=Math.min(.05,(now-last)/1000);last=now;try{update(dt);render();}catch(e){console.error(e);}Input.end();requestAnimationFrame(frame);}
function boot(){
 buildTiles();buildHollow();buildHollow2();buildIcons();buildIconCanvases();buildFx();UI.layout();addEventListener('resize',()=>UI.layout());
 Game.toTitle();requestAnimationFrame(frame);
 window.LULL={G,P,Story,Script,Snd,loadPhase,Game,startLull,die};
}

// push the player out of walls/solid furniture if they ever end up inside one
function stuckIn(m,x,y){const x0=x-P.hw,x1=x+P.hw-.01,y0=y-P.hh,y1=y-.01;
 if(m.solidAt(x0,y0)||m.solidAt(x1,y0)||m.solidAt(x0,y1)||m.solidAt(x1,y1))return true;
 for(const b of m.solids)if(x1>b.x0&&x0<b.x1&&y1>b.y0&&y0<b.y1)return true;return false;}
function unstick(){const m=G.map;if(!m||G.state!=='play'||G.cut||P.pose||!stuckIn(m,P.x,P.y))return;
 for(let r=2;r<=48;r+=2)for(let a=0;a<16;a++){const nx=P.x+Math.cos(a*Math.PI/8)*r,ny=P.y+Math.sin(a*Math.PI/8)*r;if(!stuckIn(m,nx,ny)){P.x=nx;P.y=ny;return;}}}
