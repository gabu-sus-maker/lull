// ================= STAGE 2 ART =================
// ---------- tiles ----------
tile('deck',{step:'wood',draw(x,r){R(x,'#3a2c20',0,0,16,16);for(let y=0;y<16;y+=3){R(x,['#5a4434','#634a37','#55402f'][(r()*3)|0],0,y,16,2);}R(x,'#2a1f16',0,0,1,16);R(x,'#2a1f16',15,0,1,16);speck(x,r,['#4a3626','#70543f'],10);}});
tile('lockBeam',{step:'wood',draw(x,r){R(x,'#111d24',0,0,16,16);R(x,'#3a2c20',0,3,16,10);R(x,'#5a4434',0,3,16,2);R(x,'#2a1f16',0,11,16,2);R(x,'#d8d4c8',0,5,2,6);R(x,'#d8d4c8',14,5,2,6);speck(x,r,['#4a3626'],6,0,4,16,8);}});
tile('lockWall',{solid:true,draw(x,r){R(x,'#4a4d50',0,0,16,16);speck(x,r,['#55585b','#3e4144'],20);R(x,'#3a3d40',0,0,16,1);R(x,'#3a3d40',0,8,16,1);R(x,'#3a3d40',8,0,1,8);}});
tile('gateIron',{solid:false,opaque:false,exit:true,draw(x,r){brick(x,r);R(x,'#3c3f44',0,0,3,16);R(x,'#3c3f44',13,0,3,16);R(x,'#4e5257',0,0,3,1);R(x,'#4e5257',13,0,3,1);R(x,'#3d3832',3,0,10,16);speck(x,r,['#4d473f','#2f2b26'],12,3,0,10,16);for(let i=3;i<13;i+=3)R(x,'#121417',i,0,1,5);R(x,'#121417',3,4,10,1);}});
tile('stationGate',{solid:true,opaque:true,draw(x,r){R(x,'#5f6468',0,0,16,16);R(x,'#2f8a83',0,3,16,2);R(x,'#0a0c0e',1,6,14,10);for(let i=2;i<15;i+=3)R(x,'#3a3e44',i,6,1,10);R(x,'#3a3e44',1,9,14,1);R(x,'#3a3e44',1,13,14,1);R(x,'#b8b8b0',6,10,4,1);R(x,'#9a9a92',7,11,2,2);}});
tile('hlino',{step:'tile',draw(x,r){R(x,'#8aa29d',0,0,16,16);speck(x,r,['#93aaa5','#7f9692','#9db3ae'],36);R(x,'#7f9591',0,0,16,1);R(x,'#7f9591',0,0,1,16);}});
tile('hlinoD',{step:'tile',draw(x,r){R(x,'#5f6f6c',0,0,16,16);speck(x,r,['#677774','#56655f','#4a5652'],40);R(x,'#55625f',0,0,16,1);if(r()<.3){R(x,'rgba(40,30,20,.4)',(r()*10)|0,(r()*10)|0,5,3);}}});
tile('HW',{solid:true,opaque:true,wall:true,top(x,r){R(x,'#121518',0,0,16,16);speck(x,r,['#161a1d','#0f1214'],10);},face(x,r){R(x,'#7f948c',0,8,16,8);R(x,'#93a89f',0,8,16,1);R(x,'#3f7d78',0,12,16,2);R(x,'#c9d1cb',0,14,16,1);R(x,'#6f8078',0,15,16,1);speck(x,r,['#879c94'],6,0,9,16,3);}});
tile('HWin',{solid:true,opaque:false,wall:true,top(x,r){TL[T.HW].top(x,r);R(x,'#2c3a44',2,6,12,2);},face(x,r){TL[T.HW].face(x,r);R(x,'#d8d2c4',2,8,12,5);R(x,'#344452',3,9,10,3);R(x,'#556878',3,9,10,1);}});
tile('exitH',{solid:false,opaque:true,wall:true,exit:true,step:'tile',top(x,r){TL[T.HW].top(x,r);},face(x,r){TL[T.HW].face(x,r);R(x,'#1a1d20',2,7,12,9);R(x,'#9aa4a8',3,8,5,8);R(x,'#9aa4a8',8,8,5,8);R(x,'#2a3a44',4,9,3,3);R(x,'#2a3a44',9,9,3,3);R(x,'#c8cccc',7,12,2,1);}});
tile('bconc',{draw(x,r){R(x,'#3a3d40',0,0,16,16);speck(x,r,['#42454a','#33363a','#2c2f32'],40);if(r()<.25)R(x,'rgba(30,25,15,.45)',(r()*10)|0,(r()*12)|0,6,4);}});
tile('BW',{solid:true,opaque:true,wall:true,top(x,r){R(x,'#111315',0,0,16,16);},face(x,r){R(x,'#4c5054',0,8,16,8);R(x,'#5a5e62',0,8,16,1);R(x,'#2e3236',0,10,16,2);R(x,'#3c4044',0,10,16,1);R(x,'#6a5a3a',0,13,16,1);speck(x,r,['#55595d','#43474b'],8,0,9,16,6);}});
tile('stairsDn',{solid:false,exit:true,step:'hard',draw(x,r){for(let y=0;y<16;y+=3){R(x,'#4a4e52',0,y,16,2);R(x,'#1a1c1f',0,y+2,16,1);}R(x,'#2a2d30',0,0,2,16);R(x,'#2a2d30',14,0,2,16);R(x,'rgba(0,0,0,.35)',0,8,16,8);}});
tile('stairsUpT',{solid:false,exit:true,step:'hard',draw(x,r){for(let y=0;y<16;y+=3){R(x,'#5a5e62',0,y,16,2);R(x,'#2a2d30',0,y+2,16,1);}R(x,'#2a2d30',0,0,2,16);R(x,'#2a2d30',14,0,2,16);R(x,'rgba(255,255,255,.06)',0,0,16,6);}});
// tube
tile('ballast',{step:'gravel',draw(x,r){R(x,'#2a2622',0,0,16,16);speck(x,r,['#35302a','#211e1b','#3c3630','#2e2a26'],60);}});
const sleepers=(x,r)=>{for(let i=1;i<16;i+=5){R(x,'#3a2e24',i,0,3,16);R(x,'#2a2018',i+2,0,1,16);}};
tile('trackA',{step:'gravel',draw(x,r){TL[T.ballast].draw(x,r);sleepers(x,r);R(x,'#5a5f64',0,12,16,2);R(x,'#9aa0a6',0,12,16,1);}});
tile('trackB',{step:'gravel',draw(x,r){TL[T.ballast].draw(x,r);sleepers(x,r);R(x,'#5a5f64',0,2,16,2);R(x,'#9aa0a6',0,2,16,1);R(x,'#6a6e72',0,13,16,2);R(x,'#c8c4b0',0,13,16,1);}});
tile('TW',{solid:true,opaque:true,wall:true,top(x,r){R(x,'#0d0f11',0,0,16,16);speck(x,r,['#121416','#0a0b0c'],12);},face(x,r){R(x,'#2c2f33',0,8,16,8);R(x,'#383c41',0,8,16,1);R(x,'#1a1c1f',4,8,1,8);R(x,'#1a1c1f',12,8,1,8);R(x,'#141618',0,11,16,1);R(x,'#141618',0,13,16,1);R(x,'#5a4a2a',0,12,16,1);speck(x,r,['#33373c','#25282c'],8,0,9,16,6);}});
tile('plat',{step:'tile',draw(x,r){R(x,'#5a5c5e',0,0,16,16);speck(x,r,['#626466','#525456','#6a6c6e'],30);R(x,'#4e5052',0,0,16,1);R(x,'#4e5052',0,0,1,16);}});
tile('platEdge',{step:'tile',draw(x,r){TL[T.plat].draw(x,r);for(let i=0;i<16;i+=2)for(let j=6;j<10;j+=2)R(x,'#7a7c7e',i,j,1,1);R(x,'#d8c040',0,11,16,2);R(x,'#8a8c8e',0,13,16,2);R(x,'#1a1a1a',0,15,16,1);}});
tile('PW',{solid:true,opaque:true,wall:true,top(x,r){R(x,'#121416',0,0,16,16);},face(x,r){for(let i=0;i<16;i+=4)for(let j=8;j<16;j+=2)R(x,(i+j)%3?'#d8d0b8':'#cfc6ac',i,j,4,2);R(x,'#a8a088',0,8,16,1);R(x,'#7a2a2a',0,11,16,1);speck(x,r,['#b8b098','#a09880'],8,0,9,16,6);}});
tile('trainFl',{step:'tile',draw(x,r){R(x,'#3a4a5a',0,0,16,16);speck(x,r,['#42526a','#34445a'],24);R(x,'#c8b040',0,0,16,1);R(x,'#c8b040',0,15,16,1);}});
tile('trainW',{solid:true,opaque:false,wall:true,top(x,r){R(x,'#b8bcc0',0,0,16,16);R(x,'#c03a32',0,5,16,2);R(x,'#d8dcdf',0,0,16,1);R(x,'#8a8e92',0,15,16,1);},face(x,r){R(x,'#b8bcc0',0,0,16,8);R(x,'#c03a32',0,5,16,2);R(x,'#1c2833',0,8,16,6);R(x,'#2a3a48',1,9,6,2);R(x,'#9aa0a6',7,8,2,6);R(x,'#2a3a7a',0,14,16,2);}});
tile('trainGap',{step:'hard',draw(x,r){R(x,'#121416',0,0,16,16);for(let y=0;y<16;y+=2)R(x,'#1e2124',0,y,16,1);}});
tile('voidS',{solid:true,opaque:true,draw(x){R(x,'#050607',0,0,16,16);}});
// ---------- props ----------
const BOATC=[['#2c4a3a','#c8a040'],['#7a2a26','#d8c070'],['#24364a','#d8b84a'],['#3a2c4a','#c8a040']];
def('boat',{w:100,h:26,box:[-48,-18,96,16],draw(x,o){const [hc,tr]=BOATC[o.c||0];
 R(x,'#0a0c0e',2,20,96,4);R(x,hc,0,8,98,14);R(x,sh(hc,1.2),0,8,98,1);R(x,tr,0,12,98,1);R(x,sh(hc,.7),0,18,98,4);
 R(x,hc,94,10,6,10);R(x,sh(hc,.8),98,12,2,6);R(x,'#1a1a1a',0,12,4,6);
 R(x,sh(hc,1.1),8,2,72,8);R(x,sh(hc,1.25),8,2,72,1);for(let i=12;i<76;i+=10){R(x,'#121a20',i,4,5,3);R(x,'#2a3a46',i,4,2,1);}
 if(!o.dirty){R(x,'#4a7a3a',20,0,3,3);R(x,'#a03a2a',24,0,3,3);R(x,'#5a4030',60,0,10,2);}else{R(x,'#2a2622',40,0,14,2);R(x,'rgba(30,25,20,.35)',0,2,100,20);}
 R(x,'#2a2a2a',82,4,2,6);R(x,'#3a2c20',84,3,8,1);}});
def('tent',{w:30,h:22,box:[-13,-10,26,10],draw(x,o){const c=o.c||'#4a5a3a';x.fillStyle=c;x.beginPath();x.moveTo(15,1);x.lineTo(29,21);x.lineTo(1,21);x.closePath();x.fill();x.fillStyle=sh(c,.7);x.beginPath();x.moveTo(15,1);x.lineTo(29,21);x.lineTo(18,21);x.closePath();x.fill();R(x,'#0e1012',13,12,4,9);R(x,sh(c,1.3),14,2,1,6);}});
def('brazier',{w:12,h:18,box:[-5,-5,10,5],draw(x){R(x,'#2a2622',2,6,8,10);R(x,'#3a342e',2,6,8,1);for(let i=3;i<10;i+=2)R(x,'#151311',i,8,1,6);R(x,'#1a1816',3,15,2,3);R(x,'#1a1816',7,15,2,3);R(x,'#d86a2a',3,4,6,2);R(x,'#ffb347',4,3,4,1);}});
def('cage',{w:32,h:34,box:[-15,-12,30,12],draw(x,o){R(x,'#1a1c1f',1,30,30,4);for(let i=1;i<32;i+=4)R(x,'#3a3e44',i,4,1,28);R(x,'#4a4e54',1,4,30,2);R(x,'#3a3e44',1,16,30,1);R(x,'#4a4e54',1,30,30,2);R(x,'#5a5e64',1,4,30,1);if(o.v==='open'){R(x,'#0a0c0e',12,6,8,24);R(x,'#3a3e44',20,6,1,24);}else{R(x,'#9a8a3a',14,17,4,3);}}});
def('pallets',{w:34,h:18,box:[-16,-8,32,8],draw(x){for(let j=0;j<3;j++){R(x,'#7a6242',1,2+j*5,32,3);R(x,'#8e744e',1,2+j*5,32,1);for(let i=2;i<33;i+=10)R(x,'#5a4630',i,2+j*5,3,4);}R(x,'#4a3a28',1,16,32,2);}});
def('jerry',{w:10,h:12,box:[-4,-4,8,4],draw(x){R(x,'#7a2a24',1,2,8,10);R(x,'#9a3a30',1,2,8,1);R(x,'#2a2a2a',3,0,4,2);}});
def('recdesk',{w:50,h:24,box:[-24,-14,48,13],draw(x){R(x,'#c9cdca',1,4,48,9);R(x,'#dfe2df',1,4,48,1);R(x,'#7f948c',1,13,48,11);R(x,'#6a7e76',1,13,48,1);for(let i=5;i<48;i+=12)R(x,'#738880',i,15,1,9);R(x,'#17191c',30,0,12,6);R(x,'#3a5a7a',31,1,10,4);R(x,'#e8e4d8',8,6,8,5);R(x,'#c03a2a',20,7,3,2);}});
def('hbed',{w:24,h:36,box:[-11,-30,22,30],draw(x,o){R(x,'#9aa4a8',1,0,22,4);R(x,'#c8ccd0',1,0,22,1);R(x,'#e2e4e2',2,4,20,28);R(x,'#ececea',4,5,16,6);R(x,o.c||'#8aa6c0',2,13,20,18);R(x,sh(o.c||'#8aa6c0',.8),2,29,20,2);R(x,'#9aa4a8',0,6,1,26);R(x,'#9aa4a8',23,6,1,26);R(x,'#5a6266',2,32,2,4);R(x,'#5a6266',20,32,2,4);}});
def('chairs',{w:42,h:16,box:[-20,-6,40,6],draw(x){for(let i=0;i<4;i++){R(x,'#3a6a8a',1+i*10,1,9,6);R(x,'#4a7a9a',1+i*10,1,9,1);R(x,'#2e5a76',1+i*10,7,9,4);}R(x,'#5a6266',1,11,40,2);R(x,'#3a3e42',3,13,2,3);R(x,'#3a3e42',37,13,2,3);}});
def('nboard',{w:32,h:18,wall:true,draw(x){R(x,'#6a4a30',0,0,32,18);R(x,'#a08060',2,2,28,14);[[4,4,6,7,'#e8e4d8'],[12,3,7,6,'#f0e8a0'],[21,4,7,8,'#e8e4d8'],[5,11,8,4,'#d8e8f0'],[15,10,5,5,'#f8d0d0']].forEach(([a,b,w,h,c])=>{R(x,c,a,b,w,h);R(x,'#c03a2a',a+(w>>1),b,1,1);});R(x,'#2a2a3a',22,6,5,1);R(x,'#2a2a3a',22,8,4,1);}});
def('vending',{w:18,h:30,box:[-8,-8,16,8],draw(x,o){R(x,'#2a2e33',0,0,18,30);R(x,o.on?'#cfe0e8':'#141a20',2,2,10,22);for(let j=0;j<4;j++)for(let i=0;i<3;i++)R(x,['#c03a2a','#3a7aba','#e0a030','#3a9a5a'][(i+j)%4],3+i*3,4+j*5,2,3);R(x,'#3a3e44',13,4,3,8);R(x,'#0a0a0a',3,25,10,3);}});
def('trolley',{w:20,h:16,box:[-9,-6,18,6],draw(x){R(x,'#b8bcc0',1,2,18,3);R(x,'#9aa0a4',1,8,18,2);R(x,'#7a8085',2,2,1,10);R(x,'#7a8085',17,2,1,10);R(x,'#2a2a2a',2,12,3,3);R(x,'#2a2a2a',15,12,3,3);R(x,'#e8e4d8',4,0,6,2);R(x,'#c03a2a',12,0,4,2);}});
def('pshelf',{w:16,h:24,box:[-8,-8,16,8],draw(x,o){R(x,'#d0d4d2',0,0,16,24);for(let s=0;s<3;s++){R(x,'#a8acaa',0,6+s*6,16,1);for(let i=1;i<15;i+=3)if((s*5+i)%7!==0||o.v!=='empty')R(x,o.v==='empty'?'#d0d4d2':['#e8e8e4','#f0f0ec','#c8d8e8','#e8d8c8'][(i+s)%4],i,2+s*6,2,4);}R(x,'#8a8e8c',0,22,16,2);}});
def('bench3',{w:34,h:20,box:[-16,-10,32,10],draw(x){R(x,'#5a4a36',1,4,32,8);R(x,'#6e5a42',1,4,32,1);R(x,'#3a3226',1,12,32,8);R(x,'#9aa0a4',4,1,8,3);R(x,'#c03a2a',14,1,4,3);R(x,'#7a7e82',22,2,8,2);}});
def('tseat',{w:32,h:10,box:[-16,-5,32,5],draw(x,o){R(x,'#2a3a6a',0,1,32,8);for(let i=0;i<32;i+=4){R(x,'#c83a3a',i,3,2,1);R(x,'#d8b040',i+2,6,1,1);}R(x,'#1a2a4a',0,8,32,2);for(let i=0;i<32;i+=8)R(x,'#1a2040',i,1,1,8);}});
def('elight',{w:8,h:6,wall:true,draw(x){R(x,'#2a1414',0,0,8,6);R(x,'#c83020',1,1,6,3);R(x,'#ff6040',2,1,3,1);}});
def('nameplate',{w:44,h:10,wall:true,draw(x){R(x,'#e8e4d8',0,0,44,10);R(x,'#c03a2a',0,0,44,2);R(x,'#c03a2a',0,8,44,2);R(x,'#1a2a6a',4,3,36,4);for(let i=6;i<38;i+=3)R(x,'#e8e4d8',i,4,2,2);}});
def('toolsBench',{w:36,h:20,box:[-17,-10,34,10],draw(x){R(x,'#4a3a2a',1,4,34,8);R(x,'#5e4a36',1,4,34,1);R(x,'#3a2e22',2,12,3,8);R(x,'#3a2e22',31,12,3,8);R(x,'#7a7e82',6,2,10,2);R(x,'#c03a2a',8,1,4,2);R(x,'#9a9a92',20,3,8,3);R(x,'#2a2a2a',24,5,2,4);}});
def('pipes',{w:64,h:8,wall:true,draw(x){R(x,'#5a5e62',0,1,64,3);R(x,'#7a7e82',0,1,64,1);R(x,'#6a4a2a',0,5,64,2);for(let i=6;i<64;i+=14)R(x,'#3a3e42',i,0,2,8);}});
// HD versions of key Stage 2 props
hd2('boat',(x,o)=>{const [hc,tr]=BOATC[o.c||0],hL=sh(hc,1.2),hD=sh(hc,.7);
 x.fillStyle='rgba(0,0,0,.4)';x.fillRect(4,42,192,8);
 R(x,hc,0,16,196,28);R(x,hL,0,16,196,2);R(x,tr,0,24,196,2);R(x,sh(tr,1.3),0,24,196,1);R(x,hD,0,36,196,8);for(let i=8;i<190;i+=24)R(x,sh(hc,.85),i,28,1,8);
 R(x,hc,188,20,12,20);R(x,hD,196,24,4,12);R(x,'#141414',0,24,8,12);R(x,tr,4,20,2,2);
 R(x,sh(hc,1.08),16,4,144,16);R(x,sh(hc,1.25),16,4,144,2);R(x,hD,16,18,144,2);
 for(let i=24;i<152;i+=20){R(x,'#0e161c',i,8,10,6);R(x,'#2a3c48',i,8,4,2);R(x,tr,i-1,7,12,1);}
 if(!o.dirty){R(x,'#3a6a2a',40,0,6,6);R(x,'#8a3a2a',40,4,6,3);R(x,'#a83a2a',50,0,6,6);R(x,'#5a4030',120,0,24,4);R(x,'#6a5038',120,0,24,1);R(x,'#2a2a2e',90,0,14,3);}
 else{R(x,'#2a2622',80,0,30,4);x.fillStyle='rgba(30,25,20,.35)';x.fillRect(0,4,200,40);speck2(x,['#1e1a16','#3a3028'],80,0,4,200,40,o.c+5);}
 R(x,'#2a2a2a',166,6,3,14);R(x,'#3a2c20',166,6,16,2);R(x,'#2a2a2a',176,4,2,4);});
hd2('cage',(x,o)=>{R(x,'#121416',2,60,60,8);for(let i=2;i<64;i+=6){R(x,'#3a3e44',i,8,2,56);R(x,'#5a5e64',i,8,1,56);}R(x,'#4a4e54',2,8,60,4);R(x,'#6a6e74',2,8,60,1);R(x,'#3a3e44',2,32,60,2);R(x,'#4a4e54',2,60,60,4);
 if(o.v==='open'){R(x,'#0a0c0e',24,12,16,46);R(x,'#3a3e44',40,12,2,46);}else{R(x,'#9a8a3a',28,33,8,6);R(x,'#c8b860',29,34,6,1);R(x,'#6a5a2a',31,37,2,3);}});
hd2('hbed',(x,o)=>{const bc=o.c||'#8aa6c0';R(x,'#9aa4a8',2,0,44,8);R(x,'#c8ccd0',2,0,44,2);for(let i=6;i<44;i+=6)R(x,'#7a8488',i,2,1,5);
 R(x,'#e2e4e2',4,8,40,56);R(x,'#f2f2f0',8,10,32,12);R(x,'#d0d2d0',8,20,32,2);R(x,bc,4,26,40,36);R(x,sh(bc,1.15),4,26,40,2);R(x,sh(bc,.8),4,58,40,4);for(let i=0;i<4;i++)R(x,sh(bc,.9),8+i*9,32+i*6,10,1);
 R(x,'#9aa4a8',0,12,2,52);R(x,'#9aa4a8',46,12,2,52);R(x,'#5a6266',4,64,4,8);R(x,'#5a6266',40,64,4,8);R(x,'#2a2a2a',3,70,6,2);R(x,'#2a2a2a',39,70,6,2);});
hd2('nboard',(x,o)=>{R(x,'#5a3e28',0,0,64,36);R(x,'#7a5638',0,0,64,2);R(x,'#a8885e',4,4,56,28);speck2(x,['#9a7a52','#b8986e'],80,4,4,56,28,3);
 const notes=[[8,8,12,14,'#ecE8dc'],[24,6,14,12,'#f2eaa4'],[42,8,14,16,'#ece8dc'],[10,24,16,6,'#d8e8f0'],[30,20,10,10,'#f8d0d0']];
 notes.forEach(([a,b,w,h,c],i)=>{R(x,c.toLowerCase(),a,b,w,h);R(x,'#c03a2a',a+(w>>1),b,2,2);for(let k=3;k<h-1;k+=2)R(x,'#3a3a4a',a+2,b+k,w-4-((k*3+i)%4),1);});});
hd2('brazier',(x,o)=>{R(x,'#2a2622',4,12,16,20);R(x,'#3c3630',4,12,16,2);for(let i=6;i<20;i+=3)R(x,'#141210',i,16,1,12);R(x,'#1a1816',6,30,3,6);R(x,'#1a1816',15,30,3,6);R(x,'#c85a20',6,8,12,4);R(x,'#ff9a3a',8,6,8,3);R(x,'#ffd07a',10,5,4,2);});
hd2('recdesk',(x,o)=>{R(x,'#c9cdca',2,8,96,18);R(x,'#e2e5e2',2,8,96,2);R(x,'#7f948c',2,26,96,22);R(x,'#6a7e76',2,26,96,2);for(let i=10;i<96;i+=24){R(x,'#738880',i,30,1,18);R(x,'#8a9f97',i+1,30,1,18);}
 R(x,'#17191c',60,0,24,12);R(x,'#3a5a7a',62,2,20,8);R(x,'#7aa2c2',63,3,8,1);R(x,'#2a2d30',64,12,16,2);R(x,'#e8e4d8',16,12,16,10);R(x,'#3a3a4a',18,14,10,1);R(x,'#3a3a4a',18,16,8,1);R(x,'#c03a2a',40,14,6,4);R(x,'#2a2a2e',48,16,8,3);});
// ---------- characters ----------
Object.assign(STY,{
 mara:{skin:'#8a5a3e',hair:'#151110',hs:'bun',coat:'#2f6f72',coat2:'#245659',pants:'#2f6f72',shoe:'#e0e0e0'},
 theo:{skin:'#c89a7a',hair:'#2a1a12',hs:'short',coat:'#5a6a8a',coat2:'#47546e',pants:'#2a2e38',shoe:'#d8d8d8'},
 halloran:{skin:'#e0b8a0',hair:'#cfcfcf',hs:'bald',coat:'#7a6a52',coat2:'#625540',pants:'#4a4a50',shoe:'#2a2420',beard:'#c8c8c8'},
 cole:{skin:'#c49a7c',hair:'#2a2a26',hs:'beanie',hat:'#3a3530',coat:'#3a3f36',coat2:'#2c3029',pants:'#2a2a2a',shoe:'#1a1a1a',beard:'#2a2420'},
 jas:{skin:'#7a5038',hair:'#111111',hs:'hood',coat:'#4a5a3a',coat2:'#3a4a2d',pants:'#22252a',shoe:'#e0e0e0'},
 warden3:{skin:'#e0b49a',hair:'#8a5a2a',hs:'short',coat:'#5a4a3a',coat2:'#46392c',pants:'#2a2a30',shoe:'#1a1a1a',hivis:1},
 farrow:{skin:'#d8b090',hair:'#6a5040',hs:'short',coat:'#9aa8b8',coat2:'#7a8898',pants:'#3a3a44',shoe:'#2a2a2a',beard:'#7a5a44'},
});
// ---------- items ----------
Object.assign(ITEMS,{
 insulin:{name:'Insulin',icon:'insulin',desc:'A cool-box of insulin pens from the hospital pharmacy. For Mr Halloran.',key:true},
 cutters:{name:'Bolt cutters',icon:'cutters',desc:'Long-handled bolt cutters from the hospital basement. They’ll cut a chain.',key:true},
 ring:{name:'Wedding ring',icon:'ring',desc:'A plain gold band. The inside is engraved: “A & J, always”.',clue:'ring'},
 filter:{name:'Water filter',icon:'filter',desc:'A camping water filter straw. Someone was very careful about what they drank.',clue:'filter'},
 bat:{name:'Cricket bat',icon:'bat',desc:'Old, oiled, heavy. Someone’s pride and joy.',weapon:{dmg:16,reach:22,cd:.4,stam:12,knock:120}},
 peaches:{name:'Tinned peaches',icon:'peaches',desc:'In syrup. Wonderful.',use:{hunger:22,thirst:8,sanity:3},sfx:'eat'},
 bar:{name:'Energy bar',icon:'bar',desc:'Chewy. Allegedly chocolate.',use:{hunger:14},sfx:'eat'},
});
Object.assign(ICONDRAW,{
 insulin(x){R(x,'#3a7aba',2,5,12,8);R(x,'#5a9ada',2,5,12,1);R(x,'#e8e8e4',4,7,8,4);R(x,'#c03a2a',7,8,2,2);},
 cutters(x){R(x,'#c03a2a',1,12,4,3);R(x,'#c03a2a',11,12,4,3);for(let i=0;i<8;i++){R(x,'#8a8e92',3+i/2|0,11-i,1,1);R(x,'#8a8e92',12-(i/2|0),11-i,1,1);}R(x,'#5a5e62',6,1,4,3);},
 filter(x){R(x,'#3a8aba',6,1,4,13);R(x,'#5aaada',6,1,4,1);R(x,'#2a2a2a',6,13,4,2);R(x,'#e8e8e4',7,4,2,6);},
 bat(x){for(let i=0;i<9;i++)R(x,'#c8a870',3+i,12-i,3,3);R(x,'#3a2a20',12,1,2,3);R(x,'#3a2a20',13,0,2,2);},
 peaches(x){R(x,'#9aa0a4',3,3,10,11);R(x,'#e8902a',3,6,10,6);R(x,'#f0b050',5,8,4,2);},
 bar(x){R(x,'#4a2a1a',2,6,12,5);R(x,'#c8a040',2,6,12,1);R(x,'#e8d8a0',6,7,4,3);},
});
tile('barTile',{solid:true,opaque:false,draw(x,r){TL[T.gravel].draw(x,r);for(let j=0;j<3;j++){R(x,'#7a6242',0,1+j*5,16,3);R(x,'#8e744e',0,1+j*5,16,1);R(x,'#5a4630',3,1+j*5,2,4);R(x,'#5a4630',11,1+j*5,2,4);}R(x,'#4a3a28',0,15,16,1);}});
