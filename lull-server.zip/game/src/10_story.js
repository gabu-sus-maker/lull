// ================= STORY SCRIPTS =================
const F=()=>G.flags;
const S={
// ---------- FLAT ----------
 *flatBed(){const p=PH();
  if(p==='d1_wake')yield N('You are not getting back in. You are an adult. Allegedly.');
  else if(p==='d1_night'){yield N('Bed. Finally.');const c=yield ask(['Go to sleep','Not yet']);if(c===0){if(!F().ellie_reply){yield N('Your phone buzzed a while ago. Probably Ellie.');const c2=yield ask(['Check your phone first','Sleep anyway']);if(c2===0)return;}
    yield N('The rain ticks against the window. Biscuit sighs, enormously, from the kitchen.');yield go('d2_lab');}}
  else if(p==='d3_wake')yield N('You slept well. Better than you have in years.');
  else if(p==='d3_night'){const c=yield ask(['Sleep','Not yet']);if(c===0){yield N('You lie down. The hum is very soft tonight. Very kind.');yield fade(1,2.5);G.time=G.time;yield go('a1_flat',{card:['ELEVEN DAYS LATER','Sunday 25 October',3.2],glitchCard:1});}}
  else yield N('Not now.');},
 *flatWardrobe(){const p=PH();if(p==='d1_wake')yield N('Work clothes. Grey, greyer, and the good grey.');else if(p==='a1_flat')yield N('Clothes. They hang very still.');else yield N('Your clothes.');},
 *flatMirror(){const p=PH();
  if(p==='d1_wake'||p==='d1_night'){const st=yield cu('mirror',{tired:1});yield N('You look like someone who has been awake since five.');yield N('Which you have.');yield cuClose();F().mirror1=1;}
  else if(p==='d3_wake'||p==='d3_night'){const st=yield cu('mirror',{});yield N('You look tired.');st.smile=1;st.smileOn=1;G.timers.push({t:.22,fn:()=>{st.smileOn=0;}});yield wait(.6);yield N('You look rested.');yield cuClose();F().clue_mirror=1;F().mirrorLag=1;}
  else if(p==='a1_flat'){if(!P.torch){yield N('It’s too dark to see anything in the mirror.');return;}const st=yield cu('mirror',{dark:1,flicker:1});yield N('You look calm.');yield N('You look very calm.');yield cuClose();F().clue_mirror2=1;}},
 *flatFridge(){const p=PH();if(p==='d1_wake')yield N('Half a lemon, three eggs, and a jar of something that used to be pesto. It smells faintly of cheese and regret.');
  else if(p==='a1_flat'){yield N('The fridge is warm. It smells of—');yield wait(.8);yield N('The fridge is empty.');F().clue_smell=1;}else yield N('Eggs. Lemon. A jar of something.');},
 *flatSink(){if(PH()==='a1_flat'){yield N('You turn the tap. It coughs, and gives nothing.');}else if(PH()==='d1_wake')yield N('Dishes from last night. Future you’s problem.');else yield N('The sink.');},
 *flatKettle(){const p=PH(),k='tea_'+p;if(p==='a1_flat'){yield N('No power. No water. No tea.');return;}
  if(F()[k]){yield N(p.startsWith('d1')?'You’ve had your tea. Don’t be greedy.':'You’ve had tea.');return;}
  Snd.play('kettle');yield wait(2.7);F()[k]=1;G.stats.thirst=Math.min(100,G.stats.thirst+12);G.stats.sanity=Math.min(100,G.stats.sanity+8);
  yield N(p.startsWith('d1')?'Tea. Milk, no sugar. A small daily miracle that costs four pence.':'Tea.');},
 *flatRadio(){const p=PH();
  if(p==='d1_wake'){Snd.set('static',.012,.2);yield say('RADIO','…and in Newham, officials are investigating what they’re describing as a small cluster of unexplained deaths.');yield say('RADIO','The UK Health Security Agency says there is no cause for concern. Now, travel: the District line is part suspended this morning…');Snd.set('static',0,.3);yield N('There is always no cause for concern, right up until there is.');F().radio1=1;}
  else if(p==='d1_night'){Snd.set('static',.012,.2);yield say('RADIO','…unexplained deaths in East London has risen to eleven. Health officials say the deaths appear peaceful, with no sign of distress, and there is no evidence of a link…');Snd.set('static',0,.3);yield N('Peaceful. That’s one word for it.');}
  else if(p==='d3_wake'){Snd.set('static',.012,.2);yield say('RADIO','This is a public information broadcast. A stay-at-home order will come into force at six p.m. today across Greater London.');yield say('RADIO','If you have a high temperature, or a new and continuous cough, do not leave your home. Do not—');Snd.set('static',0,.3);yield N('You don’t have a temperature. You don’t have a cough.');yield N('You feel fine.');F().clue_radio1=1;}
  else if(p==='a1_flat')yield N('No power.');else yield N('You leave it off.');},
 *flatDrawer(){if(PH()==='a1_flat'&&!F().torch){F().torch=1;giveItem('torch');giveItem('batt',1);P.battery=55;yield N('Takeaway menus. Elastic bands. A torch.');UI.hint('<kbd>F</kbd> TORCH ON / OFF &nbsp; <kbd>1-5</kbd> USE ITEMS &nbsp; <kbd>I</kbd> BAG',8);UI.objective(F().crowbar?'Go out and find water.':'Find something to defend yourself with, then go out and find water.');yield N('Darkness is bad for you. Keep the light on when you can.');}
  else yield N('Takeaway menus and elastic bands.');},
 *flatNotes(){if(F().notes_a1){yield N('Your handwriting.');return;}F().notes_a1=1;F().clue_notes=1;
  yield note({id:'h1',title:'',text:'Day 4.\nPower went this morning.\nBiscuit won’t come near me. He growls when I talk.\nEllie’s phone still off.'});
  yield note({id:'h2',title:'',text:'Day 6.\nIt says Ellie is fine.\n\nHOW WOULD IT KNOW'});
  yield note({id:'h3',title:'',text:'Day 9.\n\nDon’t trust how calm you feel.'});
  yield N('You don’t remember writing these.');yield N('You’ve been so tired.');},
 *flatTV(){const p=PH();if(p==='d1_wake')yield N('You don’t turn it on. Nothing good has ever happened on breakfast television.');else if(p==='a1_flat')yield N('A dead grey screen. Your reflection in it is a dark shape, sitting very still.');else yield N('You leave it off.');},
 *flatPhoto(){const p=PH();
  if(p.startsWith('d1')){yield cu('photo',{stage:0});yield N('You and Ellie at Southend, 2019. Neither of you wanted to be there. Dad took it anyway.');yield N('She’s almost smiling. Almost.');yield cuClose();F().photo1=1;}
  else if(p.startsWith('d3')){yield cu('photo',{stage:1});yield N('You and Ellie, at Southend.');yield N('She looks happy.');yield cuClose();F().clue_photo1=1;}
  else if(p==='a1_flat'){if(!P.torch&&lightLevelAt(P.x,P.y)<.4){yield N('Too dark to see.');return;}yield cu('photo',{stage:2});yield N('Ellie, smiling.');yield N('She was always smiling in this one.');yield cuClose();F().clue_photo2=1;}},
 *flatPhone(){const p=PH();
  if(p==='d1_wake'){if(F().voicemail){yield N('No new messages.');return;}F().voicemail=1;
   yield phone(msgs([['','1 missed call · <b>Ellie</b> (23:52)'],['','1 new voicemail']]));
   yield say('VOICEMAIL','Ro, it’s me. I know it’s been… a while. Can you call me back? It’s not — it’s not urgent. Okay. Bye.');
   const c=yield ask(['Call her back','Later']);
   if(c===0){Snd.play('ring',{n:2});yield wait(5.6);yield N('It rings out. Of course it does.');F().called=1;}
   else{yield N('Later. You’ve been saying later for two years.');}}
  else if(p==='d1_night'){if(F().ellie_reply){yield N('Nothing new.');return;}
   yield phone(msgs([[ 'Ellie',F().called?'saw you called!! sorry was on a night shift. can we talk this week? x':'ok. i’ll try you again weds x']]));
   const c=yield ask(['Reply: “Wednesday. Promise.”','Reply: “Busy week, sorry.”']);F().ellie_reply=c===0?1:2;
   yield N(c===0?'Three dots appear, disappear, appear. Then a single heart.':'Delivered. Then nothing.');}
  else if(p==='d3_wake'){if(F().ellie_call)yield N('No service.');else if(F().ringing)yield* S.ellieCall();else yield N('No messages.');}
  else if(p==='a1_flat'){yield N('The battery died days ago.');}
  else yield N('Nothing.');},
 *ellieCall(){F().ringing=0;F().ellie_call=1;Snd.set('static',.004,.2);
  yield say('ELLIE','Ro? Oh, thank god. Are you okay? Are you sick?');
  const c=yield ask(['“I’m fine. Better than fine.”','“I’m okay. Are you?”']);
  yield say('ELLIE',c===0?'Better than— okay. Okay. Listen to me.':'I’m scared, Ro. Listen.');
  yield say('ELLIE','They’re setting something up at the Barbican. Margaret — Dad’s friend, on the council? Sealed blocks, filtered air, testing at the door. She can get us in.');
  yield say('ELLIE','Come tonight. Before the lockdown. Please.');
  const c2=yield ask(['“I’ll come.”','“I can’t leave Biscuit.”','“You’re overreacting, El.”']);F().ellie_ans=c2;
  yield say('ELLIE',['Okay. Okay. Bring food, they said to bring—','Then bring him! Bring the stupid dog, just come—','People are dying in their sleep, Ro, I’m not over—'][c2]);
  Snd.set('static',.03,.1);yield say('ELLIE','—Ro? You sound strange. You sound really—',{fast:1});
  Snd.set('static',0,.1);Snd.play('beep');yield wait(1.5);
  yield N('The line is dead. The network, probably.');F().netDown=1;
  yield N('You should go to her.');F().barbican=1;
  UI.objective('Get supplies from Adeyemi’s before the 6 p.m. lockdown.');},
 *flatToolbox(){if(PH()==='a1_flat'&&!F().crowbar){F().crowbar=1;giveItem('crowbar');yield N('Screwdrivers. A spirit level. The crowbar you bought for the bathroom door.');yield N('It’s heavy in your hand. That’s good.');UI.hint('<kbd>SPACE</kbd> ATTACK &nbsp; <kbd>Q</kbd> DODGE &nbsp; <kbd>SHIFT</kbd> RUN',8);UI.objective(hasItem('torch')?'Go out and find water.':'Find a light.');}
  else yield N('Your toolbox. You keep meaning to fix the bathroom door.');},
 *flatWindow(){const p=PH();yield N({d1_wake:'Rain on Bow Road. A bus hisses past, lit up like a fish tank.',d1_night:'Wet orange streetlight. Someone’s fox is screaming in a garden.',d3_wake:'The street is quiet. Calm.',d3_night:'The street is empty. Every window is lit, and nobody is moving.',a1_flat:'No lights anywhere. Just a glow to the east, low and orange, where something is burning.'}[p]||'The street.');},
 *feedDog(){if(F().fed){yield N('Licked clean. Possibly polished.');return;}F().fed=1;const b=G.map.props.find(p=>p.name==='bowl');if(b)b.o.v='full';
  yield N('You pour the kibble. Biscuit eats as though this is the first meal in recorded history.');if(G.dog)G.dog.mode='follow';
  UI.objective('Leave for work. The front door is at the end of the hallway.');},
 *petDog(){const p=PH(),d=G.dog;
  if(p==='d1_wake'&&!F().fed){yield N('Biscuit is staring at his bowl with the focus of a hostage negotiator.');d&&d.bark();return;}
  if(d&&(d.mode==='hide'||d.mode==='wary')){Snd.play('growl');G.flags.clue_dog=1;
   if(p==='a1_flat'){yield N('Biscuit shows his teeth.');yield N('He’s frightened. He’s been alone too long.');}
   else yield N('Biscuit is unsettled. Dogs feel the weather.');return;}
  if(!F()['pet_'+p]){F()['pet_'+p]=1;G.stats.sanity=Math.min(100,G.stats.sanity+4);}
  Snd.play('whine');yield N(pick(['Biscuit leans his whole weight against your legs. Good dog.','Biscuit’s tail thumps the floor. Good boy.','Ears, then chin, then ears again. Biscuit approves.']));},
 *flatDoor(){const p=PH();
  if(p==='d1_wake'){if(!F().fed){yield N('Biscuit will eat the sofa if you leave without feeding him.');return;}yield go('d1_street');}
  else if(p==='d1_night'||p==='d3_night')yield N('You’re not going anywhere tonight.');
  else if(p==='d3_wake'){if(!F().ellie_call){yield N(F().ringing?'Your phone is ringing.':'You should check on Biscuit first.');return;}if(!F().biscuitStays){F().biscuitStays=1;yield N('Biscuit won’t come out from under the table. You leave him there.');}yield go('d3_street');}
  else if(p==='a1_flat'){if(!hasItem('torch')){yield N('It’s too dark out there to go without a light.');return;}if(!F().crowbar){yield N('You shouldn’t go out there with nothing in your hands.');return;}yield go('a1_street');}},
// ---------- DAY 1 ----------
 *d1Wake(){G.showHum=false;G.sanityOn=false;F().canFight=false;giveItem('notebook',1,true);
  Snd.play('alarm');yield wait(2);
  yield N('Six forty. The alarm has the cheerful confidence of something that has never had to get up.');
  yield N('The flat smells of last night’s curry and, faintly, of dog.');
  UI.objective('Feed Biscuit, then leave for work.');
  UI.hint('<kbd>WASD</kbd> / <kbd>ARROWS</kbd> MOVE &nbsp; <kbd>E</kbd> INTERACT &nbsp; <kbd>SHIFT</kbd> SPRINT',9);},
 *d1Street(){murmur('Bow Road at seven. Diesel, wet pavement, and somebody’s fried breakfast.');UI.objective('Get to Bow Church station.');},
 *tunde1(){const e=G.map.ents.find(x=>x.style==='tunde');
  yield* talk(e,function*(){if(F().tunde1){yield say('TUNDE','Go! You’ll miss your train.');return;}F().tunde1=1;
   yield say('TUNDE','Rowan! You look terrible.');yield say('TUNDE','Here. On the house. Tell your sister I said hello, yes?');giveItem('pastry');
   const c=yield ask(['“I will.”','“We’re not really talking.”']);
   if(c===0)yield say('TUNDE','Good. Family is family.');else{yield say('TUNDE','Then call her. Life is short, my friend.');yield say('TUNDE','Shorter than you think.');}});},
 *phoneBox(){const p=PH();yield N(p==='a1_street'?'The receiver hangs on its cord, swinging slightly. There is no wind.':'A red phone box. It smells exactly how you’d expect.');},
 *station(){const p=PH();
  if(p==='d1_street'){yield go('d1_lab');}
  else if(p==='d3_street'||p==='d3_dusk')yield N('The station is shuttered. Two soldiers stand in front of it, looking at nothing.');
  else if(p==='a1_street'){yield N('The shutters are down. Somebody has painted across them in red:');yield N('DON’T LET THEM IN.');F().clue_graffiti=1;}
  else yield N('Not tonight.');},
 *shopDoor(){const p=PH();
  if(p==='d1_street')yield N('Tunde’s isn’t open yet. He opens when he feels like it, which is usually.');
  else if(p==='d3_street')yield go('d3_shop');
  else if(p==='a1_street')yield go('a1_shop');
  else yield N('Closed.');},
 *streetHome(){const p=PH();
  if(p==='d1_street')yield N('You’re already late.');
  else if(p==='d2_walk'){if(!F().jogger){yield N('Biscuit hasn’t had his walk. He makes sure you know it.');G.dog&&G.dog.bark();return;}yield N('You don’t sleep well that night. You dream about water.');yield go('d3_wake');}
  else if(p==='d3_street')yield N('Supplies first.');
  else if(p==='d3_dusk')yield go('d3_night');
  else if(p==='a1_street')yield N('There’s nothing left for you in there.');},
 *d1Lab(){murmur('Beckton Sewage Treatment Works. One of the largest in Europe. It smells like it.');UI.objective('Find Priya.');},
 *priya(){const e=G.map.ents.find(x=>x.style==='priya');
  yield* talk(e,function*(){const f=F();
   if(!f.priya1){f.priya1=1;yield say('PRIYA','Morning. Racks one to three are yours today — the usual surveillance panel.');yield say('PRIYA','And the Newham samples came in overnight. UKHSA asked for them specifically. Be thorough.');
    const c=yield ask(['“Is this about the deaths on the news?”','“Thorough is my middle name.”']);
    if(c===0)yield say('PRIYA','Probably nothing. But they want wastewater surveillance on anything unusual. So — look for anything unusual.');else yield say('PRIYA','Your middle name is “Late”, Rowan.');
    UI.objective('Process the sample racks (0/3).');return;}
   if(!f.micro){yield say('PRIYA','Racks first. Then we talk.');return;}
   if(!f.priya2){f.priya2=1;yield say('PRIYA','Coordinated motility? Show me.');yield wait(1);yield say('PRIYA','…Okay. That’s odd. That’s very odd.');yield say('PRIYA','I’ll send it to Colindale for sequencing tonight. Good catch.');
    yield say('PRIYA','One more thing — can you take the tank two readings before you go? Gary’s supposed to, but he’s been… strange today.');UI.objective('Take the readings at tank two, in the yard.');return;}
   yield say('PRIYA','Tank two. Then go home, Rowan.');});},
 rack(n){return function*(){const f=F();if(!f.priya1){yield N('You should check in with Priya first.');return;}
   if(f['r'+n]){yield N('Done.');return;}f['r'+n]=1;
   yield N(['','Rack one: Stratford. Nothing but the usual horrors.','Rack two: Canning Town. Someone in Canning Town has been eating a heroic amount of beetroot.','Rack three: Newham, overnight. Sample 47 is cloudy. Not dirty-cloudy. Something else.'][n]);
   const k=(f.r1?1:0)+(f.r2?1:0)+(f.r3?1:0);
   if(k<3)UI.objective(`Process the sample racks (${k}/3).`);else{UI.objective('Look at Sample 47 under the microscope.');}};},
 *microscope(){const f=F();
  if(PH()==='d2_lab'){yield N('Sample 47 is in the fume hood now.');return;}
  if(!(f.r1&&f.r2&&f.r3)){yield N('The microscope. Racks first.');return;}
  if(f.micro){yield N('You don’t want to look again.');return;}f.micro=1;
  Snd.play('micro');const st=yield cu('micro',{school:1});
  yield N('Rod-shaped bacteria. Thousands of them.');
  yield N('They move like a crowd leaving a stadium. All slightly in step.');
  st.align=1;Snd.play('sting');yield wait(1.4);
  yield N('For a moment, they all turn the same way.');
  yield N('Towards you.');
  st.align=0;yield wait(.6);
  yield N('You blink. They’re just bacteria again.');
  yield cuClose();f.clue_micro=1;
  yield note({id:'lab1',typed:1,title:'LAB LOG — 12 OCT',text:'Sample 47 (Newham, overnight composite).\nGram-negative rods, very high density.\nUnusual motility: coordinated, “schooling” behaviour.\nNo comparable result on record.\nFlagged for sequencing (Colindale).\n— R.H.'});
  UI.objective('Tell Priya what you saw.');},
 *dev1(){const e=G.map.ents.find(x=>x.style==='dev');
  yield* talk(e,function*(){if(F().dev1){yield say('DEV','If you see Gary, tell him the canteen’s got custard creams. That usually gets a reaction.');return;}F().dev1=1;
   yield say('DEV','You heard about Gary?');yield say('DEV','Says he’s never felt better. He’s been out by tank two all afternoon. Just… looking at it.');
   const c=yield ask(['“Is he alright?”','“Gary looking at a tank is the most Gary thing I’ve ever heard.”']);
   yield say('DEV',c===0?'He smiled at me, Rowan. Gary. Smiled.':'He smiled at me. Six years I’ve worked with him. Not once.');});},
 *panel(){const f=F();if(PH()==='d2_lab'){yield N('Everything is normal.');return;}if(!f.priya2){yield N('The tank two control panel. Gary’s job, usually.');return;}if(f.panel){yield N('Everything is normal.');return;}f.panel=1;
  yield N('Dissolved oxygen: normal. Turbidity: normal. Temperature: normal.');yield N('Everything is normal.');
  if(f.gary)UI.objective('Go home.');else UI.objective('Check on Gary.');},
 *gary(){const e=G.map.ents.find(x=>x.style==='gary');const f=F();
  if(f.gary){yield* talk(e,function*(){yield say('GARY','Go on, Rowan. Come and look.');});e.facePlayer();return;}
  f.gary=1;yield say('GARY','Lovely, isn’t it.');
  const c=yield ask(['“The tank?”','“Gary? Are you alright?”']);
  if(c===0)yield say('GARY','The water. Twenty-two years I’ve worked here, and I never once noticed how calm it is.');
  else yield say('GARY','Never better, Rowan. Honestly. Never better in my life.');
  e.talking=true;e.facePlayer();e.smile=true;yield wait(.8);
  yield N('Gary is smiling.');yield N('Gary does not smile. Gary once described his own wedding as “fine”.');
  yield say('GARY','You should come and look. Go on. Come closer.');
  const c2=yield ask(['“Maybe tomorrow, Gary.”','Back away slowly.']);
  if(c2===0)yield say('GARY','Tomorrow, then.');
  e.talking=false;
  if(f.panel)UI.objective('Go home.');else UI.objective('Take the readings at tank two.');},
 *priyaDesk(){if(PH()==='d2_lab'){const f=F();if(!f.splash){yield N('Priya’s computer. You should deal with the sample first.');return;}if(f.email){yield N('You’ve read it.');return;}f.email=1;f.clue_email=1;
   yield note({id:'email',typed:1,title:'From: Colindale Sequencing — URGENT',text:'Re: Sample 47 (Beckton, Newham composite)\n\nPreliminary result: novel organism. Closest known relative: soil Pseudomonas.\n\nUnusual gene clusters encoding neuroactive, behaviour-modulating proteins. Function unknown.\n\nRecommend BSL-3 handling.\nDO NOT HANDLE OPEN.'});
   yield N(f.reported?'Dev reads it over your shoulder. Neither of you says anything.':'Bit late for that.');UI.objective('Go home.');}
  else yield N('Priya’s desk. Three mugs, all half full, all cold.');},
 *labExit(){const f=F(),p=PH();
  if(p==='d1_lab'){if(!(f.gary&&f.panel)){yield N('You haven’t finished.');return;}yield go('d1_night');}
  else{if(!f.email){yield N(f.splash?'You should check Priya’s email first. Colindale were meant to send something.':'You haven’t done what you came for.');return;}yield go('d2_walk');}},
 *d1Night(){yield N('Home. The radiator is ticking. Biscuit has forgiven you for leaving, but only just.');UI.objective('Get some sleep.');Snd.play('buzz');},
// ---------- DAY 2 ----------
 *d2Lab(){murmur('The smell meets you on the stairs. You’d think you’d stop noticing it. You never do.');
  const e=G.map.ents.find(x=>x.style==='dev');yield wait(.8);
  yield* talk(e,function*(){
   yield say('DEV','Priya’s off sick. Rang in at six.');yield say('DEV','She said — this is a direct quote — “I’ve never felt better, Dev.” Who rings in sick to say that?');
   yield say('DEV','And Gary hasn’t turned up. Not answering his phone.');
   yield say('DEV','Colindale want Sample 47 re-run under the hood. Full containment. I’m not doing it, I’ve got a kid.');});
  UI.objective('Re-run Sample 47 in the fume hood.');},
 *dev2(){const e=G.map.ents.find(x=>x.style==='dev');yield* talk(e,function*(){const f=F();
   if(f.splash&&!f.email){yield say('DEV',f.reported?'Fifteen minutes under the tap. I timed it. You’ll be fine. Probably fine.':'You alright? You’ve gone a bit pale.');return;}
   yield say('DEV','Hood’s on the far side. Sash down to the line, yeah?');});},
 *hood(){const f=F();if(PH()!=='d2_lab'){yield N('The fume hood. It hums to itself.');return;}if(f.splash){yield N('You don’t want to touch it again.');return;}f.splash=1;
  yield N('Gloves. Visor. Sash down to the line. You’ve done this a thousand times.');
  yield N('You uncap Sample 47.');
  Snd.play('tear');G.shake=4;UI.flash('#fff',.5,.7);yield wait(.4);
  yield N('Your glove catches on the rack, and tears.');
  yield N('Cold on your wrist. A drop. That’s all.');
  yield N('You’ve had worse at Glastonbury.');
  const c=yield ask(['Report the exposure','Wash it off and say nothing']);
  const dev=G.map.ents.find(x=>x.style==='dev');
  if(c===0){f.reported=1;yield say('DEV','Okay. Okay — the form’s in the top drawer. Wash it for fifteen minutes. You’ll be fine.');yield say('DEV','Probably fine.');}
  else{f.reported=0;yield N('You scrub your wrist at the sink until it’s pink and stinging. Nobody saw.');}
  UI.objective('Check Priya’s email for the sequencing results.');},
 *d2Walk(){murmur('The rain has thinned to a mist. Biscuit is delighted by absolutely everything.');UI.objective('Walk Biscuit down to the canal.');},
 *okafor2(){const e=G.map.ents.find(x=>x.style==='okafor');yield* talk(e,function*(){const f=F();
  if(f.ok2){yield say('OKAFOR','Go careful, love. Strange week.');return;}f.ok2=1;
  yield say('OKAFOR','Rowan, love. It’s Mr Pell, at fourteen. His daughter found him this morning.');
  yield say('OKAFOR','Asleep in his chair. Smiling, she said. Like he’d just heard a good joke.');
  const c=yield ask(['“I’m so sorry.”','“That’s the third one I’ve heard of.”']);
  yield say('OKAFOR',c===0?'He was a nice man. Grumpy. But nice.':'It’s all over the news. They don’t know anything, do they? Nobody knows anything.');
  yield say('OKAFOR','Go careful, love. Strange week.');});},
 joggerNear(){if(F().joggerSeen)return;F().joggerSeen=1;G.dog&&G.dog.bark();setTimeout(()=>{G.dog&&G.dog.bark();},900);murmur('Biscuit stops dead. Hackles up.');if(G.dog){G.dog.mode='idle';G.dog.idlePose='growl';setTimeout(()=>{if(G.dog&&!F().jogger)G.dog.mode='follow';},4000);}},
 *jogger(){const f=F();if(f.jogger){yield N('The man on the bench. Still smiling.');return;}
  yield N('A man in running gear is sitting on the bench. Eyes closed. Earbuds in.');
  yield ask(['“Excuse me — are you alright?”']);
  yield N('Nothing. Up close, he’s smiling. A small, private smile, as if he’s just remembered something nice.');
  yield N('He isn’t breathing.');
  const c=yield ask(['Check his pulse','Call 999']);
  if(c===0){yield N('His wrist is cold. Not cool. Cold.');}
  yield phone(msgs([['','Calling <b>999</b>…']]));
  yield say('999','All of our operators are currently busy. Please hold. Your call is important to us.');
  Snd.song(MEL_TITLE,120,{loop:true,v:.025});yield wait(2.5);Snd.stopSong();
  yield fade(1,1.2);
  yield N('You hold for eleven minutes. Biscuit sits against your leg the whole time and doesn’t make a sound.');
  f.jogger=1;
  const w=npc(G.map,tx(29),ty(31)-2,'police',{fixedDir:2,interact:I('PC Walsh',S.walshAfter)});const d2=npc(G.map,tx(33),ty(31)-2,'police2',{fixedDir:1});
  P.x=tx(31);P.y=ty(31)+10;P.dir=3;if(G.dog){G.dog.x=P.x+12;G.dog.y=P.y;G.dog.mode='follow';}
  yield fade(0,1);
  yield say('WALSH','You the caller? Right. Stay there for me, please.');
  yield say('DARBY','Third one today. All of ’em smiling.');
  yield say('WALSH','Darby.');
  yield say('DARBY','What? They are.');
  yield say('WALSH','Go home. Get some sleep. We’ll be in touch if we need a statement.');
  UI.objective('Go home.');},
 *walshAfter(){yield say('WALSH','Go home, please. There’s nothing you can do here.');},
// ---------- DAY 3 ----------
 *d3Wake(){G.stats.hum=Math.max(G.stats.hum,12);
  yield wait(1.2);
  yield N('You wake slowly.');
  yield N('You feel… rested. Better than you have in years.');
  yield N('There’s a faint hum. Like a fridge in another room.');
  G.showHum=true;UI.hud();yield wait(1.4);
  yield N('It’s oddly comforting.');
  UI.hint('THE HUM. YOU’RE NOT SURE WHAT IT IS.',6);
  UI.objective('Check on Biscuit.');
  G.waiters.push({cond:()=>G.dog&&dist(P.x,P.y,G.dog.x,G.dog.y)<52,fn:()=>Script.run(S.d3Biscuit)});},
 *d3Biscuit(){F().clue_dog=1;Snd.play('growl');yield N('Biscuit is under the table. When you come close, his lip curls back from his teeth.');yield N('Biscuit is unsettled. Dogs feel the weather.');
  UI.objective('');G.timers.push({t:5,fn:()=>{if(F().ellie_call)return;F().ringing=1;UI.objective('Answer your phone.');Snd.play('ring',{n:3});murmur('Your phone is ringing.');G.ringT=9;}});},
 *d3Street(){murmur('Bow Road, mid-afternoon. Hardly any traffic. It’s rather peaceful.');UI.objective('Get supplies from Adeyemi’s before the 6 p.m. lockdown.');},
 *okafor3(){const e=G.map.ents.find(x=>x.style==='okafor');yield* talk(e,function*(){const f=F();
  if(f.ok3){yield say('OKAFOR','Lovely afternoon.');return;}f.ok3=1;
  yield say('OKAFOR','Isn’t it a lovely afternoon, Rowan? So peaceful.');
  yield say('OKAFOR','I slept like a baby last night. First time in years.');
  const c=yield ask(['“You seem well.”','“Mrs Okafor, are you feeling alright?”']);
  yield say('OKAFOR','Oh, I’ve never felt better, love. Never better.');});},
 *lenaOut(){const e=G.map.ents.find(x=>x.style==='lena');yield* talk(e,function*(){if(F().lena0){yield say('LENA','Come on, come on…');return;}F().lena0=1;
  yield say('LENA','Sorry — are you queueing? They’re only letting three in at a time.');
  yield say('LENA','She’s three months. We ran out of formula yesterday and everywhere’s been cleared out.');
  yield say('LENA','You’re not… you’re not sick, are you? You look really… calm.');
  const c=yield ask(['“I’m fine.”','“I feel fine.”']);
  yield say('LENA','Right. Sorry. Everyone’s just… sorry.');});},
 *soldier(){const p=PH();yield say('SOLDIER',p==='d3_dusk'?'Curfew’s in force. Get inside. Now, please.':'Station’s closed. Go home.');},
 *shopTV(){yield say('TV','…the Prime Minister has urged the public to remain calm. Supermarkets are being asked to limit purchases to three of any item…');yield say('TV','…and we’re hearing reports this afternoon of a disturbance outside St Thomas’ Hospital, where crowds gathered—');yield N('Tunde turns the volume down.');},
 *d3Shop(){murmur('Half the shelves are bare. The rest are being emptied as you watch.');UI.objective('Take what you need.');},
 *tunde3(){const e=G.map.ents.find(x=>x.style==='tunde');yield* talk(e,function*(){const f=F();
  if(f.t3){yield say('TUNDE','Take what you need, Rowan. Go on.');return;}f.t3=1;
  yield say('TUNDE','Rowan! Take what you need. Money won’t matter much after six o’clock.');
  const c=yield ask(['“Are you staying open?”','“Thank you, Tunde.”']);
  if(c===0)yield say('TUNDE','Where would I go? This is my shop. Thirty-one years.');else yield say('TUNDE','Say hello to your sister for me. Tell her to come and see me when this is over.');});},
 *okaforShop(){const e=G.map.ents.find(x=>x.style==='okafor');yield* talk(e,function*(){const f=F();
  if(f.okw!==undefined){yield say('OKAFOR','Lovely afternoon.');return;}
  yield say('OKAFOR','Here, love. Take mine.');yield say('OKAFOR','I won’t be needing it.');
  const c=yield ask(['Take the water','“Keep it, Mrs Okafor.”']);f.okw=c===0?1:0;
  if(c===0){giveItem('water');yield N('She smiles. She won’t be needing it.');}else yield say('OKAFOR','Suit yourself, love.');});},
 *lenaShop(){const e=G.lena;yield* talk(e,function*(){const f=F();
  if(f.lena!==undefined){yield say('LENA',f.lena===0?'…':'Thank you. Really.');return;}
  yield say('LENA','They’re saying not to drink the tap water. I need clean water to make up her bottles.');});},
 *waterDilemma(){const f=F();if(f.lena!==undefined){yield N('Empty.');return;}
  const e=G.lena;yield N('One pack of water left. Two bottles.');
  if(e){e.talking=true;e.facePlayer();}
  yield say('LENA','Please. It’s for the formula. She can’t have tap — they’re saying the tap might be— please.');
  const c=yield ask(['Give her the water','Split it with her','Take it yourself']);
  if(c===0){f.lena=1;yield say('LENA','Thank you. Thank you.');yield N('She holds the bottles like they’re made of glass.');}
  else if(c===1){f.lena=2;giveItem('water');yield say('LENA','Okay. Okay — thank you.');}
  else{f.lena=0;giveItem('water',2);G.stats.sanity=Math.max(0,G.stats.sanity-6);yield say('LENA','…Right. Course.');yield N('She doesn’t look at you again.');}
  if(e)e.talking=false;},
 *shopLeave(){const p=PH();
  if(p==='d3_shop'){if(F().lena===undefined){const c=yield ask(['Leave','Stay']);if(c===1)return;}
   Snd.play('buzz');yield phone(`<div style="font-size:.55em;letter-spacing:.2em;color:#e0a24a;margin-bottom:.6em">⚠ EMERGENCY ALERT</div><div style="font-size:.66em;line-height:1.55;color:#e9edf0">Severe alert. A stay-at-home order is now in force across Greater London. Stay indoors. Do not travel. Await further instructions.</div><div class="foot" style="text-align:center"><kbd>E</kbd> CLOSE</div>`);
   yield go('d3_dusk');}
  else if(p==='a1_shop')yield go('a1_street',{pos:[tx(42),ty(10)-2],dir:0});},
 *d3Dusk(){Snd.play('siren');murmur('Six o’clock. Somewhere a siren starts, and then another.');UI.objective('Go home.');G.timers.push({t:12,fn:()=>Snd.play('siren')});},
 *d3Night(){yield wait(.6);
  yield N('The street goes quiet all at once, like a held breath.');
  yield N('Ellie’s phone goes straight to voicemail. No service. No anything.');
  yield N('Tomorrow you will go north. To the Barbican. To Ellie.');
  yield N('Tonight, you should rest.');UI.objective('Sleep.');},
// ---------- ACT I ----------
 *a1Flat(){
  yield wait(1.5);
  yield N('You wake on the sofa. You don’t remember lying down.');
  yield N('It’s dark. The power is off. It has been off for a while.');
  yield N('You’re thirsty. Very thirsty.');
  UI.objective('Find a light.');
  yield N('There’s a torch in the kitchen drawer. There always has been.');
  UI.hint('DARKNESS DRAINS <span style="color:#b9a6e0">SANITY</span>. FIND A LIGHT.',8);},
 *a1Street(){murmur('Bow Road. No traffic. No lights. Just the rain.');UI.objective('Find water. Try Adeyemi’s.');
  G.timers.push({t:9,fn:()=>murmur('People are sleeping in their cars. Let them rest.',5)});},
 firstHollow(h){G.timers.push({t:.4,fn:()=>{murmur('Something moves in the dark. One of the Hollowed.',4);Snd.play('sting');}});G.timers.push({t:4.6,fn:()=>murmur('They were people, once. They aren’t any more.',4)});
  G.timers.push({t:.6,fn:()=>UI.hint('<kbd>SPACE</kbd> ATTACK &nbsp; <kbd>Q</kbd> DODGE &nbsp; <kbd>SHIFT</kbd> RUN',7)});},
 onKill(h){if(F().kills===1)G.timers.push({t:1,fn:()=>murmur('It had to be done.',3)});},
 *okaforA1(){yield N('Mrs Okafor, sitting on her step in the rain.');yield N('Resting.');},
 *sleeperGeneric(){yield N(pick(['Sleeping. Let them sleep.','Resting. They look so peaceful.','Fast asleep. You don’t wake them.']));G.stats.sanity=Math.max(0,G.stats.sanity-2);},
 *carSleeper(){yield N('Someone asleep at the wheel, head tipped against the glass.');yield N('You don’t wake them.');G.stats.sanity=Math.max(0,G.stats.sanity-2);},
 *searchCar(){if(F().car1){yield N('Nothing else.');return;}F().car1=1;giveItem('batt');yield N('Glovebox: a parking ticket, a phone charger, two batteries.');},
 *a1Shop(){murmur('Someone has been here before you. A lot of someones.');UI.objective('Search the shop.');},
 *radioA1(){const f=F();
  if(f.radioA1){Snd.set('static',.02,.1);yield N('Static.');Snd.set('static',0,.3);return;}f.radioA1=1;f.clue_radio2=1;
  yield N('A wind-up radio on the boxes. You crank it.');Snd.set('static',.025,.1);yield wait(1.2);
  yield say('RADIO','—repeat. Infected individuals do not show fever or cough. They may appear calm. Friendly. Eager to help.',{fast:0});
  yield say('RADIO','They will try to get close to you. Do not let them—',{fast:1});
  Snd.set('static',.06,.05);UI.flash('#000',.4,.6);yield wait(.5);Snd.set('static',.015,.2);
  yield N('Static. Nothing useful.');Snd.set('static',0,.6);},
 *rest(){const f=F();if(f.restA1){yield N('You’ve rested.');return;}
  if(countItem('water')===0&&G.stats.thirst<40){yield N('You need water first. You can’t rest like this.');return;}
  f.restA1=1;
  yield N('The stockroom door locks from the inside. Good.');
  G.stats.sanity=Math.min(100,G.stats.sanity+25);G.stats.health=Math.min(100,G.stats.health+20);
  Story.checkpoint([tx(12),ty(3)+2]);
  yield N('Tomorrow, north. The Barbican. Ellie.');
  yield fade(1,2.2);
  yield N('We should rest.');
  yield wait(1.6);
  yield N('You should rest.');F().clue_we=1;
  yield wait(1.4);
  Story.endStage();},
};

// ================= PHASES =================
const PHASES={
 title:{map:'street',spawn:[tx(30),ty(14)]},
 d1_wake:{map:'flat',spawn:[54,66],dir:0,card:['MONDAY','12 October · Bow, East London'],clock:'06:40',decay:[.008,.012],enter:S.d1Wake},
 d1_street:{map:'street',spawn:[tx(9),ty(10)-3],dir:0,clock:'07:12',enter:S.d1Street},
 d1_lab:{map:'lab',spawn:[tx(4),ty(12)],dir:3,card:['GALLIONS REACH','Twenty-six minutes of looking at your phone'],clock:'08:05',enter:S.d1Lab},
 d1_night:{map:'flat',spawn:[tx(6),ty(10)-3],dir:3,card:['EVENING','Biscuit has eaten a sock. He seems proud of it.'],clock:'19:40',enter:S.d1Night},
 d2_lab:{map:'lab',spawn:[tx(4),ty(12)],dir:3,card:['TUESDAY','13 October'],clock:'08:10',enter:S.d2Lab},
 d2_walk:{map:'street',spawn:[tx(9),ty(10)-3],dir:0,card:['EVENING','Biscuit needs a walk'],clock:'21:05',enter:S.d2Walk},
 d3_wake:{map:'flat',spawn:[54,66],dir:0,card:['WEDNESDAY','14 October'],clock:'09:30',enter:S.d3Wake},
 d3_street:{map:'street',spawn:[tx(9),ty(10)-3],dir:0,clock:'15:10',enter:S.d3Street},
 d3_shop:{map:'shop',spawn:[tx(7),ty(9)-2],dir:3,clock:'15:25',enter:S.d3Shop},
 d3_dusk:{map:'street',spawn:[tx(42),ty(10)-3],dir:0,clock:'17:58',enter:S.d3Dusk},
 d3_night:{map:'flat',spawn:[tx(6),ty(10)-3],dir:3,clock:'18:20',enter:S.d3Night},
 a1_flat:{map:'flat',spawn:[206,150],dir:3,clock:'--:--',enter:S.a1Flat,setup(){
  G.stats={health:82,hunger:42,thirst:28,sanity:62,hum:38};G.inv=G.inv.filter(s=>ITEMS[s.id].key&&s.id!=='torch');G.equip=null;P.battery=0;P.torch=false;
  G.sanityOn=true;G.showHum=true;G.lullAllowed=true;F().canFight=true;G.decay={hunger:.03,thirst:.05};F().netDown=1;UI.hotbar();}},
 a1_street:{map:'street',spawn:[tx(9),ty(10)-3],dir:0,enter:S.a1Street},
 a1_shop:{map:'shop',spawn:[tx(7),ty(9)-2],dir:3,enter:S.a1Shop},
};
// ================= STORY CONTROL =================
const Story={
 goto(phase,o={},cb){const ph=PHASES[phase];G.cut=true;
  UI.fade(1,o.fast?.3:.7,()=>{
   const after=()=>{loadPhase(phase,o);UI.fade(0,.9,()=>{cb&&cb();});};
   const cd=o.card||(!o.nocard&&ph.card);
   if(cd){if(o.glitchCard){Snd.play('glitch');setTimeout(()=>{$('#cardTitle').classList.add('glitch');setTimeout(()=>$('#cardTitle').classList.remove('glitch'),700);Snd.play('glitch');},1400);}UI.card(cd[0],cd[1],after,cd[2]||2.2);}
   else after();});},
 checkpoint(pos){const cp={phase:G.phase,pos:pos||null,dir:P.dir,stats:Object.assign({},G.stats),inv:JSON.parse(JSON.stringify(G.inv)),equip:G.equip,flags:Object.assign({},G.flags),notes:G.notes.slice(),battery:P.battery,showHum:G.showHum,sanityOn:G.sanityOn,lullAllowed:G.lullAllowed,decay:Object.assign({},G.decay),objective:G.objective,clock:G.clock,ver:1};
  G.checkpointData=cp;store('lull_save',cp);},
 restore(cp){G.stats=Object.assign({},cp.stats);G.inv=JSON.parse(JSON.stringify(cp.inv));G.equip=cp.equip;G.flags=Object.assign({},cp.flags);G.notes=cp.notes.slice();P.battery=cp.battery;P.torch=false;
  G.showHum=cp.showHum;G.sanityOn=cp.sanityOn;G.lullAllowed=cp.lullAllowed;G.decay=Object.assign({},cp.decay);G.clock=cp.clock;G.lull=null;G.extraBodies=null;P.pose=null;
  Script.kill();G.timers=[];G.waiters=[];G.checkpointData=cp;UI.objective(cp.objective||'');
  loadPhase(cp.phase,{pos:cp.pos,dir:cp.dir,restore:!!cp.pos,fromCp:1});UI.hotbar();
  if(cp.phase==='a1_shop'&&G.flags.restA1){UI.objective('Sleep on the bedroll until morning.');G.timers.push({t:1.2,fn:()=>murmur('The stockroom. The bedroll. Morning will come.',4)});}},
 endStage(){G.state='end';UI.hudOn(false);Snd.set('drone',0,2);Snd.set('hum',0,2);
  UI.card('LULL','End of Stage One · Act I continues in the next build',()=>{setTimeout(()=>Game.toTitle(),400);},5);},
};
function loadPhase(phase,o={}){
 const ph=PHASES[phase];G.phase=phase;
 G.bubbles.forEach(b=>b.el&&b.el.remove());G.bubbles=[];G.parts=[];G.phantoms=[];G.extraBodies=null;G.ringT=0;
 if(!o.restore&&!o.fromCp&&ph.setup)ph.setup();
 const sp=o.pos||ph.spawn;P.x=sp[0];P.y=sp[1];P.dir=o.dir!==undefined?o.dir:(ph.dir||0);P.fx=[0,-1,1,0][P.dir];P.fy=[1,0,0,-1][P.dir];
 P.pose=null;P.swing=-1;P.dodgeT=0;P.hidden=phase==='title';P.stam=100;
 G.dog=null;G.lena=null;G.theo=null;G.mara=null;G.loopN=0;
 G.map=BUILD[ph.map]();
 G.cam.x=P.x;G.cam.y=P.y-10;
 if(ph.clock)G.clock=ph.clock;if(ph.decay)G.decay={hunger:ph.decay[0],thirst:ph.decay[1]};
 const s=G.map.snd;['rain','wind','room','drone','buzz','static'].forEach(k=>Snd.set(k,s[k]||0,1.5));Snd.set('fire',G.map.emitters.length?.035:0,1.5);
 Snd.dronePitch(G.sanityOn?1:1.06);
 if(phase==='title')return;
 G.state='play';UI.hudOn(true);UI.hotbar();UI.objective(G.objective);
 if(!o.restore&&!ph.nocp){Story.checkpoint();}
 if(!o.restore&&ph.enter&&!G.flags['entered_'+phase]){G.flags['entered_'+phase]=1;Script.run(ph.enter);}
}
