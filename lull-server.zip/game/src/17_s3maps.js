// ================= STAGE 3 MAPS =================
const PKs=(m,x,y,it,flag)=>{if(!G.flags[flag])m.ents.push(new Pickup(x,y,it,1,{flag}));};
const HOLs=(m,x,y,flag,o)=>{if(!G.flags[flag])m.ents.push(new Hollow(x,y,Object.assign({flag,guard:75},o)));};
function retile(m,x0,y0,x1,y1,map){for(let j=y0;j<=y1;j++)for(let i=x0;i<=x1;i++){const t=m.tile(i,j);if(map[t]!==undefined)m.set(i,j,map[t]);}m.tc=null;}
function dropProp(m,p){m.props=m.props.filter(q=>q!==p);if(p.box)m.solids=m.solids.filter(b=>b!==p.box);}
// ---------------- CITY: Bethnal Green Road / Columbia Road ----------------
function buildCity(){
 const m=new GMap('city',100,34,T.roof);m.outdoor=true;const f=G.flags;const r=RNG(91);
 // north facades
 for(let x=0;x<100;x++){m.set(x,14,r()<.55?T.brickWin:T.brick);m.set(x,15,r()<.3?T.brickWin:(r()<.35?T.shutter:(r()<.4?T.shopFrontDark:T.brick)));}
 for(let x=56;x<=64;x++){m.set(x,14,T.glassF);m.set(x,15,T.glassF);}m.set(60,15,T.glassDoor);
 // Ellie's block
 for(let x=68;x<=78;x++){m.set(x,13,T.flatF);m.set(x,14,T.flatF);m.set(x,15,T.flatF);}m.set(73,15,T.flatDoorX);
 // Bethnal Green station
 for(let x=89;x<=97;x++){m.set(x,14,T.stationF);m.set(x,15,T.stationF);}m.set(93,15,T.stationIn);
 // the pub (interior rows 9-14, x 12-22)
 m.rect(11,8,13,1,T.P);m.rect(11,8,1,8,T.P);m.rect(23,8,1,8,T.P);m.rect(12,9,11,6,T.wood);
 for(let x=12;x<=22;x++)m.set(x,15,(x===14||x===20)?T.pubWin:T.pubFront);m.set(17,15,T.pubDoor);
 // Columbia Road market (x 34-52, rows 2-15)
 for(let x=34;x<=52;x++){m.set(x,2,x%3?T.brickWinY:T.brickY);m.set(x,3,x%4===1?T.brickDoorY:(x%2?T.brickWinY:T.brickY));}
 m.rect(34,4,19,12,T.cobble);m.rect(33,2,1,14,T.brick);m.rect(53,2,1,14,T.brick);
 // street
 for(let x=0;x<100;x++){m.set(x,16,T.pave);m.set(x,17,T.paveCB);m.set(x,18,T.asphYelT);m.set(x,19,T.asph);m.set(x,20,T.asph);m.set(x,21,T.asphDash);m.set(x,22,T.asph);m.set(x,23,T.asph);m.set(x,24,T.asphYelB);m.set(x,25,T.paveCT);m.set(x,26,T.pave);m.set(x,27,T.fenceP);}
 // churchyard south (x 20-50)
 m.rect(20,28,31,6,T.grass);m.rect(33,27,2,1,T.pave);m.rect(33,28,2,6,T.gravel);m.rect(20,28,1,6,T.hedge);m.rect(50,28,1,6,T.hedge);m.rect(20,33,31,1,T.hedge);
 m.ambient={a:.5,c:'16,18,24'};m.rain=.2;m.fog=.06;m.snd={rain:.1,wind:.1,drone:.05};m.grade={c:'rgba(120,130,140,.35)',op:'saturation'};
 // props: market
 [[37,7],[44,7],[50,7],[37,11],[46,11]].forEach(([x,y])=>m.prop('stall',tx(x),ty(y)));
 [[40,13],[49,5],[35,13]].forEach(([x,y])=>m.prop('buckets',tx(x),ty(y)));
 m.decals.push((c,ox,oy)=>{const rr=RNG(5);for(let i=0;i<120;i++){c.fillStyle=DEADF[(rr()*7)|0];c.fillRect((tx(34)+rr()*300|0)-ox,(ty(3)+rr()*190|0)-oy,2,1);}});
 // churchyard
 const rr=RNG(12);for(let i=0;i<14;i++){const gx=tx(22)+((i%7)*36)+(rr()*8|0),gy=ty(29)+((i/7|0)*40)+(rr()*6|0);if(Math.abs(gx-tx(33.5))<20)continue;m.prop('grave',gx,gy,{v:''+(i%3)});}
 [[24,31],[46,30]].forEach(([x,y])=>m.prop('tree',tx(x),ty(y)));
 // street props
 [[6,17],[26,17],[54,17],[82,17],[14,26],[40,26],[66,26],[88,26]].forEach(([x,y])=>m.prop('lamp',tx(x),ty(y)-2,{on:false}));
 [[4,19,0],[28,19,2],[48,23,5],[80,19,3],[86,23,1]].forEach(([x,y,c])=>m.prop('car',tx(x),ty(y)-2,{c,dirty:1,occ:c===2}));
 m.prop('bus',tx(62),ty(23),{dirty:1});m.prop('burnt',tx(20),ty(23)-2);m.emitters.push({x:tx(20),y:ty(23)-8,w:8,rate:.12,cols:['#2a2a2c','#3a3a3c','#4a4a4c']});
 m.prop('shelter',tx(44),ty(26)-1);m.prop('bin',tx(10),ty(16)-3);m.prop('bin',tx(66),ty(16)-3);m.prop('postbox',tx(30),ty(16)-2);
 m.prop('pubsign',tx(17)+8,ty(14)-2);
 // pub interior
 m.prop('pubbar',tx(15),ty(10)+6);m.prop('pubtable',tx(20),ty(11));m.prop('pubtable',tx(13),ty(13)+2);m.prop('bench',tx(20),ty(13)+6,{interact:I('Bench',S.pubRest)});
 m.prop('lantern',tx(12)+4,ty(9)+6,{on:1});m.prop('lantern',tx(22)-2,ty(9)+6,{on:1});
 m.light(tx(17),ty(11),90,.9,'255,190,120',{flick:.08,gk:1.2});m.light(tx(13),ty(13),60,.6,'255,190,120',{flick:.1});
 m.safe=()=>P.y<ty(15)&&P.x>tx(11)&&P.x<tx(23);
 const des=npc(m,tx(18),ty(10)+8,'desmond',{fixedDir:0,clean:1,interact:I('The landlord',S.desmond)});
 if(!f.poppyGone)npc(m,tx(21),ty(12)+6,'poppy',{fixedDir:1,pose:'sit',scale:.75,clean:f.inf_pub?0:1,interact:I('A girl',S.poppy)});
 // calm people at the market
 npc(m,tx(43),ty(9),'c6',{fixedDir:0,smile:true,infected:1,interact:I('The flower seller',S.flowerSeller),barks:['Fresh this morning!','Aren’t they lovely?','Take some, love. Take some.'],barkR:70});
 npc(m,tx(9),ty(16)-2,'c3',{fixedDir:0,pose:'sit',smile:true,infected:1,interact:I('A man on the kerb',S.calmMan)});
 // sleepers
 m.ents.push(new Sleeper(tx(39),ty(9)+2,'p2',{pose:'lie',smile:true,interact:I('Someone between the stalls',S.sleeperGeneric)}));
 m.ents.push(new Sleeper(tx(48),ty(13),'c4',{pose:'sit',smile:true,dir:0,interact:I('Someone by the buckets',S.sleeperGeneric)}));
 m.ents.push(new Sleeper(tx(28),ty(31),'p5',{pose:'lie',smile:true,interact:I('Someone among the graves',S.sleeperGeneric)}));
 m.ents.push(new Sleeper(tx(44),ty(26)-8,'c1',{pose:'sit',smile:true,dir:0,interact:I('Someone at the bus stop',S.sleeperGeneric)}));
 // hollowed
 HOLs(m,tx(36),ty(5),'hx1',{truth:'t2',drop:{item:'water',flag:'pk_xw1'}});HOLs(m,tx(51),ty(10),'hx2',{truth:'t3'});
 HOLs(m,tx(70),ty(21),'hx3',{truth:'t1',lines:['Get back!','Don’t — please —','STAY AWAY FROM US!']});HOLs(m,tx(34),ty(21),'hx4',{truth:'p4'});HOLs(m,tx(8),ty(22),'hx5',{truth:'t2',drop:{item:'bandage',flag:'pk_xb'}});
 HOLs(m,tx(40),ty(31),'hx6',{truth:'p1',guard:60,lines:['Leave her be!','We’re burying her, please—','GO AWAY!']});
 // pickups
 PKs(m,tx(41),ty(5),'cordial','pk_cord10');PKs(m,tx(26),ty(30),'batt','pk_xbt');PKs(m,tx(84),ty(26)-4,'beans','pk_xbn');PKs(m,tx(54),ty(16)-2,'crisps','pk_xcr');PKs(m,tx(13),ty(11),'water','pk_xpw');
 // exits
 m.exit(93,15,'Bethnal Green station',function*(){yield N('Not back down there.');});
 m.exit(73,15,'Ellie’s building',S.ellieEnter);
 m.exit(60,15,'Office lobby',function*(){yield N('Locked. Through the glass: a reception desk, and three people sitting very still in the waiting chairs.');});
 for(let y=16;y<=26;y++)m.exit(0,y,'West, towards Old Street',S.cityWest);
 m.zone(tx(33),ty(4),tx(53)-tx(33),ty(16)-ty(4),()=>murmur('Columbia Road. Every Sunday for a hundred years, a flower market. Nobody has watered them.',5));
 m.zone(tx(11),ty(9),tx(23)-tx(11),ty(15)-ty(9),S.pubEnter);
 theoFollower(m,P.x+10,P.y);
 m.finalize();return m;
}
// ---------------- ELLIE'S FLAT ----------------
function buildEllie(){
 const m=new GMap('ellie',24,13,T.void);const f=G.flags;
 const rows=['PPQQPPPPPPPPPPPPQQPPQQPP'];
 for(let j=1;j<=5;j++)rows.push('P'+'b'.repeat(7)+'P'+'h'.repeat(6)+'P'+'k'.repeat(7)+'P');
 rows.push('PPPPdPPPPPPdPPPPPPdPPPPP');
 for(let j=7;j<=11;j++)rows.push('P'+'l'.repeat(22)+(j===9?'Q':'P'));
 rows.push('PPPPPPPPPPPEPPPPPPPPPPPP');
 m.ascii(rows,{P:'P',Q:'Q',b:'carpetR',h:'btile',k:'kwhite',l:'carpetB',d:'doorway',E:'exitP'});
 m.ambient={a:.9,c:'6,8,14'};m.snd={room:.06,drone:.07,rain:.04};
 [[64,26],[296,26],[352,26]].forEach(([x,y])=>m.light(x,y,56,.3,'160,175,205',{gk:.4}));m.light(366,150,50,.28,'160,175,205');
 // bedroom
 m.bedP=m.prop('bed',36,52,{v:'ellie'});m.prop('wardrobe',110,30);m.prop('plant',120,92);m.prop('rug',64,84);
 // bathroom
 m.prop('bath',176,34);m.prop('mirror',216,16,{dyn:1});m.prop('sink',216,34,{interact:I('Mirror',S.ellieMirror)});
 // kitchen
 m.prop('fridge',272,40,{interact:I('Fridge',S.ellieFridge)});m.prop('counter',288,40);m.prop('counter',304,40,{v:'sink'});m.prop('counter',320,40,{v:'kettle'});m.prop('counter',336,40,{v:'hob'});m.prop('counter',352,40,{v:'drawer'});
 m.prop('table',330,90,{v:'notes',interact:I(()=>f.letterRead?'Ellie’s letter':'A letter on the table',S.ellieLetter)});m.prop('chair',312,86);m.prop('chair',348,86);
 // living
 m.prop('answerphone',40,150,{interact:I(()=>f.vmDone?'Answerphone':'Answerphone (blinking)',S.answerphone)});
 m.prop('sofaB',96,186);m.prop('ctable',96,160);m.prop('shelf',150,124);m.prop('plant',14,124);m.prop('plant',360,186);m.prop('lampF',60,124,{on:false});
 m.decals.push((c,ox,oy)=>{[[180,118],[200,120],[220,117]].forEach(([x,y],i)=>{c.fillStyle='#c8b27a';c.fillRect(x-ox,y-oy,10,8);c.fillStyle=i===1?'#8aa2b4':'#a89a8a';c.fillRect(x+1-ox,y+1-oy,8,6);});});
 m.zone(tx(1),ty(1)-16,tx(8)-tx(1),ty(6)-ty(1),S.ellieBedroom);
 m.exit(11,12,'Front door',S.ellieLeave);
 theoFollower(m,P.x+10,P.y);
 // apply morph stages already reached (on reload)
 if(f.em1)morph1(m);if(f.em2)morph2(m);if(f.em3)morph3(m);
 m.finalize();return m;
}
function morph1(m){if(m.m1)return;m.m1=1;m.prop('bowl',190,180,{v:'full'});m.prop('dogbed',230,186);m.prop('toolbox',300,186);}
function morph2(m){if(m.m2)return;m.m2=1;retile(m,1,1,7,5,{[T.carpetR]:T.carpet});if(m.bedP){m.bedP.o={v:''};m.bedP.interact=I('Your bed',S.ellieBedNote);}}
function morph3(m){if(m.m3)return;m.m3=1;retile(m,16,1,22,5,{[T.kwhite]:T.ktile});retile(m,1,7,22,11,{[T.carpetB]:T.wood});m.prop('tv',184,124);}
// ---------------- APPROACH: Old Street -> Beech Street -> the Barbican ----------------
function buildApproach(){
 const m=new GMap('approach',120,32,T.roof);m.outdoor=true;const f=G.flags;const r=RNG(55);
 // Old Street (x 64-119)
 for(let x=64;x<120;x++){m.set(x,8,r()<.5?T.glassL:T.glassF);m.set(x,9,r()<.3?T.glassL:T.glassF);}
 for(let x=64;x<=75;x++){m.set(x,7,T.brutTop);m.set(x,8,T.brutWin);m.set(x,9,x%3?T.brutWin:T.brut);}
 for(let x=64;x<120;x++){m.set(x,10,T.pave);m.set(x,11,T.paveCB);m.set(x,12,T.asphYelT);m.set(x,13,T.asph);m.set(x,14,T.asph);m.set(x,15,T.asphDash);m.set(x,16,T.asph);m.set(x,17,T.asph);m.set(x,18,T.asphYelB);m.set(x,19,T.paveCT);m.set(x,20,T.pave);}
 for(const gx of [86,101]){m.rect(gx,0,4,10,T.asph);m.rect(gx,0,1,10,T.pave);m.rect(gx+3,0,1,10,T.pave);}
 for(const gx of [79,95]){m.rect(gx,21,4,11,T.asph);m.rect(gx,21,1,11,T.pave);m.rect(gx+3,21,1,11,T.pave);}
 // Beech Street tunnel (x 32-63)
 m.rect(32,0,32,9,T.brutTop);for(let x=32;x<64;x++){m.set(x,9,T.tunW);m.set(x,21,T.tunW);}
 for(let x=32;x<64;x++){m.set(x,10,T.pave);m.set(x,11,T.paveCB);m.set(x,12,T.asphYelT);m.set(x,13,T.asph);m.set(x,14,T.asph);m.set(x,15,T.asphDash);m.set(x,16,T.asph);m.set(x,17,T.asph);m.set(x,18,T.asphYelB);m.set(x,19,T.paveCT);m.set(x,20,T.pave);}
 m.rect(32,22,32,10,T.brutTop);
 // Barbican gate plaza (x 0-31)
 m.rect(0,0,32,3,T.brutTop);m.rect(0,3,32,5,T.brut);for(let x=0;x<32;x++){m.set(x,6,x%2?T.brutWin:T.brut);}
 m.rect(9,3,11,4,T.podium);for(let x=13;x<=15;x++)m.set(x,7,T.gateSteel);
 m.rect(0,8,32,13,T.podium);m.rect(0,21,32,11,T.brutTop);m.rect(9,21,4,11,T.asph);m.rect(8,21,1,11,T.pave);m.rect(13,21,1,11,T.pave);
 const del=f.ending==='delivery';m.rect(1,18,3,3,del?T.rampDn:T.rampShut);
 // ambience: dusk into night
 m.ambient={a:.86,c:'8,8,18'};m.rain=.35;m.fog=.09;m.snd={rain:.18,wind:.12,drone:.12};
 // lamps on Old Street (a few still on)
 [[70,10],[84,10],[98,10],[112,10]].forEach(([x,y],i)=>{m.prop('lamp',tx(x),ty(y)-2,{on:i!==1});if(i!==1)m.lights[m.lights.length-1].flick=.5;});
 [[66,20],[90,20],[106,20]].forEach(([x,y])=>m.prop('lamp',tx(x),ty(y)-2,{on:false}));
 [[72,13,1],[92,17,4],[108,13,6],[116,17,2]].forEach(([x,y,c])=>m.prop('car',tx(x),ty(y)-2,{c,dirty:1}));
 m.prop('barrierR',tx(66),ty(13)+4);m.prop('cone',tx(68),ty(15));m.prop('cone',tx(70),ty(16));
 // tunnel strip lights (die behind you)
 m.tunL=[];for(let x=34;x<63;x+=3){const L=m.light(tx(x),ty(10)+2,62,.62,'215,225,235',{flick:.15});L.tun=1;m.tunL.push(L);}
 for(let x=34;x<63;x+=3){const L=m.light(tx(x)+24,ty(20)-2,48,.4,'215,225,235',{flick:.2});L.tun=1;m.tunL.push(L);}
 m.decals.push((c,ox,oy)=>{for(const L of m.tunL){if(L.y>ty(15))continue;c.fillStyle=L.on?'#e8f0f4':'#3a3e42';c.fillRect(L.x-6-ox,ty(9)+11-oy,12,2);}});
 // gate plaza
 m.prop('flood',tx(6),ty(9)+8,{on:1});m.prop('flood',tx(24),ty(9)+8,{on:1});
 m.prop('wire',tx(6),ty(12));m.prop('wire',tx(24),ty(12));m.prop('sandbags',tx(10),ty(9)+4);m.prop('sandbags',tx(19),ty(9)+4);
 m.prop('intercom',tx(17)+6,ty(8)+6,{interact:I('Intercom',S.intercom)});
 m.prop('barrierR',tx(10)+8,ty(21)+6);m.prop('wire',tx(11),ty(22)+6);
 m.light(tx(14),ty(5),70,.55,'235,240,255');m.light(tx(17)+6,ty(8)+2,46,.5,'200,230,210');
 const g=npc(m,tx(11),ty(5)+4,'guard',{fixedDir:0,clean:1,weapon:'pipe'});m.guard=g;
 if(!f.theoSent&&!f.theoGone)theoFollower(m,P.x+10,P.y);
 // pickups
 PKs(m,tx(88),ty(4),'cordial','pk_cord11');PKs(m,tx(96),ty(26),'water','pk_aw');PKs(m,tx(76),ty(10)+2,'batt','pk_ab');
 HOLs(m,tx(104),ty(15),'hy1',{truth:'t3'});HOLs(m,tx(90),ty(13),'hy2',{truth:'p4',drop:{item:'bar',flag:'pk_ab2'}});HOLs(m,tx(74),ty(17),'hy3',{truth:'t1'});
 // exits
 m.exit(1,18,'Car park',S.carPark);m.exit(2,18,'Car park',S.carPark);m.exit(3,18,'Car park',S.carPark);
 for(let x=9;x<=12;x++)m.exit(x,31,'South, towards the river',S.southRoad);
 for(let y=10;y<=20;y++)m.exit(119,y,'Back east',function*(){yield N('No. Not back. Not now.');});
 m.zone(tx(64),ty(8),tx(2),ty(14),S.tunnelEnterZ);m.zone(tx(0),ty(8),tx(31),ty(13),S.plazaZ);
 m.tick=dt=>{approachTick(m,dt);};
 m.finalize();return m;
}
// ---------------- CONSERVATORY (Delivery) ----------------
function buildConservatory(){
 const m=new GMap('cons',30,18,T.glassRoof);const dawn=G.flags.consDawn;
 m.rect(1,1,28,16,T.pathC);
 [[2,2,6,3],[10,2,10,2],[22,2,6,3],[2,8,4,5],[24,8,4,5],[8,13,5,3],[17,13,5,3]].forEach(([x,y,w,h])=>m.rect(x,y,w,h,T.planter));
 m.rect(12,6,6,4,T.pondC);m.set(14,17,T.pathC);m.set(15,17,T.pathC);
 m.ambient=dawn?{a:.32,c:'40,30,20'}:{a:.78,c:'10,10,20'};m.snd={room:.04,drone:dawn?0:.05};
 m.grade=dawn?{c:'rgba(255,190,120,.35)',op:'soft-light'}:null;
 [[4,5],[26,5],[6,15],[24,15],[11,4],[19,4]].forEach(([x,y])=>m.prop('bigplant',tx(x),ty(y)));[[9,10],[21,10],[15,15]].forEach(([x,y])=>m.prop('fern',tx(x),ty(y)));
 if(!dawn){[[8,7],[21,7],[11,11],[19,11]].forEach(([x,y])=>{m.prop('lantern',tx(x),ty(y),{on:1});m.light(tx(x),ty(y)-4,64,.75,'255,200,140',{flick:.08});});}
 else{m.shafts.push({x:tx(6),y:0,w:60,dx:40,dy:200,c:'255,220,170',a:.18},{x:tx(18),y:0,w:60,dx:40,dy:200,c:'255,220,170',a:.16});}
 m.cots=[[7,9],[22,9],[8,12],[21,12],[15,12],[12,4],[18,4]];
 m.cots.forEach(([x,y],i)=>m.prop('campbed',tx(x),ty(y),{c:['#7a5a6a','#5a6a8a','#6a7a5a','#8a6a4a'][i%4]}));
 m.finalize();return m;
}
// ---------------- THE RIVER ----------------
function buildRiver(){
 const m=new GMap('river',30,46,T.roof);m.outdoor=true;
 m.rect(0,0,30,2,T.brut);for(let x=0;x<30;x++)m.set(x,2,x%2?T.brutWin:T.brut);
 m.rect(7,2,2,1,T.podium);m.rect(7,3,10,28,T.asph);m.rect(6,3,1,28,T.pave);m.rect(17,3,1,28,T.pave);
 for(let y=3;y<31;y++)if(y%4===0)m.set(12,y,T.asphDash);
 m.rect(18,10,11,16,T.grass);m.rect(18,25,11,1,T.fenceP);m.rect(18,9,11,1,T.fenceP);
 m.rect(0,31,30,4,T.pave);for(let x=0;x<30;x++){if(x<8||x>16)m.set(x,34,T.embank);}
 m.rect(8,35,9,2,T.stairs);m.rect(0,35,8,2,T.embank);m.rect(17,35,13,2,T.embank);
 m.rect(0,37,30,2,T.shingle);m.rect(0,39,30,2,T.mud);m.rect(0,41,30,2,T.thamesS);m.rect(0,43,30,3,T.thames);
 m.ambient={a:.7,c:'14,14,24'};m.rain=0;m.fog=.1;m.snd={wind:.14,drone:.08};
 m.prop('dome',tx(23),ty(22));m.prop('tree',tx(19),ty(13));m.prop('tree',tx(27),ty(14));
 [[6,8],[6,18],[6,28],[17,12],[17,24]].forEach(([x,y])=>m.prop('lamp',tx(x),ty(y)-2,{on:false}));
 m.prop('bench',tx(4),ty(32));m.prop('bench',tx(22),ty(32));
 m.finalize();return m;
}
Object.assign(BUILD,{city:buildCity,ellie:buildEllie,approach:buildApproach,cons:buildConservatory,river:buildRiver});
// flat variant for the Two Minds ending
{const old=BUILD.flat;BUILD.flat=function(){if(PH()!=='a3_tm')return old();const keep=G.phase;G.phase='a2_flat';const m=old();G.phase=keep;
 m.ents=m.ents.filter(e=>e.kind!=='spot');m.ambient={a:.92,c:'4,6,12'};m.lights=[];m.shafts=[];m.light(184,128,60,.5,'150,170,210',{flicker:3});return m;};}
