// ================= CO-OP: characters, walkie-talkie, network-test level =================
// The four neighbours (Roman Road, Bow). Rowan is the solo protagonist.
STY.kofi={skin:'#5b3a29',hair:'#121212',hs:'short',coat:'#c46a2a',coat2:'#9e5420',pants:'#2b3340',shoe:'#1a1a1a',beard:'#141010',hivis:1};
STY.nadia={skin:'#b07e5e',hair:'#1a1210',hs:'pony',coat:'#2e4a6a',coat2:'#243a54',pants:'#23262c',shoe:'#e0e0e0',hivis:1};
STY.jun={skin:'#e0c0a0',hair:'#121212',hs:'beanie',hat:'#22262c',coat:'#1f2328',coat2:'#15181c',pants:'#1a1d22',shoe:'#111'};
const CHAR_INFO={
 rowan:{name:'Rowan',sty:'rowan',flat:'Flat 3',job:'Lab technician'},
 kofi:{name:'Kofi',sty:'kofi',flat:'Flat 1',job:'Pump-hall engineer'},
 nadia:{name:'Nadia',sty:'nadia',flat:'Flat 2',job:'Site safety officer'},
 jun:{name:'Jun',sty:'jun',flat:'Flat 4',job:'Night security'}};
const CHAR_ORDER=['rowan','kofi','nadia','jun'];
const RCOL={amber:'#e0a24a',teal:'#4fb3a9',violet:'#9b86d6',rose:'#d47a8e'};
const PHRASES=['Over here.','I’m fine.','Help me!','Wait.','Where are you?','Yes.','No.','Something’s wrong.'];

ITEMS.walkie={name:'Walkie-talkie',icon:'walkie',desc:'A site radio from Beckton security. Hold R to talk on it, C to change channel.',key:true};
ICONDRAW.walkie=x=>{R(x,'#2a2d31',5,4,7,11);R(x,'#3a3e44',6,5,5,4);R(x,'#7fb3a0',7,6,3,2);R(x,'#1a1c1f',6,10,5,1);R(x,'#1a1c1f',6,12,5,1);R(x,'#1a1c1f',9,0,1,4);R(x,'#c03a2a',10,3,1,1);R(x,'#4a4e54',5,4,1,11);};

// ---------------- the network test level ----------------
// Deterministic: every client builds the same map, so Hollowed (h1..) and pickups (p1..) share ids.
const CO_SPAWNS=[[tx(7),ty(7)],[tx(9),ty(7)],[tx(7),ty(8)],[tx(9),ty(8)]];
function buildNetTest(){
 const m=new GMap('nettest',72,28,T.grass);m.outdoor=true;
 const r=RNG(4041);
 m.rect(0,0,72,4,T.roof);
 for(let x=0;x<72;x++){m.set(x,4,r()<.5?T.brickWin:T.brick);m.set(x,5,r()<.3?T.brickWin:(r()<.3?T.shutter:T.brick));}
 m.rect(0,6,72,3,T.pave);
 for(let x=0;x<72;x++)m.set(x,9,T.fenceP);
 m.rect(0,10,72,2,T.grass);
 m.rect(0,12,72,1,T.copingT);m.rect(0,13,72,4,T.water);m.rect(0,17,72,1,T.coping);
 m.rect(0,18,72,2,T.gravel);m.rect(0,20,72,2,T.grass);m.rect(0,22,72,6,T.hedge);
 for(const bx of [20,44]){m.rect(bx,9,2,1,T.pave);m.rect(bx,10,2,2,T.gravel);m.rect(bx,12,2,6,T.deck);}
 m.ambient={a:.86,c:'4,5,12'};m.rain=.45;m.fog=.08;m.snd={rain:.22,wind:.1,drone:.1};
 // the lit west end (safe), dark east end (torches)
 const lamp=(x,y,flk)=>{m.prop('lamp',x,y,{on:true});if(flk)m.lights[m.lights.length-1].flick=.8;};
 lamp(tx(4),ty(8)-2);lamp(tx(14),ty(8)-2,true);lamp(tx(26),ty(8)-2,true);lamp(tx(10),ty(20)-2);lamp(tx(30),ty(20)-2,true);
 m.prop('brazier',tx(11),ty(7)+4);m.light(tx(11),ty(7),90,.85,'255,140,60',{flick:.25,gk:1.6});m.emitters.push({x:tx(11),y:ty(7)-8,w:4});
 m.safe=()=>P.x<tx(16)&&P.y<ty(9);
 [[24,11],[36,11],[52,11],[64,11],[16,21],[38,21],[56,21],[68,21]].forEach(([x,y])=>m.prop('tree',tx(x),ty(y)));
 m.prop('bench',tx(6),ty(7)-2);m.prop('bench',tx(34),ty(7)-2);
 m.prop('boat',tx(30),ty(16)-2,{c:1,dirty:1});m.prop('boat',tx(58),ty(16)-2,{c:2,dirty:1});
 m.prop('tent',tx(3),ty(19),{c:'#4a5a3a'});m.prop('jerry',tx(6),ty(19)+2);m.prop('boxes',tx(2),ty(7)+2);m.prop('pallets',tx(16),ty(18)+4);
 // Hollowed — ids must stay stable
 const H=(id,x,y,o)=>{const h=new CoHollow(x,y,Object.assign({nid:id},o));m.ents.push(h);return h;};
 H('h1',tx(38),ty(7),{guard:76,truth:'t1'});
 H('h2',tx(50),ty(8),{guard:80,truth:'t2',drop:{item:'bandage'}});
 H('h3',tx(62),ty(7),{guard:80,truth:'p4'});
 H('h4',tx(34),ty(19),{guard:70,truth:'t3'});
 H('h5',tx(50),ty(19),{guard:76,truth:'t1',drop:{item:'water'}});
 H('h6',tx(66),ty(19),{guard:80,truth:'t2'});
 // pickups — ids must stay stable
 const PK=(id,x,y,it)=>{if(!NetGame.taken[id])m.ents.push(new CoPickup(id,x,y,it,1));};
 PK('p1',tx(3),ty(8),'water');PK('p2',tx(13),ty(19),'crisps');PK('p3',tx(24),ty(8),'bandage');PK('p4',tx(28),ty(19),'batt');
 PK('p5',tx(42),ty(8),'beans');PK('p6',tx(46),ty(21),'water');PK('p7',tx(54),ty(7),'choc');PK('p8',tx(60),ty(21),'batt');
 PK('p9',tx(66),ty(8),'cordial');PK('p10',tx(69),ty(20),'pills');PK('p11',tx(40),ty(20),'bread');PK('p12',tx(18),ty(11),'water');
 for(const d of NetGame.drops)m.ents.push(new CoPickup(d.id,d.x,d.y,d.item,d.n||1));
 m.finalize();return m;
}
BUILD.nettest=buildNetTest;
PHASES.co_test={map:'nettest',spawn:CO_SPAWNS[0],dir:0,nocp:true,clock:'02:10'};
