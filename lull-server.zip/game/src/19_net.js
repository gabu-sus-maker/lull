// ================= ONLINE: accounts, cloud saves, co-op =================
// The server (Cloudflare) holds anything that matters. This file only ever
// trusts it for: who you are, pickups, gifts, who hears what.
const ONLINE=/^https?:$/.test(location.protocol);
const NET_PROTO=1;
const escH=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

// ---------------- account ----------------
const Acct={u:null,tok:null,
 load(){const a=_rawStore('lull_acct');if(a&&a.u&&a.tok){this.u=a.u;this.tok=a.tok;}},
 set(u,tok){this.u=u;this.tok=tok;_rawStore('lull_acct',{u,tok});},
 clear(){this.u=null;this.tok=null;storeDel('lull_acct');},
 async api(path,method='GET',body){
  let r;try{r=await fetch(path,{method,headers:Object.assign({'content-type':'application/json'},this.tok?{authorization:'Bearer '+this.tok}:{}),body:body?JSON.stringify(body):undefined});}
  catch(e){return{s:0,j:{error:'Can’t reach the server. Check your connection.'}};}
  let j={};try{j=await r.json();}catch(e){}
  if(r.status===401&&this.tok&&!/login|register|reset/.test(path))this.clear();
  return{s:r.status,j};}
};

// ---------------- cloud saves ----------------
// Solo progress (lull_save / lull_gate / lull_endings) follows the account.
// Nothing is ever deleted silently: anything replaced is kept in lull_backup.
const _rawStore=store;
const CLOUD_KEYS=['lull_save','lull_gate','lull_endings'];
store=function(k,v){const r=_rawStore(k,v);if(v!==undefined&&CLOUD_KEYS.includes(k))Cloud.mark();return r;};
const Cloud={rev:0,dirtyT:0,busy:false,status:'',
 blob(){return{v:1,save:_rawStore('lull_save'),gate:_rawStore('lull_gate'),endings:_rawStore('lull_endings'),t:Date.now()};},
 sum(b){if(!b||(!b.save&&!b.gate&&!(b.endings&&Object.keys(b.endings).length)))return null;const ph=(b.save&&b.save.phase)||'';
  return{stage:ph.startsWith('a3')?3:ph.startsWith('a2')?2:1,endings:Object.keys(b.endings||{}).length,t:b.t||0};},
 label(s){if(!s)return'nothing saved';return`Stage ${s.stage} · ${s.endings} ending${s.endings===1?'':'s'}`+(s.t?` · ${new Date(s.t).toLocaleDateString(undefined,{day:'numeric',month:'short'})} ${new Date(s.t).toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'})}`:'');},
 apply(b){_rawStore('lull_backup',this.blob());
  for(const [k,f] of [['lull_save','save'],['lull_gate','gate'],['lull_endings','endings']]){if(b&&b[f])_rawStore(k,b[f]);else storeDel(k);}},
 mergeEndings(a,b){return Object.assign({},(a&&a.endings)||{},(b&&b.endings)||{});},
 mark(){if(Acct.tok&&!G.coop)this.dirtyT=2.5;},
 tick(dt){if(this.dirtyT>0){this.dirtyT-=dt;if(this.dirtyT<=0)this.push();}},
 async pull(){const r=await Acct.api('/api/save');if(r.s!==200)return{err:r.j.error||'Couldn’t load the cloud save.'};this.rev=r.j.rev;return{data:r.j.data};},
 async push(force){if(!Acct.tok||this.busy)return;this.busy=true;
  try{const r=await Acct.api('/api/save','PUT',{data:this.blob(),baseRev:this.rev,force:!!force});
   if(r.s===200){this.rev=r.j.rev;this.status='Saved to '+Acct.u+' at '+new Date().toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'});}
   else if(r.s===409){ // another device saved meanwhile: keep theirs as a backup, ours wins (it's the one being played)
    _rawStore('lull_backup',r.j.data);this.rev=r.j.rev;this.busy=false;
    const e=this.mergeEndings(r.j.data,this.blob());_rawStore('lull_endings',e);
    toast('Another device saved too — kept as a backup');return this.push(true);}
   else if(r.s===0){this.status='Offline — will retry';this.dirtyT=30;}
   else this.status=r.j.error||'Cloud save failed';
  }finally{this.busy=false;}}
};

// ---------------- the overlay (account + lobby), keyboard only ----------------
const NetUI={open:false,view:null,sel:0,items:[],msg:'',err:false,busy:false,after:null,
 el(){let e=$('#net');if(!e){e=document.createElement('div');e.id='net';e.className='hidden';$('#ui').appendChild(e);}return e;},
 show(view,keepSel){this.view=view;this.open=true;if(!keepSel)this.sel=0;this.items=this.build(view);
  if(this.sel>=this.items.length)this.sel=0;let g=0;while(this.items[this.sel]&&(this.items[this.sel].k==='info'||this.items[this.sel].dis)&&g++<20)this.sel=(this.sel+1)%this.items.length;
  UI._menu=null;
  this.render();},
 close(silent){this.open=false;this.el().classList.add('hidden');this.el().innerHTML='';this.msg='';
  if(document.activeElement&&document.activeElement.tagName==='INPUT')document.activeElement.blur();
  if(!silent&&G.state==='title'&&Game._tm){const it=Game._tm.items.find(i=>i.id==='a');if(it)it.t=Acct.u?'Account: '+Acct.u:'Sign in';Game.titleMenu();}},
 say(m,err){this.msg=m||'';this.err=!!err;const e=$('#netMsg');if(e){e.textContent=this.msg;e.className=this.err?'err':'';}},
 val(id){const e=$('#'+id);return e?e.value:'';},
 build(v){
  const A=Acct.u,I=[];
  const info=(t,cls)=>I.push({k:'info',t,cls});const btn=(id,t,o={})=>I.push(Object.assign({k:'btn',id,t},o));const inp=(id,t,type,ac,o={})=>I.push(Object.assign({k:'in',id,t,type,ac},o));
  if(!ONLINE){info('Online play needs the game to be opened from your server address, not from a file.');info('Ask whoever runs the server for the link.');btn('back','Back');return I;}
  switch(v){
   case 'acct':if(A){info('Signed in as '+A,'big');info(Cloud.status||'Your solo progress is saved to this account.');btn('sync','Sync now');btn('out','Sign out');btn('back','Back');}
    else{info('An account keeps your progress on any computer and lets you play together.');btn('login','Sign in');btn('reg','Create an account');btn('reset','I have a reset code');btn('back','Back');}break;
   case 'login':inp('ni_user','Username','text','username');inp('ni_pass','Password','password','current-password');btn('doLogin','Sign in',{def:1});btn('acct','Back');break;
   case 'reg':info('Use a password you don’t use anywhere else. There’s no email: if you forget it, the person who runs the server can give you a reset code.');
    inp('ni_user','Username (3–16 letters, numbers, _)','text','username');inp('ni_pass','Password (8+ characters)','password','new-password');inp('ni_pass2','Same password again','password','new-password');btn('doReg','Create account',{def:1});btn('acct','Back');break;
   case 'reset':inp('ni_user','Username','text','username');inp('ni_code','Reset code','text','one-time-code');inp('ni_pass','New password','password','new-password');btn('doReset','Set new password',{def:1});btn('acct','Back');break;
   case 'reconcile':{const R=this.rec;info(R.q,'big');R.lines.forEach(l=>info(l));R.opts.forEach(o=>btn(o.id,o.t));break;}
   case 'together':if(!A){info('Sign in to play together.');btn('login','Sign in');btn('reg','Create an account');btn('back','Back');break;}
    info('Up to four of you. One makes a room and reads out the code; the others join with it.');btn('create','Make a room');btn('join','Join a room');btn('conn','Connection test');btn('back','Back');break;
   case 'join':inp('ni_room','Room code (4 letters)','text','off',{max:4,upper:1});btn('doJoin','Join',{def:1});btn('together','Back');break;
   case 'conn':(this.connLines||['Testing…']).forEach(l=>info(l));btn('conn','Run again');btn('together','Back');break;
   case 'room':{const me=Net.roster.find(r=>r.u===Net.me);const host=Net.host===Net.me;
    info('ROOM  '+Net.code,'code');
    for(let i=0;i<4;i++){const r=Net.roster[i];if(!r){info('— empty —','pslot');continue;}const c=CHAR_INFO[r.char]||{name:'?'};
     info(`<i style="background:${RCOL[r.col]}"></i>${escH(r.u)}${r.u===Net.me?' (you)':''} · ${c.name}${r.u===Net.host?' · host':''}${r.on?'':' · offline'}  ${r.ready||r.u===Net.host?'<b>READY</b>':'<em>not ready</em>'}`,'pslot raw');}
    if(me){const c=CHAR_INFO[me.char];I.push({k:'char',id:'char',t:`Character ◂ ${c?c.name+' — '+c.job+', '+c.flat:'?'} ▸`});}
    if(!host)btn('ready',me&&me.ready?'Ready ✓ (press to undo)':'I’m ready');
    else{const all=Net.roster.filter(r=>r.on).every(r=>r.ready||r.u===Net.me);btn('start',all?'Start':'Start (waiting for everyone to be ready)',{dis:!all});}
    btn('leave','Leave room');break;}
  }return I;},
 render(){const e=this.el();e.classList.remove('hidden');
  const rows=this.items.map((it,i)=>{const s=i===this.sel?' sel':'';
   if(it.k==='info')return`<div class="ni info ${it.cls||''}">${it.cls&&it.cls.includes('raw')?it.t:escH(it.t)}</div>`;
   if(it.k==='in')return`<label class="ni in${s}" data-i="${i}"><span>${escH(it.t)}</span><input id="${it.id}" type="${it.type}" autocomplete="${it.ac}" spellcheck="false" ${it.max?`maxlength="${it.max}"`:''} ${it.upper?'style="text-transform:uppercase"':''}></label>`;
   return`<div class="ni btn${s}${it.dis?' dis':''}" data-i="${i}">${escH(it.t)}</div>`;}).join('');
  const titles={acct:'Account',login:'Sign in',reg:'Create an account',reset:'Reset password',reconcile:'Your progress',together:'Together',join:'Join a room',conn:'Connection test',room:'Waiting room'};
  e.innerHTML=`<div class="panel netp"><h2>${titles[this.view]||''}</h2>${rows}<div id="netMsg" class="${this.err?'err':''}">${escH(this.msg)}</div><div class="foot"><kbd>↑ ↓</kbd> MOVE &nbsp; <kbd>ENTER</kbd> CHOOSE &nbsp; <kbd>ESC</kbd> BACK${this.view==='room'?' &nbsp; <kbd>← →</kbd> CHARACTER':''}</div></div>`;
  e.querySelectorAll('input').forEach(inp=>{inp.addEventListener('keydown',ev=>this.inKey(ev,inp));if(inp.id==='ni_room')inp.addEventListener('input',()=>{inp.value=inp.value.toUpperCase().replace(/[^A-Z]/g,'');});});
  this.focusSel();},
 focusSel(){const it=this.items[this.sel];document.querySelectorAll('#net .ni').forEach(d=>d.classList.toggle('sel',+d.dataset.i===this.sel));
  if(it&&it.k==='in'){const inp=$('#'+it.id);if(inp&&document.activeElement!==inp)inp.focus();}else if(document.activeElement&&document.activeElement.tagName==='INPUT')document.activeElement.blur();},
 move(d){const n=this.items.length;let i=this.sel;for(let k=0;k<n;k++){i=(i+d+n)%n;if(this.items[i].k!=='info'&&!this.items[i].dis)break;}this.sel=i;Snd.play('ui');this.focusSel();},
 inKey(ev,inp){
  if(ev.key==='ArrowDown'||(ev.key==='Tab'&&!ev.shiftKey)){ev.preventDefault();this.move(1);}
  else if(ev.key==='ArrowUp'||(ev.key==='Tab'&&ev.shiftKey)){ev.preventDefault();this.move(-1);}
  else if(ev.key==='Enter'){ev.preventDefault();const nx=this.items.slice(this.sel+1).find(x=>x.k==='in');if(nx&&!inp.value){return;}
   const d=this.items.find(x=>x.def);if(nx&&!$('#'+nx.id).value){this.sel=this.items.indexOf(nx);this.focusSel();return;}if(d)this.act(d);}
  else if(ev.key==='Escape'){ev.preventDefault();this.back();}
  ev.stopPropagation();},
 back(){const v=this.view;if(this.busy)return;
  if(v==='room'){Net.leave();this.show('together');return;}
  if(['login','reg','reset'].includes(v)){this.show('acct');return;}
  if(['join','conn'].includes(v)){this.show('together');return;}
  if(v==='reconcile')return;
  this.close();},
 tick(dt){ // called every frame while open (title or play)
  if(!this.open)return;
  if(document.activeElement&&document.activeElement.tagName==='INPUT')return;
  if(Input.hit('up'))this.move(-1);if(Input.hit('down'))this.move(1);
  const it=this.items[this.sel];
  if(it&&it.k==='char'&&(Input.hit('left')||Input.hit('right'))){const me=Net.roster.find(r=>r.u===Net.me);if(me){const taken=new Set(Net.roster.filter(r=>r.u!==Net.me).map(r=>r.char));let i=CHAR_ORDER.indexOf(me.char);const d=Input.hit('left')?-1:1;for(let k=0;k<4;k++){i=(i+d+4)%4;if(!taken.has(CHAR_ORDER[i]))break;}Net.send({t:'char',char:CHAR_ORDER[i]});Snd.play('ui');}}
  if(Input.hit('pause')||Input.pressed.has('Backspace')){Input.clear();this.back();return;}
  if(Input.hit('ok')&&it&&it.k!=='info'){Input.clear();if(it.k==='in'){this.focusSel();return;}if(!it.dis)this.act(it);}
 },
 async act(it){if(this.busy)return;const id=it.id;Snd.play('uiOk');
  const go=v=>{this.msg='';this.show(v);};
  switch(id){
   case 'back':this.close();return;
   case 'acct':case 'login':case 'reg':case 'reset':case 'together':case 'join':go(id);return;
   case 'out':await Acct.api('/api/logout','POST');Acct.clear();Cloud.status='';go('acct');return;
   case 'sync':this.say('Syncing…');await Cloud.push();this.show('acct',true);this.say(Cloud.status);return;
   case 'doLogin':case 'doReg':case 'doReset':{
    const u=this.val('ni_user').trim(),p=this.val('ni_pass');
    if(!u||!p){this.say('Fill in both boxes.',true);return;}
    if(id==='doReg'&&p!==this.val('ni_pass2')){this.say('The two passwords don’t match.',true);return;}
    this.busy=true;this.say(id==='doReg'?'Creating your account…':'Signing in…');
    const r=id==='doLogin'?await Acct.api('/api/login','POST',{u,p}):id==='doReg'?await Acct.api('/api/register','POST',{u,p}):await Acct.api('/api/reset','POST',{u,code:this.val('ni_code'),p});
    this.busy=false;
    if(r.s!==200){this.say(r.j.error||'Something went wrong.',true);return;}
    Acct.set(r.j.u,r.j.token);await this.reconcile();return;}
   case 'create':{this.busy=true;this.say('Making a room…');const r=await Acct.api('/api/room','POST');this.busy=false;if(r.s!==200){this.say(r.j.error||'Couldn’t make a room.',true);return;}this.say('Connecting…');Net.join(r.j.code);return;}
   case 'doJoin':{const c=this.val('ni_room').toUpperCase();if(!/^[A-Z]{4}$/.test(c)){this.say('Room codes are 4 letters.',true);return;}this.say('Connecting…');Net.join(c);return;}
   case 'conn':this.connLines=['Testing…'];this.show('conn',true);this.connLines=await connTest();this.show('conn',true);return;
   case 'char':return;
   case 'ready':{const me=Net.roster.find(r=>r.u===Net.me);Net.send({t:'ready',r:!(me&&me.ready)});return;}
   case 'start':Net.send({t:'start',map:'nettest'});return;
   case 'leave':Net.leave();go('together');return;
   default:if(this.rec&&this.rec.fn[id]){const f=this.rec.fn[id];this.rec=null;await f();}
  }},
 // after signing in: decide what happens to this device's progress
 async reconcile(){
  this.say('Checking your saved progress…');const c=await Cloud.pull();
  const done=()=>{this.msg='';this.show(this.after||'acct');this.after=null;};
  if(c.err){this.say(c.err,true);return;}
  const cloud=c.data,local=Cloud.blob(),sc=Cloud.sum(cloud),sl=Cloud.sum(local),u=Acct.u;
  const same=cloud&&JSON.stringify(cloud.save)===JSON.stringify(local.save);
  if(!sl&&!sc){Cloud.status='Nothing saved yet.';return done();}
  if(!sl&&sc){Cloud.apply(cloud);Cloud.status='Loaded '+u+'’s progress ('+Cloud.label(sc)+').';return done();}
  if(sl&&sc&&same){const e=Cloud.mergeEndings(cloud,local);_rawStore('lull_endings',e);await Cloud.push();return done();}
  if(sl&&!sc){this.rec={q:'This computer has progress on it.',lines:['This computer: '+Cloud.label(sl),'Attach it to '+u+'? If this isn’t your progress, start fresh instead — it stays on this computer as a backup.'],
    opts:[{id:'r_attach',t:'Attach it to '+u},{id:'r_fresh',t:'Start fresh on '+u}],
    fn:{r_attach:async()=>{await Cloud.push(true);Cloud.status='This computer’s progress is now saved to '+u+'.';done();},r_fresh:async()=>{Cloud.apply(null);await Cloud.push(true);Cloud.status='Started fresh. The old progress is kept as a backup on this computer.';done();}}};
   this.msg='';this.show('reconcile');return;}
  this.rec={q:'Which progress do you want to keep?',lines:['On this computer: '+Cloud.label(sl),'On '+u+'’s account: '+Cloud.label(sc),'Endings you’ve found are kept either way. The one you don’t pick is kept as a backup on this computer.'],
   opts:[{id:'r_cloud',t:'Use '+u+'’s account save'},{id:'r_local',t:'Use this computer’s save'}],
   fn:{r_cloud:async()=>{const e=Cloud.mergeEndings(cloud,local);Cloud.apply(Object.assign({},cloud,{endings:e}));await Cloud.push(true);Cloud.status='Using '+u+'’s saved progress.';done();},
    r_local:async()=>{const e=Cloud.mergeEndings(cloud,local);_rawStore('lull_backup',cloud);_rawStore('lull_endings',e);await Cloud.push(true);Cloud.status='Using this computer’s progress.';done();}}};
  this.msg='';this.show('reconcile');}
};
async function connTest(){
 const out=[];const t0=performance.now();
 try{let best=1e9;for(let i=0;i<4;i++){const t=performance.now();const r=await fetch('/api/ping',{cache:'no-store'});await r.json();best=Math.min(best,performance.now()-t);}out.push(`Website/HTTPS: OK · ${best|0} ms`);}
 catch(e){out.push('Website/HTTPS: FAILED — the server can’t be reached from this network.');return out;}
 const ws=await new Promise(res=>{let w;try{w=new WebSocket((location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws/echo');}catch(e){res(null);return;}
  const times=[];let t;const to=setTimeout(()=>{try{w.close();}catch(e){}res(times.length?times:null);},5000);
  w.onopen=()=>{t=performance.now();w.send('x');};w.onmessage=()=>{times.push(performance.now()-t);if(times.length>=5){clearTimeout(to);w.close();res(times);}else{t=performance.now();w.send('x');}};w.onerror=()=>{clearTimeout(to);res(null);};});
 if(!ws)out.push('Live connection (WebSocket): FAILED — this network blocks it. Co-op won’t work here; solo and saving still will.');
 else{const a=ws.reduce((s,v)=>s+v,0)/ws.length;out.push(`Live connection (WebSocket): OK · ${a|0} ms`);out.push(a<120?'Verdict: good for co-op.':a<250?'Verdict: playable, a little laggy.':'Verdict: very laggy — expect delays.');}
 const st=await Acct.api('/api/status');if(st.s===200&&st.j.limit)out.push(`Today’s multiplayer budget: ${Math.min(100,Math.round(st.j.used/st.j.limit*100))}% used`);
 return out;}

// ---------------- the room connection ----------------
const Net={ws:null,code:null,me:null,host:null,roster:[],phase:'lobby',remotes:new Map(),retry:0,want:false,rtt:0,
 isHost(){return G.coop&&this.host===this.me;},
 join(code){this.code=code;this.want=true;this.retry=0;this.open();},
 open(){
  try{this.ws&&this.ws.close();}catch(e){}
  let ws;try{ws=new WebSocket((location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws/room/'+this.code,['lull',Acct.tok]);}catch(e){NetUI.say('Couldn’t connect.',true);return;}
  this.ws=ws;
  ws.onopen=()=>{this.retry=0;NetGame.netState('');};
  this.lastMsg=performance.now();
  ws.onmessage=e=>{this.lastMsg=performance.now();let m;try{m=JSON.parse(e.data);}catch(x){return;}this.onMsg(m);};
  ws.onclose=e=>{if(this.ws!==ws)return;this.ws=null;
   if(e.code===4000){this.want=false;NetGame.netState('This account joined from somewhere else.');if(!G.coop)NetUI.say('This account joined from somewhere else.',true);return;}
   if(!this.want)return;
   if(this.retry<6){const d=Math.min(8,2**this.retry);this.retry++;NetGame.netState('Connection lost — reconnecting…');if(!G.coop&&NetUI.open)NetUI.say(this.retry===1&&!this.me?'Couldn’t join. Check the code, or the room may be full.':'Reconnecting…',true);setTimeout(()=>{if(this.want)this.open();},d*1000);}
   else{this.want=false;NetGame.netState('Disconnected.');if(!G.coop)NetUI.say('Couldn’t connect to the room.',true);}};
 },
 send(o){if(this.ws&&this.ws.readyState===1){this.ws.send(JSON.stringify(o));return true;}return false;},
 leave(){this.want=false;this.send({t:'leave'});try{this.ws&&this.ws.close();}catch(e){}this.ws=null;this.code=null;this.me=null;this.host=null;this.roster=[];this.remotes.clear();},
 onMsg(m){
  switch(m.t){
   case 'hello':this.me=m.you;if(m.proto!==NET_PROTO){NetUI.say('The server is a different version from this game. Refresh the page.',true);}break;
   case 'room':{this.host=m.host;this.phase=m.phase;this.roster=m.roster;this.code=m.code;
    if(G.coop)NetGame.rosterChanged();else if(NetUI.open||m.phase==='lobby'){NetUI.msg='';NetUI.show('room',NetUI.view==='room');}break;}
   case 'start':NetGame.begin(m);break;
   case 'host':this.host=m.u;if(G.coop){NetGame.hostChanged();}break;
   case 'left':if(G.coop)NetGame.left(m.u);break;
   case 'sys':if(G.coop)toast(m.msg);else NetUI.say(m.msg,true);break;
   case 'pong':this.rtt=performance.now()-m.c;break;
   default:if(G.coop)NetGame.onMsg(m);
  }}
};

// ---------------- remote players ----------------
class RemoteP extends Actor{
 constructor(r){super(-9999,-9999);this.kind='remote';this.u=r.u;this.char=r.char;this.col=r.col;this.solid=false;this.hidden=true;
  this.nx=0;this.ny=0;this.vx=0;this.vy=0;this.rt=0;this.mv=0;this.tc=0;this.sw=-1;this.dn=0;this.fx=0;this.fy=1;this.m='';this.batt=1;}
 get name(){return(CHAR_INFO[this.char]||{name:this.u}).name;}
 net(s){this.nx=+s.x;this.ny=+s.y;this.vx=+s.vx||0;this.vy=+s.vy||0;this.rt=performance.now();this.dir=s.d|0;this.mv=s.mv|0;this.tc=s.tc|0;this.fx=+s.fx||0;this.fy=+s.fy||0;this.dn=s.dn|0;this.m=s.m;
  if(s.sw&&this.sw<0)this.sw=0;
  const here=s.m===G.map.id;this.hidden=!here;
  if(here&&(this.x<-9000||dist(this.x,this.y,this.nx,this.ny)>64)){this.x=this.nx;this.y=this.ny;}}
 update(dt){if(this.hidden)return;
  const age=Math.min(.3,(performance.now()-this.rt)/1000);let px=this.nx,py=this.ny;
  if(this.mv){const ex=px+this.vx*age,ey=py+this.vy*age;if(!blocked(G.map,ex,ey,3,3,this)){px=ex;py=ey;}}
  const k=1-Math.exp(-dt*14),bx=this.x,by=this.y;this.x+=(px-this.x)*k;this.y+=(py-this.y)*k;
  this.moving=!!this.mv&&!this.dn;this.anim+=dt*(this.moving?7:0);
  if(this.sw>=0){this.sw+=dt;if(this.sw>=.26)this.sw=-1;}
  this.interact=this.dn&&!NetGame.down?{label:'Help '+this.name+' up (hold E)',fn:()=>{}}:null;}
 draw(c,ox,oy){if(this.hidden)return;const X=q(this.x)-ox,Y=q(this.y)-oy,sty=(CHAR_INFO[this.char]||{}).sty||'p1';
  if(this.dn){drawHum(c,sty,0,'lie',0,{closed:1},X-12,Y-10);}
  else{const pose=this.sw>=0?'swing':this.moving?'walk':'idle';drawHum(c,sty,this.dir,pose,pose==='walk'?((this.anim|0)%4)+1:0,{},X-8,Y-24);
   if(this.sw>=0){const t=this.sw/.26,a=Math.atan2(this.fy||1e-6,this.fx);c.save();c.translate(X,Y-8);c.strokeStyle=`rgba(230,235,240,${.5*(1-t)})`;c.lineWidth=2;c.beginPath();c.arc(0,0,18,a-1+t*.6,a+.2+t*1.2);c.stroke();c.restore();}}
  // voice-colour marker + name when close
  let nearest=null,nd=70;for(const r of Net.remotes.values()){if(r.hidden)continue;const d=dist(r.x,r.y,P.x,P.y);if(d<nd){nd=d;nearest=r;}}
  const near=nearest===this;c.fillStyle=RCOL[this.col]||'#ccc';c.globalAlpha=near?.95:.55;c.fillRect(X-1,Y-(this.dn?16:30),3,2);c.fillRect(X,Y-(this.dn?17:31),1,4);c.globalAlpha=1;
  if(near&&!G.lull){c.save();c.font='5px "Space Mono", monospace';c.textAlign='center';c.fillStyle='rgba(0,0,0,.6)';c.fillText(this.name,X+.5,Y-(this.dn?19:33)+.5);c.fillStyle='#e8e2d4';c.fillText(this.name,X,Y-(this.dn?19:33));c.restore();}}
}

// ---------------- co-op Hollowed: the host simulates, everyone else mirrors ----------------
const HSTATES=['idle','alert','chase','wind','lunge','recover','stagger','flee','return','dead'];
class CoHollow extends Hollow{
 constructor(x,y,o){super(x,y,o);this.sx=x;this.sy=y;this.lungeT=0;this.tgt=null;}
 targets(){const a=[];if(!NetGame.down&&!P.hidden)a.push(P);for(const r of Net.remotes.values())if(!r.hidden&&!r.dn&&r.m===G.map.id)a.push(r);return a;}
 update(dt){if(this.dead)return;this.flash-=dt;this.jit+=dt;
  const dP=dist(this.x,this.y,P.x,P.y);if(dP<130)G.humNear=Math.max(G.humNear,1-dP/130);
  if(Net.isHost())this.ai(dt);else this.puppet(dt);}
 // local lunge (both modes): the victim's own game decides if it connects
 lungeStep(dt){moveActor(this,this.lx*150*dt,this.ly*150*dt);
  if(!this.hitDone&&!NetGame.down&&dist(this.x,this.y,P.x,P.y)<15){this.hitDone=true;if(P.iT<=0&&P.graceT<=0){hurtPlayer(rand(12,17),'hollow');moveActor(P,this.lx*6,0);moveActor(P,0,this.ly*6);}}}
 puppet(dt){
  if(this.lungeT>0){this.lungeT-=dt;this.state='lunge';this.lungeStep(dt);this.anim+=dt*8;return;}
  const k=1-Math.exp(-dt*12),bx=this.x,by=this.y;this.x+=(this.sx-this.x)*k;this.y+=(this.sy-this.y)*k;
  this.moving=Math.hypot(this.x-bx,this.y-by)>dt*4;if(this.moving)this.face(this.x-bx,this.y-by);this.anim+=dt*(this.moving?8:3);}
 ai(dt){
  const T=this.targets();let tg=this.tgt&&T.includes(this.tgt)?this.tgt:null,best=1e9;
  for(const a of T){const d=dist(this.x,this.y,a.x,a.y)*(a===tg?.75:1);if(d<best){best=d;tg=a;}}
  this.tgt=tg;const tx=tg?tg.x:this.hx,ty=tg?tg.y:this.hy,d=tg?dist(this.x,this.y,tx,ty):1e9;
  const look=()=>{if(tg)this.face(tx-this.x,ty-this.y);};
  this.t-=dt;this.shoutT-=dt;
  if(this.vx||this.vy){moveActor(this,this.vx*dt,this.vy*dt);this.vx*=.82;this.vy*=.82;if(Math.abs(this.vx)<1)this.vx=0;if(Math.abs(this.vy)<1)this.vy=0;}
  const home=dist(this.x,this.y,this.hx,this.hy),torch=tg===P?P.torch:(tg&&tg.tc);
  const seen=tg&&d<this.guard+(torch?30:0);
  switch(this.state){
   case 'idle':this.moving=false;if(this.t<=0){this.t=rand(2,4);this.wx=this.hx+rand(-24,24);this.wy=this.hy+rand(-16,16);}
    if(this.wx!==undefined&&dist(this.x,this.y,this.wx,this.wy)>3)this.walkTo(this.wx,this.wy,14,dt);
    if(seen){this.state='alert';this.t=.7;look();Snd.play('shriek',{pan:clamp((this.x-P.x)/120,-1,1)});this.shout();}break;
   case 'alert':this.moving=false;look();if(this.t<=0)this.state='chase';break;
   case 'chase':if(!tg||home>this.guard*2.2){this.state='return';break;}this.walkTo(tx,ty,58,dt);if(d<19){this.state='wind';this.t=.42;this.moving=false;}break;
   case 'wind':look();if(this.t<=0){if(!tg){this.state='recover';this.t=.5;break;}this.state='lunge';this.t=.2;const l=d||1;this.lx=(tx-this.x)/l;this.ly=(ty-this.y)/l;this.hitDone=false;Snd.play('swing');
    Net.send({t:'hx',id:this.nid,lx:+this.lx.toFixed(3),ly:+this.ly.toFixed(3),x:this.x|0,y:this.y|0});}break;
   case 'lunge':this.lungeStep(dt);if(this.t<=0){this.state='recover';this.t=.6;}break;
   case 'recover':this.moving=false;if(this.t<=0)this.state=tg&&d<this.guard*1.4?'chase':'return';break;
   case 'stagger':this.moving=false;if(this.t<=0){if(this.hp<this.maxhp*.35){this.state='flee';this.t=2.6;}else this.state='chase';}break;
   case 'flee':{if(tg){const dx=this.x-tx,dy=this.y-ty,l=Math.hypot(dx,dy)||1;this.walkTo(this.x+dx/l*30,this.y+dy/l*30,60,dt);}if(this.t<=0||d>150)this.state='return';break;}
   case 'return':if(this.walkTo(this.hx,this.hy,30,dt)||this.stuck>2){this.state='idle';this.t=2;}if(seen&&home<this.guard&&this.hp>this.maxhp*.35)this.state='chase';break;
  }
  this.anim+=dt*(this.moving?8:3);}
 snap(){return[this.nid,this.x|0,this.y|0,HSTATES.indexOf(this.state),this.dir,Math.max(0,this.hp|0),this.dead?1:0];}
 applySnap(s){if(this.dead)return;this.sx=s[1];this.sy=s[2];const was=this.state;if(this.lungeT<=0)this.state=HSTATES[s[3]]||'idle';
  if(was==='idle'&&this.state==='alert'&&dist(this.x,this.y,P.x,P.y)<200)Snd.play('shriek',{pan:clamp((this.x-P.x)/120,-1,1)});this.dir=s[4];this.hp=s[5];
  if(dist(this.x,this.y,this.sx,this.sy)>80){this.x=this.sx;this.y=this.sy;}
  if(s[6])this.dieLocal(null);}
 damage(dmg,fx,fy,kb,by){
  if(this.dead)return;
  if(!Net.isHost()){ // ask the host; show the hit straight away so it feels instant
   Net.send({t:'hh',id:this.nid,dmg:+dmg.toFixed(1),fx:+fx.toFixed(2),fy:+fy.toFixed(2),kb});
   this.flash=.12;Snd.play('enemyHurt');for(let i=0;i<7;i++)G.parts.push({x:this.x,y:this.y-10,vx:fx*rand(20,70)+rand(-20,20),vy:fy*rand(20,70)+rand(-40,0),g:120,life:.6,max:.6,col:G.truthNow?'#5a0a0a':'#0b0c0e',s:2});
   this.x+=fx*4;this.y+=fy*4;return;}
  this.lastBy=by||Net.me;super.damage(dmg,fx,fy,kb);}
 die(){ // host only (Hollow.damage calls this)
  this.dieLocal(this.lastBy);Net.send({t:'kill',id:this.nid,by:this.lastBy});
  if(this.drop)Net.send({t:'spawn',item:this.drop.item,n:this.drop.n||1,x:(this.x+6)|0,y:(this.y+2)|0});
  NetGame.sendWorld(true);}
 dieLocal(by){if(this.dead)return;this.dead=true;this.hittable=false;this.solid=false;this.state='dead';this.lungeT=0;Snd.play('thud');
  if(by===Net.me){G.stats.sanity=Math.max(0,G.stats.sanity-7);G.stats.hum=Math.min(100,G.stats.hum+3);G.flags.kills=(G.flags.kills||0)+1;G.shake=5;}}
}

// ---------------- shared pickups: the server decides who gets it ----------------
class CoPickup extends Pickup{
 constructor(id,x,y,item,n){super(x,y,item,n);this.pid=id;this.pend=false;
  this.interact={label:'Take '+ITEMS[item].name.toLowerCase(),fn:()=>{
   if(this.pend)return;const it=ITEMS[this.item];const stack=!it.weapon&&!it.key&&G.inv.some(s=>s.id===this.item);
   if(!stack&&G.inv.length>=INV_MAX){murmur('Your bag is full.');return;}
   this.pend=true;Net.send({t:'pick',id:this.pid});}};}
}

// ---------------- the co-op session ----------------
const NetGame={taken:{},drops:[],down:null,sendT:0,lastKey:'',lastSent:0,px:0,py:0,worldT:0,pingT:0,helpT:0,helpTgt:null,
 wheel:null,clicks:[],log:[],state:'',
 begin(m){
  if(G.coop&&m.resume&&G.phase==='co_test'&&G.map){ // reconnected mid-game: keep everything, just catch up
   this.taken=Object.assign(this.taken,m.taken||{});G.map.ents=G.map.ents.filter(e=>!(e instanceof CoPickup&&this.taken[e.pid]));
   for(const d of m.drops||[])if(!G.map.ents.some(e=>e instanceof CoPickup&&e.pid===d.id))G.map.ents.push(new CoPickup(d.id,d.x,d.y,d.item,d.n||1));
   this.netState('');this.sendState(true);if(Net.isHost())this.sendWorld(true);return;}
  NetUI.close(true);$('#title').classList.add('hidden');Snd.stopSong();UI.closeModal();
  resetGame();G.coop=true;this.down=null;this.taken=m.taken||{};this.drops=m.drops||[];this.log=[];
  const slot=Math.max(0,Net.roster.findIndex(r=>r.u===Net.me));
  G.flags.canFight=1;G.sanityOn=true;G.showHum=true;G.lullAllowed=false;G.decay={hunger:.008,thirst:.012};
  giveItem('crowbar',1,true);giveItem('torch',1,true);giveItem('walkie',1,true);giveItem('water',1,true);P.battery=70;
  G.objective='Network test: stay together, try everything';
  Net.remotes.clear();
  loadPhase('co_test',{pos:CO_SPAWNS[slot%4]});
  this.rosterChanged();
  UI.fade(1,.01);UI.fade(0,1.2);
  UI.hint('<kbd>T</kbd> say aloud &nbsp; <kbd>R</kbd> radio &nbsp; <kbd>C</kbd> channel &nbsp; <kbd>I</kbd> then <kbd>G</kbd> give &nbsp; hold <kbd>E</kbd> on a fallen friend',10);
  this.sendState(true);if(Net.isHost())this.sendWorld(true);
  this.panel();},
 rosterChanged(){
  for(const r of Net.roster){if(r.u===Net.me)continue;let e=Net.remotes.get(r.u);
   if(!e){e=new RemoteP(r);Net.remotes.set(r.u,e);G.map&&G.map.ents.push(e);}
   e.char=r.char;e.col=r.col;if(!r.on)e.hidden=true;}
  for(const [u,e] of Net.remotes)if(!Net.roster.some(r=>r.u===u)){e.hidden=true;G.map.ents=G.map.ents.filter(x=>x!==e);Net.remotes.delete(u);}
  this.panel();},
 hostChanged(){if(Net.isHost()){for(const e of G.map.ents)if(e instanceof CoHollow&&!e.dead){e.x=e.sx;e.y=e.sy;if(['lunge','wind'].includes(e.state)){e.state='recover';e.t=.5;}}toast('You are now hosting the Hollowed');this.sendWorld(true);}this.panel();},
 left(u){const e=Net.remotes.get(u);if(e){e.hidden=true;this.chat(null,`${e.name} lost connection.`);}},
 netState(s){this.state=s;const el=$('#netState');if(el){el.textContent=s;el.classList.toggle('hidden',!s);}},
 // the game asked to kill the player: in co-op you go down first
 onDie(cause){if(this.down)return true;
  this.down={t:20,cause};P.pose='lie';P.torch=false;P.swing=-1;G.stats.health=0;Net.send({t:'down'});this.sendState(true);
  Snd.play('death');UI.hint('You’re down. A friend can help you up — they hold <kbd>E</kbd> next to you.',6);return true;},
 up(hp,msg){this.down=null;P.pose=null;G.stats.health=hp;P.iT=1.5;Net.send({t:'up'});this.sendState(true);if(msg)murmur(msg);},
 // runs before the normal key handling, so R/T menus can use the number keys
 preInput(dt){
  const rad=Input.down.has('KeyR'),say=Input.down.has('KeyT');
  if(G.modal==='inv'&&Input.pressed.has('KeyG')){Input.pressed.delete('KeyG');this.giveSelected();}
  if(G.modal==='inv'&&Input.hit('drop')){const s=G.inv[UI.invSel];if(s&&!ITEMS[s.id].key){Input.eat('drop');takeItem(s.id,1);Net.send({t:'spawn',item:s.id,n:1,x:(P.x+P.fx*10)|0,y:(P.y+P.fy*8)|0});Snd.play('ui');UI.invDraw();}}
  if(G.modal&&G.modal!=='pause'){this.closeWheel();return;}
  if((rad||say)&&!G.modal&&!this.down&&!G.lull){const mode=rad?'rad':'say';if(!this.wheel||this.wheel!==mode)this.openWheel(mode);
   for(let i=1;i<=8;i++)if(Input.pressed.has('Digit'+i)){Input.pressed.delete('Digit'+i);this.speak(mode,i-1);}
   if(mode==='rad'&&Input.pressed.has('Space')){Input.pressed.delete('Space');this.clicks.push(performance.now());this.radioSnd('click',1);}
   Input.eat('attack');Input.eat('interact');}
  else if(this.wheel)this.closeWheel();
  if(Input.pressed.has('KeyC')&&!G.modal){const ch=(NetGame.ch||1)%4+1;this.ch=ch;Net.send({t:'chan',ch});toast('Radio: channel '+ch);this.radioSnd('click',1);this.panel();}

 },
 openWheel(mode){this.wheel=mode;if(mode==='rad')this.clicks=[];const w=$('#wheel');w.innerHTML=`<h4>${mode==='rad'?'RADIO · CH '+(this.ch||1)+' <small>no name — only your colour</small>':'SAY ALOUD <small>only people near you hear</small>'}</h4>`+PHRASES.map((p,i)=>`<div><kbd>${i+1}</kbd>${p}</div>`).join('')+(mode==='rad'?'<div class="sp"><kbd>SPACE</kbd>click (send a code)</div>':'');w.classList.remove('hidden');},
 closeWheel(){if(this.wheel==='rad'&&this.clicks.length){const t0=this.clicks[0];Net.send({t:'clk',pat:this.clicks.map(t=>(t-t0)|0)});this.chat(null,`You clicked ${this.clicks.length}× on CH ${this.ch||1}.`);}this.clicks=[];this.wheel=null;$('#wheel').classList.add('hidden');},
 speak(mode,i){if(mode==='say'){Net.send({t:'say',ph:i});}else{Net.send({t:'rad',ph:i});this.radioSnd('key',1);this.chat(null,`<i style="background:${RCOL[(Net.roster.find(r=>r.u===Net.me)||{}).col]}"></i>CH ${this.ch||1} (you): “${PHRASES[i]}”`,true);}},
 giveSelected(){const s=G.inv[UI.invSel];if(!s){return;}if(ITEMS[s.id].key){murmur('You need that.');return;}
  let best=null,bd=40;for(const r of Net.remotes.values()){if(r.hidden)continue;const d=dist(r.x,r.y,P.x,P.y);if(d<bd){bd=d;best=r;}}
  if(!best){murmur('Nobody is close enough to hand it to.');return;}
  takeItem(s.id,1);Net.send({t:'give',to:best.u,item:s.id});Snd.play('ui');UI.invDraw();},
 // Budget-conscious: send when what you're DOING changes (keys, torch, swing), plus a slow heartbeat.
 // Friends' games extrapolate in between. The host's Hollowed ride along in the same message.
 sendState(force){
  const t=performance.now(),sprint=P.moving&&Input.is('sprint');
  const s={t:'st',x:+P.x.toFixed(1),y:+P.y.toFixed(1),d:P.dir,mv:P.moving?1:0,tc:P.torch?1:0,fx:+P.fx.toFixed(2),fy:+P.fy.toFixed(2),dn:this.down?1:0,m:G.map.id};
  if(P.swing>=0&&!this.swSent){s.sw=1;this.swSent=true;force=true;}if(P.swing<0)this.swSent=false;
  const key=[s.d,s.mv,s.tc,s.dn,s.m,sprint?1:0,P.moving?Math.round(P.fx*2):0,P.moving?Math.round(P.fy*2):0].join();
  let world=null;
  if(Net.isHost()&&(this.worldDue||t-this.worldT>(this.worldBusy?333:2000))){world=this.worldSnap(this.worldDue==='full');}
  if(!force&&!world&&key===this.lastKey&&t-this.lastSent<(s.mv?500:3000))return;
  s.vx=+(this.vx||0).toFixed(1);s.vy=+(this.vy||0).toFixed(1);
  if(world){s.h=world;this.worldT=t;this.worldDue=false;}
  if(Net.send(s)){this.lastKey=key;this.lastSent=t;}},
 worldSnap(full){const hs=[];let busy=false;for(const e of G.map.ents)if(e instanceof CoHollow&&(full||!e.dead||!e.sentDead)){const sn=e.snap();if(!full&&sn[3]===0&&e.lastIdle&&Math.abs(e.lastIdle[0]-sn[1])+Math.abs(e.lastIdle[1]-sn[2])<2)continue;if(sn[3]===0)e.lastIdle=[sn[1],sn[2]];else e.lastIdle=null;if(sn[3]!==0&&sn[3]!==9)busy=true;hs.push(sn);if(e.dead)e.sentDead=1;}
  this.worldBusy=busy;return hs;},
 sendWorld(full){this.worldDue=full?'full':(this.worldDue||true);this.sendState(true);},
 tick(dt){
  // velocity for remote extrapolation
  this.vx=dt>0?(P.x-this.px)/dt:0;this.vy=dt>0?(P.y-this.py)/dt:0;this.px=P.x;this.py=P.y;
  this.sendState(false);
  this.pingT-=dt;if(this.pingT<=0){this.pingT=8;Net.send({t:'ping',c:performance.now()});this.panel();}
  // watchdog: in a game something arrives at least every 8 s (pongs); silence means a dead link
  if(Net.want&&Net.ws&&performance.now()-Net.lastMsg>15000){Net.lastMsg=performance.now();this.netState('Connection lost — reconnecting…');Net.open();}
  // down: countdown, then wake at the courtyard
  if(this.down){this.down.t-=dt;G.stats.health=0;
   if(this.down.t<=0){P.x=CO_SPAWNS[0][0];P.y=CO_SPAWNS[0][1];this.up(45,'You come round by the brazier. Your head is pounding.');}
   else if(((this.down.t*2)|0)!==((this.down.t*2+dt*2)|0))UI.thought('help me',1);}
  // helping someone up: hold E beside them
  let tgt=null;if(!this.down&&!G.modal)for(const r of Net.remotes.values())if(r.dn&&!r.hidden&&dist(r.x,r.y,P.x,P.y)<REVIVE_R){tgt=r;break;}
  if(tgt&&Input.is('interact')){if(this.helpTgt!==tgt){this.helpTgt=tgt;this.helpT=0;}this.helpT+=dt;UI.hint(`Helping ${tgt.name} up… ${Math.min(100,this.helpT/1.5*100)|0}%`,1);
   if(this.helpT>=1.5){Net.send({t:'rev',to:tgt.u});this.helpT=0;this.helpTgt=null;tgt.dn=0;}}
  else{this.helpT=0;this.helpTgt=null;}
  this.decayLog(dt);},
 onMsg(m){
  switch(m.t){
   case 'ps':{const e=Net.remotes.get(m.u);if(e){const was=e.dn;e.net(m);if(!was&&e.dn)this.chat(null,`${e.name} is down!`);}
    if(m.h&&m.u===Net.host&&!Net.isHost())this.applyWorld(m.h);break;}
   case 'ws':if(!Net.isHost())this.applyWorld(m.h);break;
   case 'hx':{const e=G.map.ents.find(x=>x instanceof CoHollow&&x.nid===m.id);if(e&&!e.dead&&!Net.isHost()){if(dist(e.x,e.y,m.x,m.y)<40){e.x=m.x;e.y=m.y;}e.lx=m.lx;e.ly=m.ly;e.lungeT=.2;e.hitDone=false;Snd.play('swing');}break;}
   case 'hh':if(Net.isHost()){const e=G.map.ents.find(x=>x instanceof CoHollow&&x.nid===m.id);if(e&&!e.dead){e.damage(m.dmg,m.fx,m.fy,m.kb,m.by);}}break;
   case 'kill':{const e=G.map.ents.find(x=>x instanceof CoHollow&&x.nid===m.id);if(e)e.dieLocal(m.by);break;}
   case 'need':if(Net.isHost())this.sendWorld(true);this.sendState(true);break;
   case 'got':{const e=G.map.ents.find(x=>x instanceof CoPickup&&x.pid===m.id);this.taken[m.id]=m.by;
    if(e){G.map.ents=G.map.ents.filter(x=>x!==e);if(m.by===Net.me){giveItem(e.item,e.n);Snd.play('pickup');}}break;}
   case 'gone':{const e=G.map.ents.find(x=>x instanceof CoPickup&&x.pid===m.id);if(e){e.pend=false;G.map.ents=G.map.ents.filter(x=>x!==e);}murmur('Someone else got there first.');break;}
   case 'pk+':if(!G.map.ents.some(x=>x instanceof CoPickup&&x.pid===m.id)&&!this.taken[m.id]){G.map.ents.push(new CoPickup(m.id,m.x,m.y,m.item,m.n||1));}this.drops.push(m);break;
   case 'gift':{const who=this.nameOf(m.from);if(!giveItem(m.item,1,true))Net.send({t:'spawn',item:m.item,n:1,x:P.x|0,y:(P.y+6)|0});else toast(`${who} gave you: ${ITEMS[m.item]?ITEMS[m.item].name:m.item}`);Snd.play('pickup');break;}
   case 'gave':if(!m.ok){giveItem(m.item,1,true);murmur(m.far?'They moved away before you could hand it over.':'You couldn’t hand it over.');}else toast(`Gave ${ITEMS[m.item]?ITEMS[m.item].name.toLowerCase():m.item} to ${this.nameOf(m.to)}`);break;
   case 'say':{const e=m.u===Net.me?P:Net.remotes.get(m.u);const t=PHRASES[m.ph]||'…';if(e)bubble(e,t,{t:3});this.chat(null,`${escH(this.nameOf(m.u))}: ${t}`,true);break;}
   case 'rad':{const t=PHRASES[m.ph]||'…';const shown=m.q<.98?corrupt(t,(1-m.q)*.7):t;this.radioSnd('in',m.q);this.chat(null,`<i style="background:${RCOL[m.col]}"></i>CH ${m.ch}: “${escH(shown)}”`,true);break;}
   case 'clk':{const t0=performance.now();m.pat.forEach(o=>setTimeout(()=>this.radioSnd('click',m.q),o));this.chat(null,`<i style="background:${RCOL[m.col]}"></i>CH ${m.ch}: ${'·'.repeat(m.pat.length)} (${m.pat.length} clicks)`,true);break;}
   case 'down':{const e=Net.remotes.get(m.u);if(e){e.dn=1;}break;}
   case 'up':{if(m.u===Net.me)break;const e=Net.remotes.get(m.u);if(e)e.dn=0;break;}
   case 'revived':if(this.down)this.up(40,`${this.nameOf(m.by)} pulls you to your feet.`);break;
   case 'lobby':break;
  }},
 applyWorld(h){const by={};for(const e of G.map.ents)if(e instanceof CoHollow)by[e.nid]=e;for(const s of h){const e=by[s[0]];if(e)e.applySnap(s);}},
 nameOf(u){if(u===Net.me){const r=Net.roster.find(x=>x.u===u);return r?(CHAR_INFO[r.char]||{}).name||u:u;}const e=Net.remotes.get(u);return e?e.name:u;},
 // radio sounds (synthesised; static gets worse with distance)
 radioSnd(k,q){if(!Snd.ctx)return;const bad=1-(q===undefined?1:q);
  if(k==='click'){Snd.tone(1800,.025,{type:'square',vol:.03});Snd.noise(.04,{f:3000,vol:.04+bad*.08});}
  if(k==='key'){Snd.noise(.12,{f:2400,q:.6,vol:.06});Snd.tone(1200,.05,{type:'square',vol:.02,delay:.1});}
  if(k==='in'){Snd.noise(.25+bad*.4,{f:2200,q:.5,vol:.07+bad*.08});Snd.tone(900,.06,{type:'square',vol:.025,delay:.05});Snd.noise(.18,{f:2600,q:.5,vol:.05+bad*.1,delay:.55+bad*.3});}},
 chat(who,html,raw){this.log.push({h:raw?html:escH(html),t:9});if(this.log.length>6)this.log.shift();this.drawLog();},
 decayLog(dt){let ch=false;for(const l of this.log){l.t-=dt;if(l.t<=0)ch=true;}if(ch){this.log=this.log.filter(l=>l.t>0);this.drawLog();}},
 drawLog(){const el=$('#chatlog');if(el)el.innerHTML=this.log.map(l=>`<div style="opacity:${Math.min(1,l.t/2).toFixed(2)}">${l.h}</div>`).join('');},
 panel(){const el=$('#coopPanel');if(!el)return;if(!G.coop){el.classList.add('hidden');return;}el.classList.remove('hidden');
  el.innerHTML=`<div>ROOM ${escH(Net.code||'')} · CH ${this.ch||1}${Net.isHost()?' · HOST':''} · ${Net.rtt?Math.round(Net.rtt)+' ms':''}</div>`+Net.roster.map(r=>`<div><i style="background:${RCOL[r.col]}"></i>${escH((CHAR_INFO[r.char]||{}).name||r.u)}${r.on?'':' (offline)'}</div>`).join('');},
 end(){G.coop=false;this.closeWheel();this.down=null;this.log=[];this.drawLog();Net.leave();$('#coopPanel')&&$('#coopPanel').classList.add('hidden');this.netState('');}
};
const REVIVE_R=30;
function playerStyle(){if(!G.coop)return'rowan';const r=Net.roster.find(x=>x.u===Net.me);return(r&&CHAR_INFO[r.char]||{}).sty||'rowan';}
// friends' torches cut into the dark the same way yours does
function remoteTorches(lx,m,ox,oy){const out=[];
 for(const r of Net.remotes.values()){if(r.hidden||!r.tc||r.dn)continue;const ex=r.x,ey=r.y-7;if(ex<ox-140||ex>ox+W+140||ey<oy-140||ey>oy+H+140)continue;
  const a0=Math.atan2(r.fy||1e-6,r.fx||0),poly=castPoly(m,ex,ey,128,a0-.48,a0+.48,30),X=ex-ox,Y=ey-oy;
  const g=lx.createRadialGradient(X,Y,0,X,Y,128);g.addColorStop(0,'rgba(0,0,0,.95)');g.addColorStop(.6,'rgba(0,0,0,.7)');g.addColorStop(1,'rgba(0,0,0,0)');lx.fillStyle=g;polyPath(lx,poly,ox,oy);lx.fill();
  const g2=lx.createRadialGradient(X,Y,0,X,Y,26);g2.addColorStop(0,'rgba(0,0,0,.5)');g2.addColorStop(1,'rgba(0,0,0,0)');lx.fillStyle=g2;lx.beginPath();lx.arc(X,Y,26,0,7);lx.fill();
  out.push([poly,X,Y]);}
 // a faint glow around each friend so you can find them in the dark
 for(const r of Net.remotes.values()){if(r.hidden)continue;const X=r.x-ox,Y=r.y-8-oy;const g=lx.createRadialGradient(X,Y,0,X,Y,18);g.addColorStop(0,'rgba(0,0,0,.25)');g.addColorStop(1,'rgba(0,0,0,0)');lx.fillStyle=g;lx.beginPath();lx.arc(X,Y,18,0,7);lx.fill();}
 return out;}

// ---------------- hooks into the rest of the game ----------------
{const oldDie=die;die=function(cause){if(G.coop&&NetGame.onDie(cause))return;return oldDie(cause);};}
{const oldCp=Story.checkpoint;Story.checkpoint=function(...a){if(G.coop)return;return oldCp.apply(this,a);};} // co-op never touches solo saves
{const oldTT=Game.toTitle;Game.toTitle=function(){if(G.coop)NetGame.end();return oldTT.apply(this,arguments);};}
Game.extraTitle=()=>[{t:'Together (online)',id:'o'},{t:Acct.u?'Account: '+Acct.u:'Sign in',id:'a'}];
Game.onTitlePick=id=>{if(id==='o'){NetUI.show('together');return true;}if(id==='a'){NetUI.show('acct');return true;}return false;};
Acct.load();
setInterval(()=>{Cloud.tick(.5);},500);
