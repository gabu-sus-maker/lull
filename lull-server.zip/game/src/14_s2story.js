// ================= STAGE 2 STORY =================
Object.assign(WHO_COL,{MARA:'#7ac0b8',THEO:'#a8b8e8',HALLORAN:'#d8c8a0',COLE:'#c0a080',JAS:'#a8c890',FARROW:'#c8c8d8'});
Object.assign(VOICE,{MARA:1.15,THEO:1.6,HALLORAN:.8,COLE:.7,JAS:1.1,FARROW:1});
const wrapS=(name,phases,gen)=>{const old=S[name];S[name]=function*(){if(phases.includes(PH()))yield* gen();else yield* old();};};
// the organism rewards sharing
function shared(who){F()['inf_'+who]=1;G.stats.hum=Math.min(100,G.stats.hum+8);G.stats.sanity=Math.min(100,G.stats.sanity+6);Snd.play('box',{f:659.3,v:.045});Snd.play('box',{f:987.8,v:.03});}
function refused(){G.stats.sanity=Math.max(0,G.stats.sanity-3);}
Object.assign(S,{
// ---------- morning after ----------
 *a2Wake(){yield wait(1);
  yield N('Grey light through the broken shop window.');
  yield N('You slept without dreaming. You feel ready.');
  yield N('Today, north. The Barbican is an hour’s walk. Less, if you don’t stop.');
  UI.objective('Go home and fetch Biscuit.');
  yield N('Biscuit can look after himself. Dogs always do.');},
 *a2Street(){murmur('Bow Road in daylight. Quiet. Peaceful, almost.');},
 *a2Flat(){yield wait(.6);
  yield N('The front door was open. You don’t remember leaving it open.');
  yield N('Biscuit isn’t here.');
  UI.objective('Look around the flat.');},
 *a2Page(){const f=F();if(f.a2page){yield N('Your handwriting.');return;}f.a2page=1;f.clue_page2=1;
  yield note({id:'h4',text:'Day 10.\nLet Biscuit out.\nHe’s better off away from me.\n\nHe knows. Dogs know.'});
  yield N('You don’t remember writing this.');
  yield N('It’s for the best. He’ll find someone kinder.');
  UI.objective('Head west along the canal, towards the City.');},
 *towpathWest(){if(!F().a2page&&!F().towWarn){F().towWarn=1;yield N('Good. West. The canal will take you most of the way.');}yield go('a2_canal');},
 *canalEast(){yield go('a2_street',{pos:[tx(1)+4,ty(31)-2],dir:2});},
// ---------- canal ----------
 *a2Canal(){murmur('The Regent’s Canal. The water is very still.',4);UI.objective('Follow the towpath west.');
  G.timers.push({t:9,fn:()=>murmur('Narrowboats, moored nose to tail. People sleeping inside. Let them sleep.',5)});},
 *boatDuchess(){yield N('Curtains drawn. Through a gap: two people in the bunk, holding hands, smiling.');yield N('Sleeping in. Good for them.');G.stats.sanity=Math.max(0,G.stats.sanity-3);},
 *boatWren(){yield N('The hatch is padlocked from the inside. Someone has scratched into the paint: STILL HERE. DON’T KNOCK.');},
 *boatKingfisher(){const f=F();if(f.kingfisher){yield N('You’ve taken what’s useful.');return;}f.kingfisher=1;
  yield N('The Kingfisher. Unlocked. Neat as a pin inside, and nobody aboard.');
  giveItem('bat');giveItem('peaches');
  yield N('A cricket bat in the rack by the door. A tin of peaches in the galley.');
  yield N('Someone looked after this boat. They won’t mind.');},
 *wardensMeet(){const f=F();if(f.wardens)return;f.wardens=1;
  const cole=G.map.ents.find(e=>e.style==='cole');
  yield say('COLE','That’s close enough.');
  yield say('COLE','Hands where I can see them. You on your own?');
  const c=yield ask(['“Yes.”','“Who are you?”']);
  if(c===1)yield say('COLE','Doesn’t matter who we are. Matters what we’ve got.');
  yield say('COLE','Nobody comes past this lock. There’s clean water this side, and we’re keeping it clean.');
  yield say('COLE','You’ve got the look, you know that? Calm. They’re all calm, at the start.');
  const c2=yield ask(['“I’m not sick.”','“I need to get to the Barbican.”']);
  if(c2===0)yield say('COLE','That’s what he said.');
  else{yield say('COLE','The Barbican.');yield say('COLE','Course you do. Everyone wants the Barbican.');}
  yield say('COLE','You want west, take the Tube. Mile End station, up on the path. Council chained the gate, not us. Find something to cut it.');
  yield say('COLE','And stay away from the cage.');
  UI.objective('Find a way through the chained gate at Mile End station.');
  G.timers.push({t:1,fn:()=>murmur('A cage on the towpath. There’s someone inside it.',4)});},
 *cole(){const f=F();
  if(G.flags.hospDone&&!f.farrowFree){yield say('COLE','Told you. Slept, and never woke up. Same as all the rest.');yield say('COLE','You did right, leaving him. Doesn’t feel like it. It was.');return;}
  yield say('COLE',pick(['Station’s that way. Go on.','I said stay back.','You’re still here.']));},
 *jas(){yield say('JAS','Don’t. Just… don’t come closer. Please.');},
 *jasNight(){yield say('JAS','Oh — hello.');yield say('JAS','It’s a lovely night, isn’t it? Cole’s asleep. Everyone’s asleep.');yield say('JAS','I just feel… really calm. For the first time since all this.');yield N('They’re resting. Good.');},
 *farrow(){const f=F();
  if(f.farrowFree){yield N('The cage is open, and empty.');return;}
  if(G.flags.hospDone){yield* S.farrowDead();return;}
  const e=G.map.ents.find(x=>x.style==='farrow');if(e){e.talking=true;e.facePlayer();}
  if(!f.farrow1){f.farrow1=1;
   yield say('FARROW','Hello. Sorry — hello. They won’t tell me how long. It’s been two nights.');
   yield say('FARROW','I feel fine. Honestly. I’ve never felt better.');
   const c=yield ask(['“Why are you in there?”','“Are you hungry?”']);
   if(c===0)yield say('FARROW','They think I’m sick because I’m calm. Isn’t that funny? Everyone’s so frightened, and I’m just… not.');
   else yield say('FARROW','No. No, not at all. I tried to give them my food. They wouldn’t take it.');
   yield say('FARROW','The key’s on the hook by their fire. They sleep half the night.');
   yield say('FARROW','You understand, don’t you? You’re calm too.');}
  else yield say('FARROW','You came back. I knew you would.');
  yield N('He’s fine. Look at him. He should be let out.');
  const c2=yield ask(['Get the key and let him out','Not yet','Leave him there']);
  if(e)e.talking=false;
  if(c2===0){yield N('Cole is arguing with someone by the tents. Nobody is watching the fire.');yield fade(1,.6);
   f.farrowFree=1;f.inf_wardens=1;const cg=G.map.props.find(p=>p.name==='cage');if(cg){cg.o.v='open';}
   if(e){e.x=tx(15);e.y=ty(13);e.hidden=true;}shared('wardens_via_farrow');
   yield fade(0,.6);yield say('FARROW','Thank you. Thank you. I’ll go and talk to them — they’ll understand, once they see I’m fine.');
   yield N('He climbs out along the lock gates, towards their tents, without a sound.');yield N('That was kind.');}
  else if(c2===2){f.farrowLeft=1;refused();yield N('He watches you go, still smiling.');}},
 *farrowDead(){yield N('Farrow is lying on the floor of the cage, on his side, smiling.');yield N('He’s asleep. Let him sleep.');G.stats.sanity=Math.max(0,G.stats.sanity-4);},
 *stationGate(){const f=F();
  if(f.gateCut){yield go('a2_tunnel');return;}
  if(!hasItem('cutters')){yield N('Mile End station. A chain and a padlock as thick as your wrist across the gate.');yield N('You’d need bolt cutters.');if(!f.wardens)UI.objective('Find a way through the chained gate at Mile End station.');return;}
  if(!f.insulin&&!f.hospWarn){f.hospWarn=1;yield N('You could leave now. Mara would never know.');const c=yield ask(['Cut the chain','Not yet']);if(c===1)return;}
  Snd.play('hitMetal');G.shake=4;yield N('The chain parts with a crack that echoes all the way down the stairs.');
  f.gateCut=1;G.map.set(20,5,T.stationIn);G.map.tc=null;G.map.exits['20,5'].label='Down into Mile End station';
  if(f.theoAsk===undefined&&!f.theoWith&&!f.theoStay&&f.insulin){}
  UI.objective('Go down into the station.');},
// ---------- hospital ----------
 *hospEnter(){yield go('a2_hosp',{pos:[tx(8),ty(14)-2],dir:3});},
 *hospLeave(){const f=F();
  if(f.insulin&&!f.theoWith&&!f.theoStay){yield* S.theoChoice();}
  yield go('a2_canal',{pos:[tx(56)+8,ty(7)],dir:0});},
 *hospDown(){yield fade(1,.35);P.x=tx(2)+8;P.y=ty(20)+2;P.dir=2;P.fx=1;P.fy=0;G.cam.x=P.x;G.cam.y=P.y;if(G.theo){G.theo.x=P.x-12;G.theo.y=P.y;}yield fade(0,.35);
  if(!F().basement){F().basement=1;yield N('The basement. The air is warm and wet.');yield N('The pharmacy is at the far end of the corridor.');}},
 *hospUp(){yield fade(1,.35);P.x=tx(3)+8;P.y=ty(13)+4;P.dir=0;P.fx=0;P.fy=1;G.cam.x=P.x;G.cam.y=P.y;if(G.theo){G.theo.x=P.x+12;G.theo.y=P.y;}yield fade(0,.35);},
 *a2Hosp(){const f=F();if(f.maraMet)return;f.maraMet=1;
  const m=G.mara;yield wait(.5);
  yield say('MARA','Stop there. Stay by the door.');
  if(m){yield walk(m,P.x,P.y-22);m.facePlayer();}
  yield say('MARA','Look at me. No — at the light.');
  UI.flash('#fff',.5,.55);yield wait(.9);
  yield say('MARA','…');
  yield say('MARA','Your pupils don’t change. In the dark, in the light. They just… stay.');f.clue_pupils=1;
  const c=yield ask(['“Is that bad?”','“I’m not sick.”']);
  yield say('MARA',c===0?'I don’t know what it is. I’ve seen it in every one of them who came in calm.':'Nobody thinks they are.');
  yield say('MARA','I’m Mara. I was a nurse at the Royal London, before. Now I’m whatever this is.');
  yield say('MARA','You can stay in the lobby. Not the ward. And you don’t sleep in a room with any of us. That’s the rule. It’s not personal.');
  Snd.play('bark');yield wait(.6);
  yield N('A bark, from the ward. You know that bark.');
  yield say('MARA','He turned up two days ago. Sweetest dog. Sleeps on Theo’s bed.');
  yield say('MARA','He doesn’t like you much, does he?');
  const c2=yield ask(['“He’s mine. His name’s Biscuit.”','Say nothing.']);
  if(c2===0)yield say('MARA','Biscuit. Well. He’s found himself a new family.');
  yield say('MARA','If you’re staying, I need something from you. Mr Halloran — he’s diabetic, and we’re out of insulin.');
  yield say('MARA','The pharmacy’s in the basement. I’m not going down there again. There are… people down there. The ones that scream.');
  const c3=yield ask(['“I’ll go.”','“What’s in it for me?”']);
  if(c3===1)yield say('MARA','Food. Water. And there’s a maintenance room down there, if it’s tools you’re after.');
  else yield say('MARA','Thank you. Stairs are in the corner. It’s pitch black down there.');
  if(f.wardens&&!hasItem('cutters'))yield say('MARA','Bolt cutters? Maintenance room. Basement. Same place.');
  if(m){yield walk(m,tx(17)+8,ty(8));m.fixedDir=1;}
  UI.objective('Fetch insulin from the basement pharmacy.');},
 *mara(){const f=F();
  if(hasItem('insulin')&&!f.insulin){f.insulin=1;takeItem('insulin');
   yield say('MARA','You found it.');yield say('MARA','…Thank you. Really.');
   giveItem('water',2);giveItem('beans');
   yield say('MARA','Here. Water and food. It’s what we’ve got.');
   yield say('MARA','You can sleep on the bench in the lobby tonight. I’ll lock the ward door.');
   f.hospDone=1;
   const m=G.mara;if(m){yield walk(m,tx(22),ty(11));m.fixedDir=0;}
   const t=G.map.ents.find(e=>e.style==='theo')||npc(G.map,tx(18)+8,ty(6),'theo',{fixedDir:1,scale:.8,clean:f.inf_theo?0:1});t.interact=I('Theo',S.theoTalk);t.pose=null;
   const h=G.map.ents.find(e=>e.style==='halloran');if(h){h.pose=null;h.speed=40;h.target=[tx(18)+8,ty(8)+4];h.onArrive=()=>{h.fixedDir=1;};}
   t.speed=40;t.target=[tx(13),ty(10)];t.onArrive=()=>{t.fixedDir=3;};
   UI.objective(hasItem('cutters')||f.gateCut?'Go to Mile End station and cut the chain.':'Find bolt cutters (maintenance room, basement).');return;}
  if(!f.insulin){yield say('MARA',hasItem('cutters')?'And the insulin? The pharmacy, Rowan. Please.':'The pharmacy’s at the end of the basement corridor.');return;}
  if(f.board&&!f.boardAsk){f.boardAsk=1;yield say('MARA','That note on the board? It was there one morning last week. I never saw who left it.');yield say('MARA','Whoever it was had the sense to write it down.');return;}
  yield say('MARA',pick(['Get some rest.','Keep your distance from the kid. Please.','We’re doing alright, here. Considering.']));},
 *noticeboard(){const f=F();
  yield N('Rota sheets. A child’s drawing of a dog. A list of names with lines through them.');
  if(!f.board){f.board=1;f.clue_board=1;
   yield note({id:'board',text:'Day 7.\n\nMara, if you find this:\ndon’t let me in.\nWhatever I say.\n\n— R'});
   yield N('Your handwriting.');yield N('You’ve never been here before.');}},
 *theoTalk(){const f=F();const e=G.theo&&G.theo.follow?G.theo:G.map.ents.find(x=>x.style==='theo');
  if(f.theoWith){yield say('THEO',pick(['Is it much further?','Mum always said the Barbican looks like a castle.','I’m alright. I’m fine.']));return;}
  if(!f.theo1){f.theo1=1;
   yield say('THEO','Are you one of the calm ones?');
   const c=yield ask(['“What do you mean?”','“No.”']);
   yield say('THEO','Mum went calm. Before she went to the Barbican. She was so happy. She kept giving people things.');
   yield say('THEO','Mara says the calm ones don’t wake up.');
   yield N('He’s frightened. Children say strange things.');return;}
  if(f.insulin&&f.theoWater===undefined){
   yield say('THEO','Have you got any water? Mara’s rationing it. I’m so thirsty.');
   if(!hasItem('water')){yield N('You don’t have any.');return;}
   yield N('Give him some. It’s the kind thing to do.');
   const c=yield ask(['Give Theo some of your water','“Sorry. I need it.”']);
   if(c===0){f.theoWater=1;takeItem('water');shared('theo');if(e)e.clean=0;yield N('He drinks half the bottle in one go, and smiles at you. It’s the first time he’s smiled.');}
   else{f.theoWater=0;refused();yield say('THEO','…Okay.');}
   return;}
  yield say('THEO',pick(['Biscuit sleeps on my feet. He snores.','Mr Halloran knows every card trick in the world.','Do you think Mum’s alright?']));},
 *theoChoice(){const f=F();f.theoAsk=1;
  const t=G.map.ents.find(x=>x.style==='theo');if(t){t.talking=true;t.facePlayer();}
  yield say('THEO','Wait! Take me with you. Please.');
  yield say('THEO','Mum’s at the Barbican. I know she is. I know it.');
  yield say('MARA','Theo. No.');
  yield N('He shouldn’t be alone. Take him with you. You could keep him safe.');
  const c=yield ask(['Take Theo with you','“Stay with Mara, Theo.”']);
  if(c===0){f.theoWith=1;yield say('MARA','…I can’t keep him here if he won’t stay. I’ve tried.');yield say('MARA','If anything happens to him, Rowan.');yield say('THEO','I’ll be quiet. I promise.');
   if(t){t.talking=false;t.follow=1;t.ghost=1;t.solid=false;G.theo=t;}}
  else{f.theoStay=1;yield say('THEO','…Fine.');if(t){t.talking=false;t.target=[tx(18)+8,ty(7)];}yield say('MARA','Thank you.');}},
 *halloran(){const f=F();
  if(!f.insulin){yield say('HALLORAN','Don’t mind me. Just an old man waiting on his medicine. And his tea.');return;}
  if(f.hTea===undefined){
   yield say('HALLORAN','You’re a saint. A wet, grim-looking saint, but a saint.');
   yield say('HALLORAN','Here — sit a minute. Have some tea. I’ve a flask, and one cup, and I’m not proud.');
   yield N('Go on. Share it with him. He’s lonely.');
   const c=yield ask(['Share his tea','“No, thank you.”']);
   if(c===0){f.hTea=1;shared('halloran');yield N('You drink. He takes the cup back and finishes it. It’s a nice moment.');yield say('HALLORAN','Grand. Now I feel human.');}
   else{f.hTea=0;refused();yield say('HALLORAN','Suit yourself. More for me.');}
   return;}
  yield say('HALLORAN',pick(['Did I tell you I was a postman? Forty years. Bow, mostly.','The girl’s a good nurse. Don’t tell her I said so.','If you see a decent biscuit out there, think of me.']));},
 *biscuitHosp(){Snd.play('growl');F().clue_dog=1;yield N('Biscuit backs away from you, low and growling, and puts himself between you and Theo.');},
 *hospRest(){const f=F();if(!f.insulin){yield N('Later. There’s something you need to do first.');return;}if(f.hospRested){yield N('You’ve rested.');return;}f.hospRested=1;
  yield N('You lie down on the bench. Somewhere upstairs, a key turns in a lock.');yield fade(1,1.4);
  G.stats.sanity=Math.min(100,G.stats.sanity+20);G.stats.health=Math.min(100,G.stats.health+25);Story.checkpoint([tx(5)+8,ty(14)-2]);
  yield N('You sleep, and the hum keeps you company.');yield fade(0,1.2);},
// ---------- tunnel ----------
 *a2Tunnel(){yield wait(.5);murmur('Below the first landing, the dark is total.',4);UI.objective('Follow the tracks west to Bethnal Green.');
  if(F().theoWith)G.timers.push({t:4,fn:()=>G.theo&&bubble(G.theo,'It’s so dark.',{t:3})});},
 *tunnelBack(){yield go('a2_canal',{pos:[tx(20),ty(7)],dir:0});},
 *trainSleeper(){yield N(pick(['A carriage full of people, sitting up, eyes closed. Resting.','Someone’s head on someone else’s shoulder. Both smiling.','A commuter, still holding his paper. Fast asleep.']));G.stats.sanity=Math.max(0,G.stats.sanity-2);},
 *tunnelRadio(){const f=F();if(f.tradio){Snd.set('static',.02,.1);yield N('Static.');Snd.set('static',0,.3);return;}f.tradio=1;f.clue_radio3=1;
  yield N('An emergency radio on a shelf, still running on its battery.');Snd.set('static',.02,.1);yield wait(.8);
  yield say('RADIO','—they want to be near you. They will try to share food and water. Do not accept anything from—',{});
  yield say('RADIO','—the calm ones are trying to reach the shelters. The Barbican shelter is sealed. Do not approach the Barbican. Do NOT admit anyone who—',{fast:1});
  Snd.set('static',.07,.05);UI.flash('#000',.4,.6);yield wait(.4);Snd.set('static',.015,.2);
  yield N('Static. Nothing useful.');Snd.set('static',0,.6);},
 *tunnelEnd(){const f=F();
  yield N('Bethnal Green. The stairs go up towards a grey square of daylight.');
  if(f.theoWith){const t=G.theo;if(t){t.follow=0;t.talking=true;t.facePlayer();}
   yield say('THEO','Rowan…');yield say('THEO','I’m so tired.');
   yield N('Let him sleep. He needs to rest.');}
  yield N('The City is close now. Ellie is close now.');
  Story.checkpoint([tx(3),ty(4)]);
  yield fade(1,2);
  Story.endStage2();},
});
// ---------- tweaks to earlier scripts for the new phases ----------
wrapS('rest',['a1_shop','a2_shop'],function*(){const f=F();
 if(PH()==='a2_shop'){yield N('You’ve slept enough.');return;}
 if(!f.restA1){
  if(countItem('water')===0&&G.stats.thirst<40){yield N('You need water first. You can’t rest like this.');return;}
  f.restA1=1;Story.checkpoint([tx(12),ty(3)+2]);
  yield N('The stockroom door locks from the inside. Good.');
  G.stats.sanity=Math.min(100,G.stats.sanity+25);G.stats.health=Math.min(100,G.stats.health+20);
  yield N('Tomorrow, north. The Barbican. Ellie.');
  yield fade(1,2.2);
  yield N('We should rest.');yield wait(1.6);yield N('You should rest.');F().clue_we=1;yield wait(1.2);}
 else{const c=yield ask(['Sleep until morning','Not yet']);if(c===1)return;yield fade(1,1.5);}
 Story.checkpoint([tx(12),ty(3)+2]);
 yield go('a2_shop',{card:['MONDAY','26 October']});});
wrapS('shopLeave',['a2_shop'],function*(){yield go('a2_street',{pos:[tx(42),ty(10)-2],dir:0});});
wrapS('shopDoor',['a2_street'],function*(){yield go('a2_shop',{pos:[tx(7),ty(9)-2],dir:3});});
wrapS('streetHome',['a2_street'],function*(){yield go('a2_flat',{pos:[tx(6),ty(10)-3],dir:3});});
wrapS('flatDoor',['a2_flat'],function*(){if(!F().a2page&&!F().a2doorWarn){F().a2doorWarn=1;yield N('There’s a piece of paper on the floor by the door.');return;}yield go('a2_street',{pos:[tx(9),ty(10)-3],dir:0});});
wrapS('flatPhoto',['a2_flat'],function*(){yield cu('photo',{stage:3});yield N('You, at Southend. On your own.');yield N('You must have taken it yourself.');yield cuClose();F().clue_photo3=1;});
wrapS('flatMirror',['a2_flat'],function*(){yield cu('mirror',{tired:0,flicker:1});yield N('You look well. Rested.');yield cuClose();});
wrapS('flatBed',['a2_flat'],function*(){yield N('No time.');});
wrapS('feedDog',['a2_flat'],function*(){yield N('The bowl is on its side. Empty.');});
wrapS('station',['a2_street'],function*(){yield N('The shutters are still down. DON’T LET THEM IN.');});
wrapS('flatKettle',['a2_flat'],function*(){yield N('No power. No water. No tea.');});
// photo stage 3: only Rowan
{const old=CLOSEUP.photo;CLOSEUP.photo=(x,t,s)=>{old(x,t,s);if(s.stage===3){x.fillStyle='#8a9aa4';x.fillRect(46,18,22,12);x.fillStyle='#6a7e8a';x.fillRect(46,30,22,10);x.fillStyle='#c8b48a';x.fillRect(46,40,22,32);x.fillStyle='rgba(240,220,180,.12)';x.fillRect(46,18,22,54);}};}
// ---------- phases ----------
Object.assign(PHASES,{
 a2_shop:{map:'shop',spawn:[tx(12),ty(3)+2],dir:0,card:['MONDAY','26 October'],enter:S.a2Wake},
 a2_street:{map:'street',spawn:[tx(42),ty(10)-2],dir:0,enter:S.a2Street},
 a2_flat:{map:'flat',spawn:[tx(6),ty(10)-3],dir:3,enter:S.a2Flat},
 a2_canal:{map:'canal',spawn:[tx(107),ty(19)-2],dir:1,enter:S.a2Canal},
 a2_hosp:{map:'hosp',spawn:[tx(8),ty(14)-2],dir:3,enter:S.a2Hosp},
 a2_tunnel:{map:'tunnel',spawn:[tx(118),ty(4)+6],dir:1,enter:S.a2Tunnel},
});
Story.endStage2=()=>{G.state='end';UI.hudOn(false);Snd.set('drone',0,2);Snd.set('hum',0,2);
 UI.card('LULL','End of Stage Two · Act III next',()=>{setTimeout(()=>Game.toTitle(),400);},5);};
