// ================= PLAYER =================
const P={graceT:0,x:0,y:0,hw:4,hh:4,dir:0,fx:0,fy:1,anim:0,moving:false,stam:100,stamDelay:0,swing:-1,swingHit:false,atkCd:0,dodgeT:0,dodgeCd:0,dvx:0,dvy:0,iT:0,hurtT:0,stepT:0,torch:false,battery:0,pose:null,
 hbox(){return{x0:this.x-this.hw,y0:this.y-this.hh,x1:this.x+this.hw,y1:this.y};}};
function weapon(){return G.equip&&ITEMS[G.equip]?ITEMS[G.equip].weapon:FISTS;}
function canAct(){return G.state==='play'&&!G.cut&&!G.modal;}
function updatePlayer(dt){
 const p=P;
 p.atkCd=Math.max(0,p.atkCd-dt);p.dodgeCd-=dt;p.iT-=dt;p.hurtT-=dt;
 let ix=0,iy=0;const act=canAct();
 if(act&&!p.pose){if(Input.is('left'))ix--;if(Input.is('right'))ix++;if(Input.is('up'))iy--;if(Input.is('down'))iy++;}
 const mag=Math.hypot(ix,iy);if(mag){ix/=mag;iy/=mag;}
 let speed=46;const sprint=act&&Input.is('sprint')&&mag&&p.stam>2&&!G.lull;
 if(sprint){speed=78;p.stam-=19*dt;p.stamDelay=.6;}
 if(G.lull)speed*=G.lull.slow;
 if(G.stats.health<25)speed*=.86;
 if(G.slowWalk)speed*=.75;
 if(G.speedMul!==undefined)speed*=G.speedMul;
 if(p.dodgeT>0){p.dodgeT-=dt;moveActor(p,p.dvx*dt,p.dvy*dt);p.dvx*=.9;p.dvy*=.9;
  if(Math.random()<.5)G.parts.push({x:p.x+rand(-3,3),y:p.y-1,vx:0,vy:-6,life:.35,max:.35,col:'rgba(160,170,180,.35)',s:2});}
 else{const k=p.swing>=0?.35:1;moveActor(p,ix*speed*k*dt,iy*speed*k*dt);}
 if(mag&&p.swing<0&&p.dodgeT<=0){p.fx=ix;p.fy=iy;p.dir=Math.abs(ix)>Math.abs(iy)?(ix<0?1:2):(iy<0?3:0);}
 p.moving=mag>0&&p.dodgeT<=0;
 if(p.moving){p.anim+=dt*(sprint?10:7);p.stepT-=dt;if(p.stepT<=0){p.stepT=sprint?.24:.33;const t=G.map.tile(Math.floor(p.x/16),Math.floor((p.y-2)/16));Snd.play('step',{s:STEP_OF(t),v:G.map.outdoor&&G.map.rain?1.2:1});
  if(G.map.rain&&G.map.outdoor&&Math.random()<.5)G.parts.push({x:p.x+rand(-3,3),y:p.y,vx:rand(-8,8),vy:-14,g:60,life:.3,max:.3,col:'rgba(150,170,190,.5)',s:1});}}
 else p.anim=0;
 // attack
 if(act&&!p.pose&&!G.lull&&Input.hit('attack')&&p.atkCd<=0&&p.swing<0&&G.flags.canFight){const w=weapon();
  if(p.stam>=w.stam*.5){p.swing=0;p.swingHit=false;p.atkCd=w.cd;p.stam-=w.stam;p.stamDelay=.7;Snd.play('swing');}else{UI.stamFlash();}}
 if(p.swing>=0){p.swing+=dt;if(!p.swingHit&&p.swing>=.07){p.swingHit=true;doHit();}if(p.swing>=.26)p.swing=-1;}
 // dodge
 if(act&&!p.pose&&Input.hit('dodge')&&p.dodgeCd<=0&&p.stam>=18&&!G.lull&&G.flags.canFight){const dx=mag?ix:p.fx,dy=mag?iy:p.fy;p.dvx=dx*180;p.dvy=dy*180;p.dodgeT=.2;p.dodgeCd=.45;p.iT=.3;p.stam-=18;p.stamDelay=.6;Snd.play('dodge');}
 p.stamDelay-=dt;if(p.stamDelay<=0)p.stam=Math.min(100,p.stam+28*dt);
 // torch
 if(act&&Input.hit('torch')&&hasItem('torch')){if(p.battery>0){p.torch=!p.torch;Snd.play('torch');}else murmur('The torch is dead. You need batteries.');}
 if(p.torch){p.battery-=dt*.3;if(p.battery<=0){p.battery=0;p.torch=false;Snd.play('torch');murmur('The torch flickers, and dies.');}}
}
function doHit(){
 const w=weapon(),ox=P.x,oy=P.y-7;let any=false;
 for(const e of G.map.ents){if(!e.hittable||e.dead)continue;const ex=e.x,ey=e.y-8,d=dist(ox,oy,ex,ey);if(d>w.reach+8)continue;
  const dot=((ex-ox)*P.fx+(ey-oy)*P.fy)/(d||1);if(d>9&&dot<.3)continue;e.damage(w.dmg*rand(.9,1.12),P.fx,P.fy,w.knock);any=true;}
 if(any){G.hitstop=.07;G.shake=Math.max(G.shake,3.5);Snd.play(G.equip==='crowbar'?'hitMetal':'hit');}
}
function hurtPlayer(dmg,cause,silent){
 if(G.lull||G.state!=='play')return;
 if(!silent&&(P.iT>0||P.graceT>0||G.cut||(!G.coop&&G.modal&&G.modal!=='inv')))return;
 G.stats.health=Math.max(0,G.stats.health-dmg);G.lastCause=cause;
 if(!silent){P.iT=.55;P.hurtT=.3;G.shake=Math.max(G.shake,5);G.redFlash=.5;Snd.play('hurt');G.stats.sanity=Math.max(0,G.stats.sanity-2.5);
  for(let i=0;i<8;i++)G.parts.push({x:P.x,y:P.y-9,vx:rand(-40,40),vy:rand(-50,-5),g:140,life:.5,max:.5,col:'#3a0c0c',s:2});}
}

// ================= ACTORS =================
class Actor{
 constructor(x,y,o={}){this.x=x;this.y=y;this.hw=4;this.hh=4;this.dir=0;this.anim=0;this.moving=false;this.solid=true;this.stuck=0;Object.assign(this,o);}
 hbox(){return{x0:this.x-this.hw,y0:this.y-this.hh,x1:this.x+this.hw,y1:this.y};}
 face(dx,dy){this.dir=Math.abs(dx)>Math.abs(dy)?(dx<0?1:2):(dy<0?3:0);}
 facePlayer(){this.face(P.x-this.x,P.y-this.y);}
 walkTo(x,y,sp,dt){const dx=x-this.x,dy=y-this.y,d=Math.hypot(dx,dy);if(d<2){this.moving=false;return true;}
  const s=Math.min(d,sp*dt),bx=this.x,by=this.y;this.face(dx,dy);if(this.ghost){this.x+=dx/d*s;this.y+=dy/d*s;}else moveActor(this,dx/d*s,dy/d*s);this.moving=true;
  if(Math.abs(this.x-bx)+Math.abs(this.y-by)<s*.3)this.stuck+=dt;else this.stuck=0;return false;}
 update(dt){}
}
class NPC extends Actor{
 constructor(x,y,style,o={}){super(x,y,o);this.style=style;this.kind='npc';this.pi=0;this.speed=this.speed||24;this.wait=0;this.barkT=rand(1,3);this.barkI=0;}
 update(dt){
  if(this.follow&&!this.talking&&!this.target){const d=dist(this.x,this.y,P.x,P.y);if(d>150||(this.stuck>1.2&&d>60)){this.x=P.x-P.fx*14;this.y=P.y-P.fy*10;this.stuck=0;}else if(d>26)this.walkTo(P.x-P.fx*16,P.y-P.fy*12,d>60?72:46,dt);else{this.moving=false;if(d<50)this.facePlayer();}}
  else if(this.target){if(this.walkTo(this.target[0],this.target[1],this.speed,dt)||this.stuck>1.2){this.target=null;this.moving=false;this.stuck=0;if(this.onArrive){const f=this.onArrive;this.onArrive=null;f();}}}
  else if(this.path&&!this.talking){if(this.wait>0){this.wait-=dt;this.moving=false;}else{const p=this.path[this.pi];if(this.walkTo(p[0],p[1],this.speed,dt)||this.stuck>1){this.pi=(this.pi+1)%this.path.length;this.wait=p[2]||0;this.stuck=0;if(p[3]==='warp'){const q=this.path[this.pi];this.x=q[0];this.y=q[1];}}}}
  else this.moving=false;
  if(this.talking||(this.watch&&dist(this.x,this.y,P.x,P.y)<this.watch))this.facePlayer();
  if(this.fixedDir!==undefined&&!this.talking&&!this.moving)this.dir=this.fixedDir;
  this.anim+=dt*(this.moving?7:0);
  if(this.clean&&G.showHum){const dd=dist(this.x,this.y,P.x,P.y);if(dd<120){G.humNear=Math.max(G.humNear,1-dd/120);if(dd<50)G.flags.clue_hum=1;}}
  if(this.barks&&!G.cut&&this.barkI<this.barks.length){const d=dist(this.x,this.y,P.x,P.y);if(d<(this.barkR||70)){this.barkT-=dt;if(this.barkT<=0){bubble(this,this.barks[this.barkI++]);this.barkT=rand(4.5,6.5);}}}
 }
 draw(c,ox,oy){const fr=this.moving?((this.anim|0)%4)+1:0;const lie=this.pose==='lie';drawHum(c,this.style,this.dir,this.pose||(this.moving?'walk':'idle'),fr,{smile:this.smile||(G.lull&&this.infected),closed:this.closed,weapon:this.weapon,scale:this.scale},q(this.x-(lie?12:8))-ox,q(this.y-(lie?10:24))-oy);}
}
class Sleeper extends Actor{
 constructor(x,y,style,o={}){super(x,y,o);this.style=style;this.kind='sleeper';this.pose=o.pose||'lie';this.solid=this.pose!=='lie';this.corpse=true;this.flyT=rand(2);}
 update(dt){this.flyT-=dt;if(this.flyT<=0&&G.truthNow){this.flyT=.25;G.parts.push({x:this.x+rand(-8,8),y:this.y-rand(4,12),vx:rand(-20,20),vy:rand(-20,20),life:.6,max:.6,col:'#0a0a0a',s:1,fly:1});}}
 draw(c,ox,oy){const truth=G._truthPass||(G.truthNow&&!G.lull);
  if(this.pose==='lie')drawHum(c,this.style,0,'lie',0,{closed:!truth,dead:truth,smile:!truth&&this.smile,scale:this.scale},q(this.x-12)-ox,q(this.y-10)-oy);
  else drawHum(c,this.style,this.dir,'sit',0,{closed:!truth,dead:truth,smile:!truth&&this.smile,scale:this.scale},q(this.x-8)-ox,q(this.y-24)-oy);}
}
// ================= DOG =================
class Dog extends Actor{
 constructor(x,y,o={}){super(x,y,o);this.kind='dog';this.mode=this.mode||'idle';this.hw=5;this.hh=3;this.solid=false;this.growlCd=0;this.barkCd=0;this.pose='sit';}
 update(dt){
  this.growlCd-=dt;this.barkCd-=dt;const d=dist(this.x,this.y,P.x,P.y);this.pose='stand';
  if(this.mode==='follow'){if(d>30){const tx=P.x-P.fx*14,ty=P.y-P.fy*10;this.walkTo(tx,ty,d>70?84:58,dt);if(this.stuck>1.5&&d>90){this.x=P.x-P.fx*12;this.y=P.y-P.fy*8;this.stuck=0;}}else{this.moving=false;this.pose='sit';}if(this.heel){this.dir=P.x<this.x?1:2;}}
  else if(this.mode==='wary'){if(d<44){const dx=this.x-P.x,dy=this.y-P.y,l=Math.hypot(dx,dy)||1;this.walkTo(this.x+dx/l*20,this.y+dy/l*20,52,dt);this.pose='growl';if(this.growlCd<=0){Snd.play('growl');this.growlCd=3.2;G.flags.clue_dog=1;}}else{this.moving=false;this.pose=d<90?'growl':'sit';this.dir=P.x<this.x?1:2;}}
  else if(this.mode==='hide'){this.moving=false;this.pose=d<56?'growl':'sit';this.dir=P.x<this.x?1:2;if(d<40&&this.growlCd<=0){Snd.play('growl');this.growlCd=3.5;G.flags.clue_dog=1;}}
  else if(this.mode==='goto'){if(this.walkTo(this.tx,this.ty,50,dt)||this.stuck>2){this.mode=this.after||'idle';this.moving=false;}}
  else{this.moving=false;this.pose=this.idlePose||'sit';if(d<60)this.dir=P.x<this.x?1:2;}
  if(this.moving)this.pose='walk';
  this.anim+=dt*(this.moving?8:2.5);
 }
 draw(c,ox,oy){const fr=(this.anim|0)%2;const dd=this.dir===2?2:1;drawDogImg(c,dd,this.pose,fr,q(this.x-10)-ox,q(this.y-13)-oy);}
 bark(){if(this.barkCd>0)return;this.barkCd=1.2;Snd.play('bark');bubble(this,'Woof!',{shout:1});}
}
// ================= HOLLOWED =================
class Hollow extends Actor{
 constructor(x,y,o={}){super(x,y,o);this.kind='hollow';this.hp=this.hp||46;this.maxhp=this.hp;this.hx=x;this.hy=y;this.state='idle';this.t=rand(1,3);this.hittable=true;this.hw=4;this.hh=4;
  this.truth=this.truth||pick(['t1','t2','t3']);this.vx=0;this.vy=0;this.flash=0;this.guard=this.guard||80;this.shoutT=0;this.jit=0;this.lines=this.lines||['STAY BACK!','Please — just go!','We’re not sick!','Don’t come any closer!','PLEASE!'];}
 hbox(){return{x0:this.x-this.hw,y0:this.y-this.hh,x1:this.x+this.hw,y1:this.y};}
 update(dt){
  if(this.dead){return;}
  if(G.cut||(G.modal&&G.modal!=='inv')){this.moving=false;if(this.state==='lunge'||this.state==='wind'){this.state='recover';this.t=.9;}return;}
  const d=dist(this.x,this.y,P.x,P.y);this.t-=dt;this.flash-=dt;this.shoutT-=dt;this.jit+=dt;
  if(d<130)G.humNear=Math.max(G.humNear,1-d/130);
  if(this.vx||this.vy){moveActor(this,this.vx*dt,this.vy*dt);this.vx*=.82;this.vy*=.82;if(Math.abs(this.vx)<1)this.vx=0;if(Math.abs(this.vy)<1)this.vy=0;}
  const home=dist(this.x,this.y,this.hx,this.hy);
  const seen=d<this.guard+(P.torch?30:0)&&G.state==='play'&&!G.cut;
  switch(this.state){
   case 'idle':this.moving=false;if(this.t<=0){this.t=rand(2,4);this.wx=this.hx+rand(-24,24);this.wy=this.hy+rand(-16,16);}
    if(this.wx!==undefined&&dist(this.x,this.y,this.wx,this.wy)>3)this.walkTo(this.wx,this.wy,14,dt);
    if(seen){this.state='alert';this.t=.7;this.facePlayer();Snd.play('shriek',{pan:clamp((this.x-P.x)/120,-1,1)});this.shout();if(!G.flags.firstHollow){G.flags.firstHollow=1;Story.firstHollow(this);}}break;
   case 'alert':this.moving=false;this.facePlayer();if(this.t<=0)this.state='chase';break;
   case 'chase':{if(home>this.guard*2.2||G.lull){this.state='return';break;}this.walkTo(P.x,P.y,58,dt);if(d<19){this.state='wind';this.t=.42;this.moving=false;}if(this.shoutT<=0&&Math.random()<.01)this.shout();break;}
   case 'wind':this.facePlayer();if(this.t<=0){this.state='lunge';this.t=.2;const l=d||1;this.lx=(P.x-this.x)/l;this.ly=(P.y-this.y)/l;this.hitDone=false;Snd.play('swing');}break;
   case 'lunge':moveActor(this,this.lx*150*dt,this.ly*150*dt);if(!this.hitDone&&dist(this.x,this.y,P.x,P.y)<15){this.hitDone=true;if(P.iT<=0&&P.graceT<=0){hurtPlayer(rand(12,17),'hollow');moveActor(P,this.lx*6,0);moveActor(P,0,this.ly*6);}}if(this.t<=0){this.state='recover';this.t=.6;}break;
   case 'recover':this.moving=false;if(this.t<=0)this.state=d<this.guard*1.4?'chase':'return';break;
   case 'stagger':this.moving=false;if(this.t<=0){if(this.hp<this.maxhp*.35){this.state='flee';this.t=2.6;}else this.state='chase';}break;
   case 'flee':{const dx=this.x-P.x,dy=this.y-P.y,l=Math.hypot(dx,dy)||1;this.walkTo(this.x+dx/l*30,this.y+dy/l*30,60,dt);if(this.shoutT<=0)this.shout(['Please!','No — no, please—','Leave us alone!']);if(this.t<=0||d>150){this.state='return';}break;}
   case 'return':if(this.walkTo(this.hx,this.hy,30,dt)||this.stuck>2){this.state='idle';this.t=2;}if(seen&&home<this.guard&&this.hp>this.maxhp*.35)this.state='chase';break;
  }
  this.anim+=dt*(this.moving?8:3);
 }
 shout(lines){this.shoutT=rand(3,5);if(G.stats.sanity<45||G.truthNow){bubble(this,pick(lines||this.lines),{shout:1,truth:1});G.flags.clue_shout=1;}}
 damage(dmg,fx,fy,kb){
  if(this.dead)return;this.hp-=dmg;this.flash=.12;this.vx=fx*kb;this.vy=fy*kb;Snd.play('enemyHurt');
  for(let i=0;i<7;i++)G.parts.push({x:this.x,y:this.y-10,vx:fx*rand(20,70)+rand(-20,20),vy:fy*rand(20,70)+rand(-40,0),g:120,life:.6,max:.6,col:G.truthNow?'#5a0a0a':'#0b0c0e',s:2});
  if(this.hp<=0){this.die();return;}
  this.state='stagger';this.t=.28;
 }
 die(){this.dead=true;this.hittable=false;this.solid=false;this.state='dead';G.stats.sanity=Math.max(0,G.stats.sanity-7);G.stats.hum=Math.min(100,G.stats.hum+3);G.flags.kills=(G.flags.kills||0)+1;
  Snd.play('thud');G.shake=5;if(this.flag)G.flags[this.flag]=1;
  if(this.drop){const d=this.drop;G.map.ents.push(new Pickup(this.x+6,this.y+2,d.item,d.n||1,{flag:d.flag}));}
  Story.onKill&&Story.onKill(this);}
 draw(c,ox,oy){
  if(G.lull&&!G._truthPass&&!this.dead)return;
  const truth=G._truthPass||((G.truthNow||this.forceTruth)&&!G.lull);
  if(this.dead){if(truth){drawHum(c,this.truth,0,'lie',0,{dead:1},q(this.x-12)-ox,q(this.y-10)-oy);}
   else{c.fillStyle='#060708';c.fillRect((q(this.x-10)-ox),(q(this.y-5)-oy),20,5);c.fillRect((q(this.x-6)-ox),(q(this.y-7)-oy),10,3);c.fillStyle='#1a1d22';c.fillRect((q(this.x-9)-ox),(q(this.y-5)-oy),6,1);}return;}
  if(truth){const pose=this.state==='lunge'||this.state==='wind'?'swing':(this.moving?'walk':'idle');drawHum(c,this.truth,this.dir,pose,this.moving?((this.anim|0)%4)+1:0,{weapon:'pipe'},q(this.x-8)-ox,q(this.y-24)-oy);return;}
  const lunge=this.state==='lunge'||this.state==='wind';const f=lunge?4+((this.jit*20|0)%2):((this.jit*(this.state==='chase'?14:6))|0)%4;
  const sx=this.state==='wind'?rand(-1,1):0;
  drawHollowImg(c,f,q(this.x-10)-ox+sx,q(this.y-29)-oy,this.dir===2);
  if(this.flash>0){c.globalCompositeOperation='lighter';c.globalAlpha=.6;drawHollowImg(c,f,q(this.x-10)-ox,q(this.y-29)-oy,this.dir===2);c.globalAlpha=1;c.globalCompositeOperation='source-over';}
 }
}
// ================= PICKUPS =================
class Pickup extends Actor{
 constructor(x,y,item,n=1,o={}){super(x,y,o);this.kind='pickup';this.item=item;this.n=n;this.solid=false;this.t=rand(5);
  this.interact={label:'Take '+ITEMS[item].name.toLowerCase(),fn:()=>takePickup(this)};}
 update(dt){this.t+=dt;}
 draw(c,ox,oy){const b=Math.sin(this.t*3)*1;c.globalAlpha=.9;c.drawImage(ICONC[ITEMS[this.item].icon],(q(this.x-8)-ox),(q(this.y-14)-oy+b));c.globalAlpha=1;
  if((this.t%2.4)<.25){c.fillStyle='rgba(255,240,200,.9)';c.fillRect((q(this.x)-ox+3),(q(this.y-12)-oy),1,1);c.fillRect((q(this.x)-ox+2),(q(this.y-11)-oy),3,1);c.fillRect((q(this.x)-ox+3),(q(this.y-10)-oy),1,1);}}
}
function takePickup(pk){if(!giveItem(pk.item,pk.n))return;if(pk.flag)G.flags[pk.flag]=1;pk.gone=true;G.map.ents=G.map.ents.filter(e=>e!==pk);Snd.play('pickup');
 if(pk.onTake)pk.onTake();}
// ================= INVENTORY =================
const INV_MAX=10;
function hasItem(id){return G.inv.some(s=>s.id===id);}
function countItem(id){const s=G.inv.find(s=>s.id===id);return s?s.n:0;}
function giveItem(id,n=1,quiet){
 const s=G.inv.find(s=>s.id===id);
 if(s&&!ITEMS[id].weapon&&!ITEMS[id].key)s.n+=n;
 else if(!s){if(G.inv.length>=INV_MAX){murmur('Your bag is full.');return false;}G.inv.push({id,n});}
 if(!quiet)toast((n>1?n+' × ':'')+ITEMS[id].name);
 if(ITEMS[id].weapon&&!G.equip){G.equip=id;}
 if(ITEMS[id].clue)G.flags['clue_'+ITEMS[id].clue]=1;
 UI.hotbar();return true;}
function takeItem(id,n=1){const s=G.inv.find(s=>s.id===id);if(!s)return;s.n-=n;if(s.n<=0){G.inv=G.inv.filter(q=>q!==s);if(G.equip===id)G.equip=null;}UI.hotbar();}
function useItem(id){
 const it=ITEMS[id];if(!it)return;
 if(it.weapon){G.equip=G.equip===id?null:id;Snd.play('ui');toast(G.equip?'Equipped: '+it.name:'Put away: '+it.name);UI.hotbar();return;}
 if(id==='notebook'){UI.notebook();return;}
 if(id==='torch'){if(G.modal==='inv')UI.closeModal();if(P.battery>0){P.torch=!P.torch;Snd.play('torch');}else murmur('The torch is dead. You need batteries.');return;}
 if(!it.use){murmur(it.desc);return;}
 const u=it.use,s=G.stats;
 if(u.battery){if(!hasItem('torch')){murmur('You don’t have anything to put these in.');return;}P.battery=Math.min(100,P.battery+u.battery);}
 if(u.health)s.health=Math.min(100,s.health+u.health);
 if(u.hunger)s.hunger=clamp(s.hunger+u.hunger,0,100);
 if(u.thirst)s.thirst=clamp(s.thirst+u.thirst,0,100);
 if(u.sanity)s.sanity=Math.min(100,s.sanity+u.sanity);
 Snd.play(it.sfx||'pickup');takeItem(id,1);
}
