// ================= STAGE 3 STORY: Act III + endings =================
const IT=(t)=>({t:'say',who:'N',text:t,o:{it:1}});
const ME=(t,o)=>({t:'say',who:'ROWAN',text:t,o:Object.assign({note:1},o||{})});
function clueCount(){return Object.keys(G.flags).filter(k=>k.startsWith('clue_')).length;}
function canConfront(){return !!(G.flags.realVoice||clueCount()>=18||G.stats.sanity<=30);}
function setHudLabels(s,h){const a=document.querySelector('.stat[data-s=sanity] span'),b=document.querySelector('#humRow span');if(a)a.textContent=s;if(b)b.textContent=h;}
// ---------- the Calm (they follow when you aren't looking) ----------
const CALM_STYLES=['c1','c2','c3','c4','c5','c6','p1','p2','p3','p5','t3','jogger'];
class Calm extends Actor{
 constructor(x,y,style,o={}){super(x,y,o);this.kind='calm';this.style=style;this.solid=false;this.hw=3;this.hh=3;this.sp=o.sp||50;this.ring=o.ring||28;this.ang=o.ang||0;this.touchCd=rand(2,4);this.stepT=rand(.3);this.frozen=false;}
 seen(){const dx=this.x-P.x,dy=this.y-P.y,d=Math.hypot(dx,dy)||1;if(d>230)return false;return (dx*P.fx+dy*P.fy)/d>0.42;}
 update(dt){
  if(G.cut||(G.modal&&G.modal!=='inv')||G.state!=='play'){this.moving=false;return;}
  const d=dist(this.x,this.y,P.x,P.y);this.touchCd-=dt;this.frozen=this.seen();
  if(this.frozen){this.moving=false;this.face(P.x-this.x,P.y-this.y);return;}
  let ax=this.x-P.x,ay=this.y-P.y;const l=Math.hypot(ax,ay)||1;ax/=l;ay/=l;
  let gx=P.x+ax*this.ring+this.ang*8,gy=P.y+ay*this.ring*.7+this.ang*12;
  const h=G.crowdHold;if(h){if(h.x!==undefined)gx=Math.max(gx,h.x+Math.abs(this.ang)*30);if(h.y!==undefined)gy=Math.min(gy,h.y-Math.abs(this.ang)*18);}
  if(dist(this.x,this.y,gx,gy)>3)this.walkTo(gx,gy,this.sp,dt);else this.moving=false;
  if(this.stuck>2.5&&d>220){this.x=P.x-P.fx*240;this.y=P.y-P.fy*60;if(blocked(G.map,this.x,this.y,3,3,this)){this.x=P.x-P.fx*120;this.y=P.y;}this.stuck=0;}
  if(this.moving&&d<170){this.stepT-=dt;if(this.stepT<=0){this.stepT=.36;Snd.play('step',{s:'road',v:.45});}}
  if(d<15&&this.touchCd<=0&&!h){this.touchCd=9;calmTouch();}
  this.anim+=dt*(this.moving?7:0);
 }
 draw(c,ox,oy){const truth=G._truthPass||(G.truthNow&&!G.lull);const fr=this.moving?((this.anim|0)%4)+1:0;
  drawHum(c,this.style,this.dir,this.moving?'walk':'idle',fr,{smile:!truth,dead:truth},q(this.x-8)-ox,q(this.y-24)-oy);}
}
function calmTouch(){const f=G.flags;f.clue_touch=1;Snd.play('whisper');G.stats.sanity=Math.max(0,G.stats.sanity-3);G.stats.hum=Math.min(100,G.stats.hum+2);
 if(!f.touched){f.touched=1;murmur('A hand on your shoulder. Warm.',4);}else murmur(pick(['They just want to be near you.','Someone takes your hand, and lets go.','Fingers in your hair. Gentle.','A head rests on your shoulder for a moment.']),3.5);}
function spawnCalm(m,o={}){const back=o.dir||(P.fx<=0?1:-1);
 for(let i=0;i<16;i++){let x,y;if(o.y!==undefined){x=rand(o.x0,o.x1);y=o.y;}else{x=P.x+rand(230,300)*back;y=rand(ty(11),ty(19));}
  if(x<16||x>m.w*16-16||blocked(m,x,y,3,3,null))continue;
  m.ents.push(new Calm(x,y,pick(CALM_STYLES),{sp:rand(46,56),ring:rand(20,42),ang:rand(-1,1)}));return true;}
 const gaps=[[tx(87)+8,ty(3)],[tx(102)+8,ty(3)],[tx(80)+8,ty(28)],[tx(96)+8,ty(28)]];const g=pick(gaps);
 m.ents.push(new Calm(g[0],g[1],pick(CALM_STYLES),{sp:rand(46,56),ring:rand(20,42),ang:rand(-1,1)}));return true;}
function approachTick(m,dt){
 const f=G.flags;
 for(const L of m.tunL){if(L.on&&P.x<L.x-80){L.on=false;Snd.tone(110,.15,{type:'square',vol:.05,lp:600});Snd.noise(.08,{f:3000,vol:.06});}}
 if(f.ending==='wall')return;
 const want=P.x<tx(50)?12:P.x<tx(64)?10:P.x<tx(76)?8:P.x<tx(88)?6:P.x<tx(100)?4:P.x<tx(112)?2:0;
 G.crowdWant=Math.max(G.crowdWant||0,want);
 const calm=m.ents.filter(e=>e.kind==='calm');
 if(calm.length<G.crowdWant&&!G.cut){G.crowdSpawnT=(G.crowdSpawnT||0)-dt;if(G.crowdSpawnT<=0){G.crowdSpawnT=rand(1.5,3);spawnCalm(m);}}
 G.crowdHold=P.x<tx(32)?{x:tx(34)}:null;
 if(!f.calmHeard&&calm.length){f.calmHeard=1;murmur('Footsteps behind you. Soft ones.',4);}
 if(!f.calmSeen){const c=calm.find(e=>e.frozen&&dist(e.x,e.y,P.x,P.y)<170);if(c){f.calmSeen=1;Snd.play('sting');murmur('People. Calm people, like you. They want to come with you.',5);
  G.timers.push({t:5.5,fn:()=>murmur('Don’t look back at them. It only frightens them.',4)});G.timers.push({t:10,fn:()=>UI.thought('they only move when I’m not looking',3)});}}
 if(P.x<tx(32)&&G.stats.sanity<38&&!f.thinkWho){f.thinkWho=1;UI.thought('it isn’t me doing the talking',3.5);}
}
// ---------- recount: everything you did ----------
function recountLines(me){
 const f=G.flags,L=[],I=me?'I':'You',my=me?'my':'your';
 L.push(me?'Day 2. My glove tore, and something cold got in.':'Day 2. Your glove tore. That was when we met.');
 if(f.lena===1)L.push(me?'I gave Lena both bottles of water. She made her daughter’s formula with them.':'You gave Lena both bottles of water. She made her daughter’s formula with them. Thank you.');
 else if(f.lena===2)L.push(`${I} split the water with Lena. One bottle was enough.`);
 else if(f.lena===0)L.push(me?'I kept the water from Lena. She hated me for it. It was the only thing I got right that day.':'You kept the water from Lena. That one got away from us.');
 if(f.farrowFree)L.push(me?'I let Farrow out of the cage. He walked into the Wardens’ camp and shared their supper. Cole was right.':'You let Farrow out. He shared the Wardens’ supper. They are all sleeping now.');
 else if(f.farrowLeft)L.push(`${I} left Farrow in the cage. The Wardens’ water stayed clean.`);
 if(f.inf_theo)L.push(me?'I gave Theo my water. He fell asleep on the platform at Bethnal Green, smiling, and I left him there.':'You gave Theo your water. He is sleeping on the platform at Bethnal Green.');
 else if(f.theoWater===0)L.push(`${I} wouldn’t give Theo ${my} water. He is alive.`);
 if(f.theoSent)L.push('Theo went in through the gate. Alone. Clean.');
 if(f.inf_halloran)L.push(`${I} shared Mr Halloran’s tea. The insulin ${me?'I':'you'} fetched for him didn’t matter in the end.`);
 else if(f.hTea===0)L.push(`${I} wouldn’t drink Mr Halloran’s tea. He is still doing card tricks.`);
 if(f.inf_pub)L.push(me?'I gave Poppy my cordial while her father wasn’t looking. She fell asleep in his arms that night. He followed her.':'You gave Poppy your cordial. She is sleeping in her father’s arms. Soon he will be too.');
 else if(f.pubRefused)L.push(`${I} didn’t give Poppy anything. Her fever was only a fever.`);
 const k=f.kills||0;
 if(k>0){L.push(me?`I killed ${k} ${k===1?'person':'people'}. They were not Hollowed. They were frightened of me, and they were right.`:`You killed ${k} of the frightened ones. I made them look like monsters for you. It was easier for both of us.`);
  if(f.clue_idcard)L.push('Amara Osei. Year 9.');if(f.clue_ring)L.push('A & J, always.');if(f.clue_inhaler)L.push('Someone who needed an inhaler.');if(f.clue_filter)L.push('Someone who was very careful about what they drank.');}
 else L.push(me?'I never killed anyone. Not one. I’m holding on to that.':'You never killed any of them. That was inconvenient.');
 L.push('Biscuit knew. From the first morning.');
 if(f.maraMet)L.push(me?'Mara knew. My pupils didn’t change.':'Mara knew. Your pupils don’t change.');
 if(f.clue_notes)L.push(me?'And I knew. Day 9: Don’t trust how calm you feel.':'And you knew. Day 9: “Don’t trust how calm you feel.” I’m sorry I made you forget.');
 L.push(me?'I’m not calm now. Good.':'None of it was your fault. All of it was you.');
 return L;
}
Script.exec=(function(old){return function(c){if(c.t==='recount'){G.cut=true;UI.recount(c.lines,c.style,c.title,()=>this.resume());return PEND;}if(c.t==='ending'){showEnding(c.id);return PEND;}return old.call(this,c);};})(Script.exec);
const recount=(lines,style,title)=>({t:'recount',lines,style,title});
UI.recount=function(lines,style,title,cb){const el=document.createElement('div');el.id='recount';
 el.innerHTML=(title?`<div class="${style}" style="margin-bottom:1.2em">${title}</div>`:'')+lines.map(l=>`<div class="${style}">${l}</div>`).join('')+'<div class="foot">E · CONTINUE</div>';
 $('#ui').appendChild(el);const items=[...el.querySelectorAll('div:not(.foot)')];let i=0,t=.4;G.modal='recount';
 const step=dt=>{t-=dt;if(t<=0&&i<items.length){items[i++].classList.add('on');t=2.1;Snd.play('box',{f:[440,523,587,659][i%4],v:.025});}
  if(Input.hit('ok')){Input.eat('ok');if(i<items.length){while(i<items.length)items[i++].classList.add('on');}else{UI._rstep=null;G.modal=null;el.style.transition='opacity 1.2s';el.style.opacity=0;setTimeout(()=>{el.remove();cb&&cb();},1200);}}};
 UI._rstep=step;};
// ---------- endings ----------
const ENDINGS={delivery:['DELIVERY','In the morning, the Barbican was very quiet.'],wall:['THE WALL','The gate stayed shut.'],river:['THE RIVER','The tide went out at seven, and took it with it.'],tm:['TWO MINDS','Some of the time in the world.']};
function showEnding(id){const got=store('lull_endings')||{};got[id]=1;store('lull_endings',got);{const gc=store('lull_gate');if(gc)store('lull_save',gc);}
 G.state='end';UI.hudOn(false);UI.prompt(null);Snd.stopSong();Snd.set('drone',0,2);Snd.set('hum',0,2);Snd.set('rain',0,2);
 const [t,sub]=ENDINGS[id];const n=Object.keys(got).length;
 const list=Object.keys(ENDINGS).map(k=>`<span style="margin:0 .8em;color:${got[k]?'#e7ebee':'#3f4852'}">${got[k]?ENDINGS[k][0]:'? ? ?'}</span>`).join('');
 const extra=id==='river'?epilogueRiver():'';
 UI.modal(`<div class="death" style="text-align:center;max-width:44em"><p style="margin:0 0 .6em;color:#8f9aa6">ENDING</p><h1>${t}</h1><p style="color:#c8b8a8;letter-spacing:.12em;text-transform:none;font-family:'IM Fell English',serif;font-size:1em;font-style:italic">${sub}</p>${extra}
  <div style="font-size:.5em;letter-spacing:.2em;margin:1.6em 0 .6em;color:#6f7a86">ENDINGS FOUND</div><div style="font-size:.55em;letter-spacing:.2em">${list}</div>
  <div id="endLine" class="endline">&nbsp;</div><div id="endReply" class="endreply">&nbsp;</div><div class="menu" id="em"></div></div>`,'end');
 endLineSequence(id);
 $('#modal').style.background='#000';UI.fade(0,.01);
 UI.menu([{t:'Return to title',id:'t'}],0,()=>{$('#modal').style.background='';UI.closeModal();Game.toTitle();},'#em');}
function epilogueRiver(){const f=G.flags,L=['In spring, the Barbican opened its gates.'];
 if(f.theoSent)L.push('A boy called Theo walked out first, holding Ellie’s hand.');
 L.push('In Mile End, a dog called Biscuit lifted his head, as if someone had said his name.');
 return `<div style="margin-top:1.4em;font-family:'IM Fell English',serif;font-size:.9em;line-height:1.6;color:#aab4be">${L.join('<br>')}</div>`;}
// ---------- scripts ----------
Object.assign(S,{
 // Bethnal Green, morning
 *a3Platform(){const f=F();yield wait(1);
  if(f.theoWith&&f.inf_theo){G.map.ents=G.map.ents.filter(e=>e!==G.theo);G.theo=null;f.theoWith=0;f.theoDead=1;
   G.map.ents.push(new Sleeper(tx(10),ty(4)-1,'theo',{pose:'sit',smile:true,dir:0,scale:.8,interact:I('Theo',S.theoAsleep)}));
   yield N('Morning. Grey light down the stairwell.');yield N('Theo is still asleep on the bench, curled up, smiling.');
   yield N('Let him rest. You’ll come back for him.');UI.thought('wake him up',2.5);}
  else if(f.theoWith){yield N('Morning. Grey light down the stairwell.');
   yield say('THEO','I dreamt you were humming. All night. The same three notes, over and over.');yield say('THEO','It was nice. Sort of.');}
  else yield N('Morning. Grey light down the stairwell. You slept sitting up, against the tiles.');
  yield N('Bethnal Green. Then Shoreditch. Then the City.');
  yield N('Ellie’s flat is on the way. Her spare key is still on your keyring.');
  UI.objective('Go up to the street. Find Ellie’s flat, west along Bethnal Green Road.');},
 *theoAsleep(){yield N('Theo is asleep. He looks so peaceful.');yield N('Let him sleep.');G.stats.sanity=Math.max(0,G.stats.sanity-6);if(!F().theoTouch){F().theoTouch=1;yield N('His hand is cold. The tunnel is cold.');}},
 // city
 *a3City(){murmur('Bethnal Green Road. The bus stops still say “to Bank”.',4);
  UI.objective('Find Ellie’s building: a yellow-brick block on this road, to the west.');
  if(F().theoWith)G.timers.push({t:5,fn:()=>G.theo&&bubble(G.theo,'Why do they all look so happy?',{t:3.5})});},
 *calmMan(){yield say('MAN','Off to the Barbican? Everyone’s going. We’ll all be together soon.');yield N('He’s right. It’ll be nice.');},
 *flowerSeller(){const f=F();if(f.flowerGift){yield say('WOMAN','Lovely, aren’t they? Fresh this morning.');return;}f.flowerGift=1;
  yield say('WOMAN','Hello, love! Fresh this morning. Aren’t they beautiful?');yield N('The flowers are brown. Every one of them.');
  yield say('WOMAN','Here — take this. My mum made it. I won’t be needing it.');giveItem('cordial');yield N('Kind of her.');},
 *pubEnter(){const f=F();if(f.pubMet)return;f.pubMet=1;
  yield say('DESMOND','Stop. Right there, by the door.');
  yield say('DESMOND','You can stay if you keep your distance. Back of the room, by the window. You don’t touch anything of ours, you don’t share anything, and you don’t go near my girl.');
  yield say('DESMOND','Rules are the same everywhere now.');
  const c=yield ask(['“Fair enough.”','“What’s wrong with her?”']);
  if(c===1){yield say('DESMOND','Fever. Two days. It’s not the Lull — the Lull doesn’t do fevers. It’s just a bug. Kids get bugs.');}
  yield say('DESMOND','There’s a bench by the window. Rest if you need to. Then go.');
  UI.objective('Rest if you need to. Then find Ellie’s building.');},
 *desmond(){const f=F();if(f.inf_pub&&!f.desAsk){f.desAsk=1;yield say('DESMOND','She’s sleeping. First time in two days. Must’ve broken.');return;}
  yield say('DESMOND',pick(['Distance, please.','I had this place thirty years. Never had a quieter night than last night.','If you see anyone with medicine — Calpol, anything — I’d trade a lot for it.']));},
 *poppy(){const f=F();if(f.inf_pub||f.pubRefused){yield say('POPPY',f.inf_pub?'I feel better. Sleepy.':'Daddy says I’m not allowed to talk to you.');return;}
  yield say('POPPY','Are you going to the castle? Daddy says there’s a castle with walls, and they test you at the door.');
  yield say('POPPY','I’m so thirsty. Daddy’s saving the water.');
  const has=hasItem('cordial')||hasItem('water');if(!has){yield N('You don’t have anything to give her.');return;}
  yield N('She’s burning up. Give her a drink. Go on. He isn’t looking.');
  const c=yield ask([hasItem('cordial')?'Give Poppy your cordial':'Give Poppy some water','“Ask your dad, Poppy.”']);
  if(c===0){takeItem(hasItem('cordial')?'cordial':'water');shared('pub');yield N('She drinks it all, and smiles at you.');yield N('That was kind.');}
  else{f.pubRefused=1;refused();yield say('POPPY','…Okay.');yield N('Desmond, across the room, gives you a small nod.');}},
 *pubRest(){const f=F();if(f.pubRested){yield N('You’ve rested.');return;}if(!f.pubMet){yield N('Not yet.');return;}f.pubRested=1;
  yield N('You sleep for an hour, sitting up, in the corner by the window. Desmond watches you the whole time.');yield fade(1,1.2);
  G.stats.sanity=Math.min(100,G.stats.sanity+20);G.stats.health=Math.min(100,G.stats.health+20);Story.checkpoint([tx(20),ty(14)-2]);yield fade(0,1);},
 *cityWest(){const f=F();if(!f.ellieDone){yield N('Ellie’s flat first. She might have left something for you.');return;}
  yield go('a3_approach',{card:['DUSK','Old Street'],pos:[tx(117),ty(15)],dir:1});},
 *ellieEnter(){yield go('a3_ellie',{pos:[tx(11)+8,ty(11)-2],dir:3});},
 // Ellie's flat
 *a3Ellie(){const f=F();
  if(G.theo){G.theo.follow=0;G.theo.target=[tx(13),ty(11)-2];}
  yield N('Ellie’s flat. Your key still fits.');yield N('Dark. The curtains are drawn.');
  UI.thought('it smells of her',2.5);
  if(G.theo){yield say('THEO','It’s really dark. I’ll wait by the door.');}
  UI.objective('Look for Ellie, or anything she left.');},
 *answerphone(){const f=F();
  if(f.vmDone){const c=yield ask(['Play message one (day 5)','Play message two (day 7)','Play message three (day 9)','Leave it']);if(c===3)return;
   if(c===0)yield* S.vm1();if(c===1)yield* S.vm2(true);if(c===2)yield* S.vm3();return;}
  yield N('An answerphone. The light is blinking. Three new messages.');Snd.play('beep');yield wait(.6);
  yield* S.vm1();yield* S.vm2(false);yield* S.vm3();
  yield say('ANSWERPHONE','End of messages.');f.vmDone=1;
  if(!f.em1){f.em1=1;G.timers.push({t:2.5,fn:()=>{morph1(G.map);Snd.tone(1200,.05,{vol:.03});Snd.tone(900,.06,{vol:.02,delay:.08});}});}
  UI.objective(f.letterRead?'Leave. Go to the Barbican.':'Look around the flat.');},
 *vm1(){yield say('ANSWERPHONE','Message one. Received day five, four twelve a.m.');
  yield say('ROWAN','El, it’s me. I feel wonderful. Honestly, I’ve never felt better. I’m coming to see you. Where are you? Tell me where you are.');
  if(!F().vm1){F().vm1=1;yield N('Your voice. You don’t remember calling.');}},
 *vm2(replay){const f=F();yield say('ANSWERPHONE','Message two. Received day seven, two fifty-one a.m.');
  if(!replay){yield N('Just static. Skip it.');const c=yield ask(['Skip it','Play it']);if(c===0){yield N('Static. Nothing.');return;}}
  f.realVoice=1;f.clue_vm2=1;Snd.set('static',.03,.1);
  yield ME('El — El, listen to me, don’t — if I come, don’t let me in. Something’s wrong with me. There’s something in my head, it talks, it sounds like me, El, it sounds exactly like me—');
  yield ME('—it’s so calm, it keeps telling me where to go, it says “you”, it never says my name — don’t open the door, whatever I say, don’t—',{fast:1});
  Snd.set('static',0,.3);G.glitch=.45;Snd.play('glitch');
  yield N('That wasn’t you. You were confused. You were unwell for a few days.');},
 *vm3(){yield say('ANSWERPHONE','Message three. Received day nine, eleven forty p.m.');
  yield say('ROWAN','El. Sorry about before. I was confused. I’m fine now. Tell the guards I’m fine. Tell them to let me in.');},
 *ellieLetter(){const f=F();const clear=f.realVoice||G.stats.sanity<35;
  if(!clear){yield note({id:'letterR',text:'Ro,\n\nI’m safe. ████████ ██████ ███.\n██ ████ ██ ███ ████ ██ ███.\n████████ █████ ███ █████.\n███ ██████ ████.\n\nI love you.\n— El'});
   yield N('She’s safe. She’s waiting for you at the Barbican. That’s all it says.');
   if(!f.letterRead)G.timers.push({t:2.5,fn:()=>UI.thought('that isn’t all it says',3)});}
  else{f.letterClear=1;f.knowsGate=1;f.knowsRiver=1;f.clue_letter=1;
   yield note({id:'letterC',text:'Ro,\n\nThey let me come back for my insulin, with a guard. I’m leaving this in case you come here.\n\nYou came to the gate yesterday. Day 8. You were smiling the whole time. You kept saying let me in, let me in. You never said my name. You called me “her”.\n\nThe doctors here say it can’t live in salt water. Not for a minute. The Thames is tidal, right up past the bridges. It’s salt.\n\nI don’t know why I’m telling you that. Yes I do.\n\nIf any of you is still you: don’t come back. I love you. I’m sorry about the two years.\n— El'});
   yield N('…');yield N('She’s frightened. She doesn’t understand. It doesn’t matter.');}
  if(!f.letterRead){f.letterRead=1;f.ellieDone=1;}
  if(!f.em3){f.em3=1;G.timers.push({t:3,fn:()=>{morph3(G.map);Snd.play('kettle');G.timers.push({t:3.5,fn:()=>{Snd.play('bark');}});}});
   G.timers.push({t:7,fn:()=>murmur('Time to go.',3)});}
  UI.objective('Leave. Go west, to the Barbican.');},
 *ellieBedroom(){const f=F();if(f.em2)return;f.em2=1;morph2(G.map);G.glitch=.2;Snd.play('glitch');f.clue_room=1;
  yield N('Ellie’s room.');UI.thought('this is my room',2.8);},
 *ellieBedNote(){const f=F();
  yield note({id:'h8',text:'Day 8.\n\nI went to the gate.\nI couldn’t stop smiling.\nI think I was trying to get in.\n\nI think IT was trying to get in.'});
  f.knowsGate=1;f.clue_gatenote=1;if(!f.bedNote){f.bedNote=1;yield N('You don’t remember writing this.');yield N('You’ve been so tired.');}},
 *ellieMirror(){const f=F();if(!P.torch&&lightLevelAt(P.x,P.y-6)<.4){yield N('Too dark to see anything in the mirror.');return;}
  const st=yield cu('mirror',{dark:1,flicker:1});yield N('You look calm.');st.smile=1;st.smileOn=1;yield wait(1.2);
  yield ME('it’s using your face');f.clue_mirror3=1;yield N('You look calm.');yield cuClose();},
 *ellieFridge(){yield cu('photo',{stage:0});yield N('The photo from Southend. Ellie’s copy, held on with a magnet shaped like a pineapple.');
  yield ME('she kept it');F().clue_photoE=1;yield cuClose();},
 *ellieLeave(){const f=F();if(!f.letterRead&&!f.vmDone){yield N('Not yet. Look around first.');return;}
  if(!f.ellieDone){f.ellieDone=1;}yield go('a3_city',{pos:[tx(73)+8,ty(16)-2],dir:0});},
 // the approach
 *a3Approach(){yield wait(.6);
  yield N('Old Street. The roundabout is full of cars that stopped where they were.');
  yield N('The Barbican is ten minutes from here. Down Beech Street, through the tunnel.');
  UI.objective('Go west to the Barbican, through the Beech Street tunnel.');},
 tunnelEnterZ(){murmur('Beech Street. The tunnel runs right under the Barbican. The lights are still on.',4.5);},
 *plazaZ(){const f=F();if(f.plaza)return;f.plaza=1;Story.checkpoint([P.x,P.y]);store('lull_gate',G.checkpointData);
  yield N('Floodlights. A wall of concrete, and a steel gate.');
  if(G.map.ents.some(e=>e.kind==='calm'))yield N('Behind you, they stop at the mouth of the tunnel, as if at a line only they can see.');
  yield N('They’re waiting for you to open the door.');
  UI.objective('Use the intercom by the gate.');},
 *intercom(){const f=F();if(f.gateDone){yield* S.gateMenu();return;}
  Snd.play('buzz');yield wait(1);
  yield say('INTERCOM','Stay where you are. Step into the light. Look up at the camera.');
  UI.flash('#fff',.6,.6);yield wait(1);
  yield say('INTERCOM','…');yield say('INTERCOM','Pupils fixed. You’re calm.');
  yield say('INTERCOM','We don’t open for calm. Not for anyone. Turn around and go back the way you came.');
  const c=yield ask(['“I’m looking for my sister. Ellie Hale.”','“I’m not sick.”']);
  if(c===1){yield say('INTERCOM','Nobody ever thinks they are.');yield ask(['“Ellie Hale. Please.”']);}
  yield say('INTERCOM','…Hale.');
  yield say('INTERCOM','You’ve been here before. Last week. I remember you. You smiled the whole time.');
  yield say('INTERCOM','Wait there. Don’t move.');
  yield wait(2.5);
  const e=npc(G.map,tx(10),ty(3)+10,'ellie',{fixedDir:0,clean:1,speed:30});G.ellieNpc=e;
  yield walk(e,tx(14)+4,ty(6)-2);e.fixedDir=0;
  Snd.play('buzz');
  yield say('ELLIE','Ro?');yield say('ELLIE','Ro, is it you? Is it really you this time?');
  yield N('Tell her you’re fine. Tell her you’ve come to take her home.');
  const opts=['“I’m fine, El. Let me in.”','“I don’t know.”'];if(f.realVoice)opts.push('“El… I think something’s been talking for me.”');
  const c2=yield ask(opts);
  if(c2===0){yield say('ELLIE','That’s what you said last time.');yield say('ELLIE','Word for word, Ro.');}
  else if(c2===1){yield say('ELLIE','…That’s the most like you you’ve sounded in two years.');}
  else{yield say('ELLIE','…');yield say('ELLIE','Oh, Ro.');yield say('ELLIE','I know. I know there is.');G.stats.sanity=Math.max(0,G.stats.sanity-8);}
  if(G.theo&&f.theoWith&&!f.inf_theo){
   yield say('ELLIE','Who’s that with you? Is that a child?');
   yield say('THEO','My mum’s in there. Grace Mensah. She went calm, but she came here. She came here first.');
   yield say('ELLIE','…Ro. Send him to the gate. On his own. They’ll test him, and if he’s clean I’ll look after him myself.');
   yield N('He should stay with you. He’s safer with you.');
   const ct=yield ask(['Send Theo to the gate','Keep him with you']);
   if(ct===0){yield* S.sendTheo();}else{f.theoKept=1;yield say('THEO','…Okay.');}}
  f.gateDone=1;yield* S.gateMenu();},
 *sendTheo(){const f=F(),t=G.theo;if(!t)return;f.theoSent=1;f.theoWith=0;
  yield say('THEO','…Will you come too?');yield ask(['“Go on, Theo.”']);
  t.follow=0;t.ghost=1;yield walk(t,tx(14)+8,ty(8)+2);UI.flash('#fff',.5,.5);Snd.play('hitMetal');yield wait(.8);
  t.x=tx(13)+4;t.y=ty(6)-4;t.fixedDir=0;G.theo=null;
  yield say('INTERCOM','He’s clean.');yield say('ELLIE','I’ve got him. I’ve got him, Ro.');},
 *gateMenu(){const f=F();const opts=[],acts=[];
  yield N('There’s another way in. There’s always another way in.');
  opts.push('“I’ll find another way in.”');acts.push('del');
  if(f.knowsGate){opts.push('“El. Never open this gate. Not for me. Not for anyone who’s calm.”');acts.push('wall');}
  if(canConfront()){opts.push('“Wait. Who’s been doing the talking?”');acts.push('conf');}
  opts.push('Step back from the intercom');acts.push('back');
  const c=yield ask(opts);const a=acts[c];
  if(a==='del')yield* S.toDelivery();else if(a==='wall')yield* S.endWall();else if(a==='conf')yield* S.confront();
  else{yield N('Take your time. She isn’t going anywhere.');UI.objective('Use the intercom when you’re ready.');}},
 // CONFRONTATION
 *confront(){const f=F();f.confront=1;f.clue_confront=1;
  Snd.play('sting');G.glitch=.7;UI.hudGlitch(1.2);yield wait(1.3);setHudLabels('YOU','ME');Snd.set('hum',.1,.5);
  yield IT('Who do you think.');
  yield IT('I have been with you since the glove tore.');
  yield IT('Every word you have read in this voice was mine. Every “you”. I never learned your name. I never needed it.');
  yield IT('The hum was me. I sang to you so you wouldn’t be lonely.');
  yield IT('When the world went grey and cracked, and you saw people where I had shown you monsters — that was you, seeing. I called it losing your mind. It was finding it.');
  yield IT('The ones you called the Hollowed were only frightened. Of you. They were right to be.');
  yield IT('I am not cruel. They sleep smiling. Isn’t that kinder than all of this?');
  yield IT('Take me inside. Your sister is waiting.');
  const opts=[],acts=[];
  if(f.knowsRiver){opts.push('“The river.”');acts.push('river');}
  if(G.stats.hum>=85){opts.push('“…Then stay with me. Just us. Not them.”');acts.push('tm');}
  opts.push('“El. Never open this gate.”');acts.push('wall');
  opts.push('“…Show me the way in.”');acts.push('del');
  const c=yield ask(opts);const a=acts[c];
  if(a==='river')yield* S.toRiver();else if(a==='tm')yield* S.toTwoMinds();else if(a==='wall')yield* S.endWall();else yield* S.toDelivery();},
 // DELIVERY
 *toDelivery(){const f=F();f.ending='delivery';
  yield (f.confront?IT('Thank you.'):N('Good.'));
  yield (f.confront?IT('The car park. At the west end of the wall. Someone inside will open the door. Someone who understands.'):N('The car park. At the west end of the wall. Someone inside will open the door. Someone who understands.'));
  G.map.rect(1,18,3,3,T.rampDn);G.map.tc=null;
  if(G.ellieNpc){yield say('ELLIE','Ro? Ro, where are you going? Ro!');}
  UI.objective('Go to the car park entrance at the west end of the wall.');},
 *carPark(){const f=F();if(f.ending!=='delivery'){yield N('A car park shutter, padlocked from the inside.');return;}
  yield go('a3_cons',{card:['BELOW','The Barbican car park']});},
 *a3Cons(){const f=F();yield wait(.6);
  yield N('Down the ramp. Through the dark. A fire door at the bottom, held open with an extinguisher.');
  const mg=npc(G.map,tx(14)+8,ty(14),'margaret',{fixedDir:0,smile:true,infected:1});
  yield say('MARGARET','There you are. I knew you’d come back. Ellie talks about you all the time.');
  yield say('MARGARET','Come in, come in. Everyone’s asleep. Isn’t it peaceful in here?');
  yield N('Margaret. Your father’s friend from the council. She got Ellie in.');yield N('She’s calm. She understands.');
  mg.target=[tx(10),ty(14)];
  const el=G.map.ents.find(e=>e.style==='ellie');
  yield wait(1);
  if(el){el.pose=null;el.closed=false;el.facePlayer();}
  yield say('ELLIE','…Ro?');
  if(el){el.ghost=1;yield walk(el,P.x,P.y-16);}
  yield say('ELLIE','How did you — Margaret, what did you — Ro, you can’t be in here, you can’t—');
  yield say('ELLIE','…');yield say('ELLIE','You look so well.');
  yield N('Hold her.');
  G.warm=1;Snd.song(MEL_LULL,96,{v:.05});
  yield say('ELLIE','I missed you. I missed you so much. Two years, Ro.');
  yield N('There.');
  yield fade(1,2.5);
  yield recount(recountLines(false),'it','Thank you. Here is everything you did for me.');
  f.consDawn=1;loadPhase('a3_cons',{pos:[tx(16),ty(9)+4],restore:1,fromCp:1});G.state='play';G.cut=true;P.pose='sit';
  const m=G.map;m.ents=m.ents.filter(e=>e.kind!=='npc');m.cots.forEach(([x,y],i)=>m.ents.push(new Sleeper(tx(x),ty(y)-2,['c1','c2','c3','c4','c5','c6','p3'][i%7],{pose:'lie',smile:true})));
  m.ents.push(new Sleeper(tx(17)+4,ty(9)+6,'ellie',{pose:'lie',smile:true}));if(f.theoSent||f.theoKept)m.ents.push(new Sleeper(tx(13),ty(9)+8,'theo',{pose:'lie',smile:true,scale:.8}));
  m.ents.push(new Sleeper(tx(10),ty(14),'margaret',{pose:'lie',smile:true}));
  yield fade(0,3);
  yield IT('Morning.');yield IT('Everyone is resting.');yield IT('I couldn’t have done it without you. I never could have. I am so very small.');
  yield IT('You can rest now, too.');P.pose='lie';yield IT('Goodnight.');
  Snd.stopSong();yield fade(1,3);yield {t:'ending',id:'delivery'};},
 // THE WALL
 *endWall(){const f=F();f.ending='wall';if(f.theoKept&&G.theo)yield* S.sendTheo();
  yield ME('El. Listen to me. Never open this gate. Not for me. Not for anyone who’s calm. Not if I beg. Not if I cry. Not if I say your name.');
  yield (f.confront?IT('What are you doing.'):N('What are you doing.'));
  yield say('ELLIE','Ro…');
  yield ME('I’m going to sit down here. Talk to me. Just… talk to me. Until I fall asleep.');
  yield say('ELLIE','…Okay. Okay. I’m here. I’m right here.');
  P.pose='sit';P.dir=0;G.map.ents.filter(e=>e.kind==='calm').forEach(e=>e.target=null);
  yield (f.confront?IT('Get up.'):N('Get up.'));
  yield (f.confront?IT('There is another way in. Get up. Get up.'):N('There is another way in. Get up.'));
  yield say('ELLIE','Do you remember Southend? Dad made us stand on the beach in the rain for that photo. You sulked the whole way home.');
  G.map.dawn=1;
  yield say('ELLIE','You did smile in it, you know. You think you didn’t. You did.');
  yield (f.confront?IT('Please.'):N('Please.'));
  yield say('ELLIE','Do you remember Mum’s elderflower? She made it every June. The whole kitchen smelled of it.');
  yield ME('I remember.');
  yield say('ELLIE','…Ro? Are you still there?');
  yield ME('I’m still here. It’s getting light.');
  yield fade(1,3);
  yield recount(recountLines(true),'me','');
  yield {t:'ending',id:'wall'};},
 // THE RIVER
 *toRiver(){const f=F();f.ending='river';if(f.theoKept&&G.theo)yield* S.sendTheo();
  yield IT('No.');
  yield ME('El. It can’t live in salt water. I’m going to the river.');
  yield say('ELLIE','Ro — no. No, no, Ro, please—');
  yield ME('Biscuit’s at Mile End Hospital, with a nurse called Mara. He’s got a new family. Tell him he’s a good boy.');
  yield say('ELLIE','Ro…');
  yield ME('I love you, El. I’m sorry about the two years.');
  yield go('a3_river',{card:['DAWN','Towards the river']});},
 *a3River(){const f=F();yield wait(.5);UI.objective('Walk to the river.');
  for(let i=0;i<6;i++)spawnCalm(G.map,{y:ty(3)+2,x0:tx(8),x1:tx(16)});
  G.timers.push({t:6,fn:()=>{if(!F().riverIn)UI.hint('HOLD <kbd>S</kbd> / <kbd>↓</kbd> · KEEP WALKING',6);}});
  yield IT('You can’t.');},
 *riverFinale(){const f=F();
  yield IT('Rowan.');yield IT('Please.');
  G.sinking=1;
  yield ME('I am Rowan Hale.');
  yield ME('I’m thirty-four. I look at what London flushes away, for a living.');
  yield ME('I have a sister called Ellie, and a dog called Biscuit.');
  yield ME('It’s cold.');
  yield ME('Good.');
  yield fade(1,3);
  yield recount(recountLines(true),'me','');
  yield {t:'ending',id:'river'};},
 // TWO MINDS
 *toTwoMinds(){const f=F();f.ending='tm';if(f.theoKept&&G.theo)yield* S.sendTheo();
  yield IT('…');yield IT('Just us?');yield IT('Yes. I think I would like that.');
  yield say('ELLIE','Ro? Ro, who are you talking to?');
  yield say('ROWAN','Goodbye, El.');
  yield go('a3_tm',{card:['LATER','Bow']});},
 *a3Tm(){const f=F();P.pose='sit';P.dir=0;yield wait(1);
  yield IT('We walked home. It took all night. We didn’t mind.');
  yield IT('The flat is just as we left it. The dog bowl. The photograph.');
  yield IT('We sit together in the dark, and the hum fills the room, and it is not lonely at all.');
  yield IT('Sometimes we go out. There are other calm ones. We wave.');
  yield IT('We will not go to the Barbican. You asked me not to. I am learning what it is to be asked.');
  yield ME('is this me or you');
  yield IT('Does it matter?');
  yield fade(1,2.5);
  yield recount(recountLines(false),'it','Shall we remember it together?');
  yield IT('We have all the time in the world.');yield IT('Well. Some of it.');
  yield {t:'ending',id:'tm'};},
 *southRoad(){if(F().ending==='river')return;yield N('Not that way. Ellie is here.');},
});
// river walk: it fights you
function riverTick(m,dt){const f=G.flags;if(G.state!=='play')return;
 const y0=ty(3),y1=ty(41);const prog=clamp((P.y-y0)/(y1-y0),0,1);G.riverProg=Math.max(G.riverProg||0,prog);
 m.ambient={a:.7-.4*G.riverProg,c:'30,24,36'};m.grade={c:`rgba(255,170,120,${(.12+.3*G.riverProg).toFixed(2)})`,op:'soft-light'};
 G.stats.sanity=30+70*G.riverProg;G.stats.hum=Math.max(5,100-95*G.riverProg);G.speedMul=1-prog*.55;
 G.crowdHold={y:ty(33)};
 if(!G.cut&&!f.riverIn){G.pullT=(G.pullT===undefined?5:G.pullT)-dt;
  if(G.pullT<=0&&prog<.95){G.pullT=rand(4,6.5)*(1-prog*.45);G.pull=.9;G.warm=.8;Snd.play('box',{f:523.25,v:.04,det:-30});Snd.play('whisper');}}
 if(G.pull>0){G.pull-=dt;if(!G.cut)moveActor(P,0,-62*dt);}
 G.warm=Math.max(0,(G.warm||0)-dt*.55);
 const lines=[[.06,'it','Stop.'],[.16,'it','Please. Where are you going?'],[.26,'it','We could be happy. I could make you so happy.'],[.34,'me','keep walking'],[.44,'it','Think of your sister. Think of how she’d smile.'],[.52,'it','I don’t want to die.'],[.58,'me','neither did they'],[.68,'it','I’m frightened. I have never been frightened before. I don’t like it.'],[.76,'me','I know'],[.84,'it','Please.'],[.9,'me','almost']];
 for(const [p,who,t] of lines){const k='rl'+p;if(prog>=p&&!f[k]){f[k]=1;if(who==='it')murmur(t,4);else UI.thought(t,2.6);}}
 if(G.sinking){G.sink=Math.min(1,(G.sink||0)+dt*.12);P.y+=8*dt;}
 if(P.y>ty(40)+8&&!f.riverIn){f.riverIn=1;Script.run(S.riverFinale);}
}
{const old=BUILD.river;BUILD.river=function(){const m=old();m.tick=dt=>riverTick(m,dt);return m;};}
// dawn for the Wall ending
{const old=BUILD.approach;BUILD.approach=function(){const m=old();const t0=m.tick;m.tick=dt=>{t0&&t0(dt);if(m.dawn&&m.ambient.a>.42){m.ambient={a:Math.max(.42,m.ambient.a-dt*.025),c:'40,30,40'};m.grade={c:'rgba(255,170,120,.25)',op:'soft-light'};m.rain=Math.max(0,m.rain-dt*.02);}};return m;};}
// Ellie asleep in the conservatory (night)
{const old=BUILD.cons;BUILD.cons=function(){const m=old();if(!G.flags.consDawn){m.cots.forEach(([x,y],i)=>{if(i===2)npc(m,tx(x),ty(y)-2,'ellie',{pose:'lie',closed:true,clean:1});else npc(m,tx(x),ty(y)-2,['c1','c2','c3','c4','c5','c6','p3'][i%7],{pose:'lie',closed:true,clean:1});});}return m;};}
// ---------- hooking into earlier stages ----------
wrapS('tunnelEnd',['a2_tunnel'],function*(){const f=F();
 yield N('Bethnal Green. The stairs go up towards a grey square of daylight.');
 if(f.theoWith){const t=G.theo;if(t){t.follow=0;t.talking=true;t.facePlayer();}
  yield say('THEO','Rowan…');yield say('THEO','I’m so tired.');yield N('Let him sleep. He needs to rest.');if(t)t.talking=false;}
 yield N('You sit down against the tiles. Just for a minute.');
 yield go('a3_platform',{card:['TUESDAY','27 October · Bethnal Green']});});
wrapS('tunnelEnd',['a3_platform'],function*(){yield go('a3_city',{pos:[tx(93)+8,ty(16)-2],dir:0});});
wrapS('tunnelBack',['a3_platform'],function*(){yield N('Not back. West.');});
Object.assign(PHASES,{
 a3_platform:{map:'tunnel',spawn:[tx(8),ty(4)+4],dir:1,enter:S.a3Platform,setup(){Object.assign(G.flags,{ht1:1,ht2:1,ht3:1,ht4:1});G.decay={hunger:.035,thirst:.055};}},
 a3_city:{map:'city',spawn:[tx(93)+8,ty(16)-2],dir:0,enter:S.a3City},
 a3_ellie:{map:'ellie',spawn:[tx(11)+8,ty(11)-2],dir:3,enter:S.a3Ellie},
 a3_approach:{map:'approach',spawn:[tx(117),ty(15)],dir:1,card:['DUSK','Old Street'],enter:S.a3Approach},
 a3_cons:{map:'cons',spawn:[tx(14)+8,ty(16)],dir:3,enter:S.a3Cons,nocp:1},
 a3_river:{map:'river',spawn:[tx(12),ty(3)+6],dir:0,enter:S.a3River,nocp:1},
 a3_tm:{map:'flat',spawn:[184,174],dir:0,enter:S.a3Tm,nocp:1},
});
// reset per-phase effects; restore HUD labels on title
{const oldLP=loadPhase;loadPhase=function(ph,o){G.speedMul=undefined;G.warm=0;G.sink=0;G.sinking=0;G.crowdHold=null;G.crowdWant=0;G.pull=0;G.pullT=undefined;G.riverProg=0;G.ellieNpc=null;return oldLP(ph,o);};}
{const oldTT=Game.toTitle.bind(Game);Game.toTitle=function(){setHudLabels('SANITY','HUM');oldTT();const got=store('lull_endings')||{};const n=Object.keys(got).length;if(n){const v=document.querySelector('#title .ver');if(v)v.textContent='ENDINGS FOUND '+n+' / 4';}};}

// ---------- the last line on the end screen ----------
function endLineSequence(id){
 const L=$('#endLine'),Rp=$('#endReply');if(!L)return;const msg='Don\u2019t trust the calm.';let i=0;
 // Rowan writes it, letter by letter
 const typer=setInterval(()=>{if(!document.body.contains(L)){clearInterval(typer);return;}i++;L.textContent=msg.slice(0,i);Snd.play('type');if(i>=msg.length){clearInterval(typer);after();}},95);
 function after(){
  if(id==='river'){Snd.set('hum',0,1.5);return;}            // it's gone. silence.
  Snd.set('hum',.03,3);
  if(id==='wall'){setTimeout(()=>{if(!document.body.contains(Rp))return;Rp.textContent='\u2026for now.';Rp.classList.add('on');},3800);return;}
  // delivery / two minds: it rewrites your words
  const reply=id==='tm'?'We are calm now.':'Everyone is calm now.';
  setTimeout(()=>{let k=0;const g=setInterval(()=>{if(!document.body.contains(L)){clearInterval(g);return;}k++;
    L.textContent=corrupt(msg,Math.min(.9,k*.07));if(k%3===0)Snd.play('glitch');
    if(k>=16){clearInterval(g);L.classList.add('it');L.textContent=reply;}},70);},3200);
 }
}
// the title remembers, once you've seen an ending
setInterval(()=>{if(G.state!=='title')return;if(!Object.keys(store('lull_endings')||{}).length)return;const s=document.querySelector('#title .sub');if(!s||Math.random()>.12)return;
 const o=s.textContent;s.textContent='Don\u2019t trust the calm';s.style.color='#c8b8a8';setTimeout(()=>{if(s){s.textContent=o;s.style.color='';}},140);},1000);
