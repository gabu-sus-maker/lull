// ================= UI =================
const UI={dlg:null,cardT:0,
 layout(){const ww=innerWidth,wh=innerHeight;let w=ww,h=ww*9/16;if(h>wh){h=wh;w=wh*16/9;}const wr=$('#wrap');wr.style.width=w+'px';wr.style.height=h+'px';wr.style.left=((ww-w)/2)+'px';wr.style.top=((wh-h)/2)+'px';wr.style.fontSize=(w/92)+'px';this.scale=w/W;this.w=w;this.h=h;if(typeof setRes==='function')setRes();},
 show(id,on){$(id).classList.toggle('hidden',!on);},
 // ---------- HUD ----------
 hudOn(on){this.show('#hud',on);this.show('#hotbar',on);this.show('#objective',on&&!!G.objective);this.show('#torchInd',on&&hasItem('torch'));},
 hud(){
  const s=G.stats,L=G.lull;
  for(const k of['health','hunger','thirst','sanity']){const el=document.querySelector(`.stat[data-s=${k}]`);let v=s[k];
   if(L&&!L.truthHud)v=100;else if(L&&L.truthHud&&Math.random()<.5)v=s[k];
   if(L&&L.scramble&&Math.random()<L.scramble)v=rand(0,100);
   el.querySelector('i').style.width=v+'%';el.querySelector('b').style.width=v+'%';el.querySelector('em').textContent=(L&&L.scramble&&Math.random()<L.scramble)?pick(['--','??','██','00','99']):Math.round(v);
   el.classList.toggle('low',!L&&v<20&&(k!=='sanity'||G.sanityOn));}
  const sr=document.querySelector('.stat[data-s=sanity]');sr.style.opacity=G.sanityOn?1:.35;
  this.show('#humRow',G.showHum);
  if(G.showHum){const c=$('#humCv'),x=c.getContext('2d');x.clearRect(0,0,c.width,c.height);const lvl=clamp((s.hum+G.humNear*30)/100,0,1);const smooth=lvl;
   x.fillStyle='rgba(255,255,255,.06)';x.fillRect(0,5,c.width,1);
   x.fillStyle=L?'#f2d39b':'#b9c4cf';
   for(let i=0;i<c.width;i++){const t=G.time*3+i*.32;const a=(1.2+lvl*4.8);const n=(1-smooth)*Math.sin(t*3.7+Math.sin(i*1.3)*4)*.8;const y=6+Math.sin(t)*a*.7+n*a*.6;x.fillRect(i,Math.round(clamp(y,0,11)),1,1);}
   $('#humRow em').textContent='';}
  const st=$('#stam');st.style.opacity=P.stam<99?1:0;st.firstChild.style.width=P.stam+'%';
  const ti=$('#torchInd');if(hasItem('torch')&&G.state==='play'){ti.classList.remove('hidden');ti.classList.toggle('off',!P.torch);ti.innerHTML=`TORCH <span class="tb"><i style="width:${P.battery}%"></i></span>`;}else ti.classList.add('hidden');
 },
 stamFlash(){const st=$('#stam');st.style.opacity=1;st.animate([{background:'#c0443c'},{background:'rgba(255,255,255,.06)'}],{duration:400});},
 hudGlitch(d){const h=$('#hud');h.classList.add('glitch');const lb=[...document.querySelectorAll('.stat span')];const orig=lb.map(e=>e.textContent);lb.forEach(e=>e.textContent=corrupt(e.textContent,.4));setTimeout(()=>{h.classList.remove('glitch');lb.forEach((e,i)=>e.textContent=orig[i]);},d*1000);},
 hotbar(){const hb=$('#hotbar');hb.innerHTML='';for(let i=0;i<5;i++){const s=G.inv[i];const d=document.createElement('div');d.className='slot'+(s&&G.equip===s.id?' eq':'');d.innerHTML=`<span class="k">${i+1}</span>`+(s?`<img src="${ICON[ITEMS[s.id].icon]}"><span class="n">${s.n>1?s.n:''}</span>`:'');hb.appendChild(d);}},
 objective(t){G.objective=t;const o=$('#objective');if(!t){o.classList.add('hidden');return;}$('#objText').textContent=t;if(G.state==='play'&&G.hudVisible)o.classList.remove('hidden');o.classList.remove('flash');void o.offsetWidth;o.classList.add('flash');},
 hint(html,d=6){const h=$('#hint');h.innerHTML=html;h.classList.remove('hidden');h.style.opacity=1;clearTimeout(this._ht);this._ht=setTimeout(()=>{h.style.opacity=0;setTimeout(()=>h.classList.add('hidden'),700);},d*1000);},
 // ---------- prompt / bubbles ----------
 toScreen(x,y){const [ox,oy]=[G._ox||0,G._oy||0];return[(x-ox)*this.scale,(y-oy)*this.scale];},
 prompt(t){const p=$('#prompt');if(!t||G.cut||G.modal||G.state!=='play'){p.classList.add('hidden');return;}const [sx,sy]=this.toScreen(t.x,t.y-26);p.style.left=sx+'px';p.style.top=sy+'px';p.innerHTML=`<kbd>E</kbd>${t.label}`;p.classList.remove('hidden');},
 bubbles(){const host=$('#bubbles');for(const b of G.bubbles){if(!b.el){b.el=document.createElement('div');b.el.className='bub'+(b.shout?' shout':'');b.el.textContent=b.text;host.appendChild(b.el);}
   const e=b.ent;const [sx,sy]=this.toScreen(e.x,e.y-(e.kind==='dog'?16:30));b.el.style.left=sx+'px';b.el.style.top=sy+'px';b.el.style.opacity=b.t<.4?b.t/.4:1;}
  G.bubbles=G.bubbles.filter(b=>{if(b.t<=0||(b.ent.gone)){b.el&&b.el.remove();return false;}return true;});},
 // ---------- dialog ----------
 say(who,text,o,cb){const d=$('#dialog');$('#murmur').classList.remove('on');this.dlg={who,text,shown:0,cb,choices:null,sel:0,o:o||{}};
  d.className=(who==='N'?'narr':(o&&o.note?'note':''))+(o&&o.it?' it':'');d.classList.remove('hidden');
  $('#dlgWho').textContent=who==='N'?'':who;d.style.setProperty('--wc',(o&&o.col)||WHO_COL[who]||'#e0a24a');
  $('#dlgText').textContent='';$('#dlgChoices').innerHTML='';$('#dlgNext').style.visibility='hidden';},
 choice(who,text,opts,cb){this.say(who||'N',text||'',{},null);this.dlg.choices=opts;this.dlg.cb=cb;this.dlg.sel=0;if(!text)this.dlg.shown=0;this.renderChoices();},
 renderChoices(){const c=$('#dlgChoices');const D=this.dlg;if(!D.choices)return;if(D.shown<D.text.length){c.innerHTML='';return;}c.innerHTML=D.choices.map((o,i)=>`<div class="${i===D.sel?'sel':''}"><span>${i+1}</span>${o}</div>`).join('');},
 closeDlg(){$('#dialog').classList.add('hidden');this.dlg=null;},
 updDlg(dt){const D=this.dlg;if(!D)return;
  if(D.shown<D.text.length){const sp=D.o.fast?90:52;const prev=Math.floor(D.shown);D.shown=Math.min(D.text.length,D.shown+dt*sp);const n=Math.floor(D.shown);
   if(n>prev&&D.who!=='N'&&D.text[n-1]!==' '&&n%2===0)Snd.play('voice',{pitch:VOICE[D.who]||1});
   let s=D.text.slice(0,n);if(D.o.corrupt)s=corrupt(s,D.o.corrupt);$('#dlgText').textContent=s;
   if(Input.hit('ok')){Input.eat('ok');D.shown=D.text.length;$('#dlgText').textContent=D.o.corrupt?corrupt(D.text,D.o.corrupt):D.text;}
   if(D.shown>=D.text.length){if(D.choices)this.renderChoices();else $('#dlgNext').style.visibility='visible';}
   return;}
  if(D.choices){let ch=false;if(Input.hit('up')){D.sel=(D.sel+D.choices.length-1)%D.choices.length;ch=true;}if(Input.hit('down')){D.sel=(D.sel+1)%D.choices.length;ch=true;}
   for(let i=0;i<D.choices.length;i++)if(Input.pressed.has('Digit'+(i+1))){D.sel=i;Input.eat('ok');this.pickChoice();return;}
   if(ch){Snd.play('ui');this.renderChoices();}
   if(Input.hit('ok')){Input.eat('ok');this.pickChoice();}return;}
  if(Input.hit('ok')){Input.eat('ok');Snd.play('ui');const cb=D.cb;this.closeDlg();cb&&cb();}
 },
 pickChoice(){const D=this.dlg;Snd.play('uiOk');const cb=D.cb,i=D.sel;this.closeDlg();cb&&cb(i);},
 // ---------- murmur / thought / toast ----------
 murmur(t,d){const m=$('#murmur');m.textContent=t;m.classList.toggle('it',!!(G.flags&&G.flags.confront));m.classList.add('on');clearTimeout(this._mt);this._mt=setTimeout(()=>m.classList.remove('on'),(d||Math.max(3.2,t.length*.065))*1000);},
 thought(t,d=3){const m=$('#thought');m.textContent=t;m.classList.add('on');clearTimeout(this._tt);this._tt=setTimeout(()=>m.classList.remove('on'),d*1000);},
 toast(t){let el=$('#toast');if(!el){el=document.createElement('div');el.id='toast';el.style.cssText='position:absolute;left:50%;bottom:4.1em;transform:translateX(-50%);font-size:.55em;letter-spacing:.2em;color:#f2d39b;text-transform:uppercase;transition:opacity .5s;text-shadow:0 0 4px #000';$('#ui').appendChild(el);}
  el.textContent='+ '+t;el.style.opacity=1;clearTimeout(this._to);this._to=setTimeout(()=>el.style.opacity=0,1800);},
 // ---------- card / fade / flash ----------
 card(t,s,cb,hold=2.6){const c=$('#card');$('#cardTitle').textContent=t;$('#cardSub').textContent=s||'';c.style.pointerEvents='auto';c.classList.add('on');
  setTimeout(()=>{cb&&cb();setTimeout(()=>{c.classList.remove('on');},50);},hold*1000+1200);},
 cardNow(on){$('#card').classList.toggle('on',on);},
 fade(to,d,cb){const f=$('#fade');f.style.transition=`opacity ${d}s`;f.style.opacity=to;setTimeout(()=>cb&&cb(),d*1000+30);},
 flash(col='#fff',d=.6,a=1){const f=$('#flash');f.style.background=col;f.style.transition='none';f.style.opacity=a;void f.offsetWidth;f.style.transition=`opacity ${d}s`;f.style.opacity=0;},
 // ---------- modals ----------
 modal(html,kind){const m=$('#modal');m.innerHTML=html;m.classList.remove('hidden');G.modal=kind;},
 closeModal(){$('#modal').classList.add('hidden');$('#modal').innerHTML='';const k=G.modal;G.modal=null;if(this.onModalClose){const f=this.onModalClose;this.onModalClose=null;f(k);}},
 inv(){this.invSel=0;this.modal('<div class="panel"><h2>Bag</h2><div class="inv" id="invG"></div><div class="invInfo" id="invI"></div><div class="foot"><kbd>ARROWS</kbd> SELECT &nbsp; <kbd>E</kbd> USE / EQUIP &nbsp; <kbd>1-5</kbd> MOVE TO HOTBAR &nbsp; <kbd>X</kbd> DROP &nbsp; <kbd>I</kbd> CLOSE</div></div>','inv');this.invDraw();Snd.play('ui');},
 invDraw(){const g=$('#invG');if(!g)return;g.innerHTML='';for(let i=0;i<INV_MAX;i++){const s=G.inv[i];const d=document.createElement('div');d.className='slot'+(i===this.invSel?' sel':'')+(s&&G.equip===s.id?' eq':'');d.innerHTML=(i<5?`<span class="k">${i+1}</span>`:'')+(s?`<img src="${ICON[ITEMS[s.id].icon]}"><span class="n">${s.n>1?s.n:''}</span>`:'');g.appendChild(d);}
  const s=G.inv[this.invSel];$('#invI').innerHTML=s?`<b>${ITEMS[s.id].name}${G.equip===s.id?' · equipped':''}</b><p>${ITEMS[s.id].desc}</p>`:'<p>Empty.</p>';},
 invKeys(){let ch=false;if(Input.hit('left')){this.invSel=(this.invSel+INV_MAX-1)%INV_MAX;ch=true;}if(Input.hit('right')){this.invSel=(this.invSel+1)%INV_MAX;ch=true;}if(Input.hit('up')){this.invSel=(this.invSel+INV_MAX-5)%INV_MAX;ch=true;}if(Input.hit('down')){this.invSel=(this.invSel+5)%INV_MAX;ch=true;}
  const s=G.inv[this.invSel];
  if(Input.hit('interact')&&s){useItem(s.id);if(G.modal==='inv'){if(this.invSel>=G.inv.length)this.invSel=Math.max(0,G.inv.length-1);ch=true;}}
  for(let k=1;k<=5;k++)if(Input.pressed.has('Digit'+k)&&s){const j=k-1;if(j<G.inv.length){const tmp=G.inv[j];G.inv[j]=s;G.inv[this.invSel]=tmp;this.invSel=j;}else{G.inv.splice(this.invSel,1);G.inv.splice(Math.min(j,G.inv.length),0,s);}ch=true;this.hotbar();}
  if(Input.hit('drop')&&s&&!ITEMS[s.id].key){takeItem(s.id,1);G.map.ents.push(new Pickup(P.x+P.fx*10,P.y+P.fy*8,s.id,1));ch=true;Snd.play('ui');}
  if(ch){Snd.play('ui');this.invDraw();}
  if(Input.hit('inv')||Input.hit('pause')){Input.eat('inv');Input.eat('pause');this.closeModal();}},
 noteI:0,
 notebook(){if(!G.notes.length){murmur('Your notebook is empty.');return;}this.noteI=G.notes.length-1;this.modal('<div class="notewrap"><div id="noteP"></div><div class="foot"><kbd>← →</kbd> TURN PAGE &nbsp; <kbd>N</kbd> CLOSE</div></div>','note');this.noteDraw();Snd.play('ui');},
 noteDraw(){const n=G.notes[this.noteI];const el=$('#noteP');if(!el)return;el.innerHTML=`<div class="paper ${n.typed?'typed':''}">${n.title?`<h3>${n.title}</h3>`:''}${n.text.split('\n').map(l=>`<div>${l||'&nbsp;'}</div>`).join('')}<div class="pg">${this.noteI+1} / ${G.notes.length}</div></div>`;},
 noteKeys(){if(Input.hit('left')&&this.noteI>0){this.noteI--;this.noteDraw();Snd.play('ui');}if(Input.hit('right')&&this.noteI<G.notes.length-1){this.noteI++;this.noteDraw();Snd.play('ui');}if(Input.hit('note')||Input.hit('pause')||Input.hit('interact')){Input.eat('note');Input.eat('pause');Input.eat('ok');this.closeModal();}},
 // closeups: animated canvas
 closeup(kind,state){this.cu={kind,state:state||{},t:0};this.modal('<div class="closeup"><canvas id="cuC" width="96" height="96"></canvas></div>','cu');},
 cuDraw(dt){if(!this.cu)return;const c=$('#cuC');if(!c)return;const x=c.getContext('2d');this.cu.t+=dt;CLOSEUP[this.cu.kind](x,this.cu.t,this.cu.state);},
 cuClose(){this.cu=null;this.closeModal();},
 phone(html){this.modal(`<div class="panel" style="min-width:18em;max-width:20em;border-radius:1.2em;padding:1.2em 1.1em;background:#0a0d11"><div style="font-size:.5em;letter-spacing:.2em;color:#6f7a86;margin-bottom:1em;display:flex;justify-content:space-between"><span>${G.flags.netDown?'NO SERVICE':'EE 4G'}</span><span>${G.clock||'07:12'}</span></div>${html}</div>`,'phone');},
 // ---------- menus ----------
 menu(items,sel,onPick,el){this._menu={items,sel,onPick,el};this.menuDraw();},
 menuDraw(){const M=this._menu;if(!M)return;$(M.el).innerHTML=M.items.map((it,i)=>`<div class="${i===M.sel?'sel':''} ${it.dis?'dis':''}">${it.t}</div>`).join('');},
 menuKeys(){const M=this._menu;if(!M)return;let ch=false;const n=M.items.length;
  if(Input.hit('up')){do{M.sel=(M.sel+n-1)%n;}while(M.items[M.sel].dis);ch=true;}if(Input.hit('down')){do{M.sel=(M.sel+1)%n;}while(M.items[M.sel].dis);ch=true;}
  if(ch){Snd.play('ui');this.menuDraw();}
  if(Input.hit('ok')){Input.clear();Snd.play('uiOk');const it=M.items[M.sel];this._menu=null;M.onPick(it.id);}},
 pause(){if(G.state!=='play'||G.modal||G.lull)return;G.paused=true;this.modal('<div class="panel" style="text-align:center"><h2>Paused</h2><div class="menu" id="pm"></div></div>','pause');
  this.menu([{t:'Resume',id:'r'},{t:'Bag',id:'i'},{t:'Notebook',id:'n'},{t:'Controls',id:'c'},{t:'Graphics: '+resLabel(),id:'res'},{t:G.coop?'Leave the game':'Quit to title',id:'q'}],0,id=>{this.closeModal();G.paused=false;if(id==='res'){toggleRes();this.pause();this._menu.sel=4;this.menuDraw();return;}if(id==='i')this.inv();if(id==='n')this.notebook();if(id==='c')this.controls();if(id==='q')Game.toTitle();},'#pm');},
 controls(back){this.modal(`<div class="panel"><h2>Controls</h2><div class="ctrl">
  <kbd>WASD / ARROWS</kbd><span>Move</span><kbd>SHIFT</kbd><span>Sprint</span><kbd>E</kbd><span>Interact / continue</span><kbd>SPACE</kbd><span>Attack</span><kbd>Q</kbd><span>Dodge</span><kbd>F</kbd><span>Torch</span><kbd>I / TAB</kbd><span>Bag</span><kbd>1 – 5</kbd><span>Use hotbar item</span><kbd>N</kbd><span>Notebook</span><kbd>ESC</kbd><span>Pause</span>${G.coop?'<kbd>T + 1–8</kbd><span>Say aloud (only people near you)</span><kbd>R + 1–8</kbd><span>Radio (no name, any distance)</span><kbd>R + SPACE</kbd><span>Radio click code</span><kbd>C</kbd><span>Change radio channel</span><kbd>I then G</kbd><span>Give the selected item to the nearest friend</span><kbd>HOLD E</kbd><span>Help a fallen friend up</span>':''}</div><div class="foot"><kbd>E</kbd> BACK</div></div>`,'ctrl');this._ctrlBack=back;},
};
const WHO_COL={ELLIE:'#d9a0b8',PRIYA:'#9ac0d8',DEV:'#a8c890',GARY:'#d8c060',TUNDE:'#e0a060',OKAFOR:'#c0a8d8',LENA:'#e8b090',RADIO:'#8f9aa6',WALSH:'#7a9ad8',DARBY:'#7a9ad8',SOLDIER:'#a8b080',ROWAN:'#cfd5da','999':'#8f9aa6',TV:'#8f9aa6',VOICEMAIL:'#d9a0b8'};
const VOICE={ELLIE:1.4,PRIYA:1.3,DEV:1.05,GARY:.75,TUNDE:.8,OKAFOR:1.25,LENA:1.45,WALSH:.85,DARBY:.95,SOLDIER:.8,ROWAN:1};
function murmur(t,d){UI.murmur(t,d);}
function toast(t){UI.toast(t);}
function bubble(ent,text,o={}){G.bubbles=G.bubbles.filter(b=>{if(b.ent===ent){b.el&&b.el.remove();return false;}return true;});G.bubbles.push({ent,text,t:o.t||2.6,shout:o.shout});}

// ================= CLOSE-UP ART =================
function face(x,o){
 // bathroom mirror portrait 96x96
 const sk=o.dark?'#7a6656':'#c79b7d',sk2=o.dark?'#5a4a3e':'#a77a60',hr='#3b2a22';
 const ox=(o.lag||0)|0;
 R(x,'#2a2620',0,0,96,96);R(x,'#b8b2a6',4,4,88,88);R(x,o.dark?'#0e1216':'#4e5d66',8,8,80,80);
 if(!o.dark){for(let i=0;i<6;i++)R(x,'#5a6a74',10+i*14,10,1,76);}
 // shoulders
 R(x,'#2f3a35',18+ox,72,60,16);R(x,'#3d4b44',22+ox,72,52,16);R(x,'#7a3a32',34+ox,70,28,6);
 // neck
 R(x,sk2,42+ox,60,12,12);
 // head
 R(x,sk,32+ox,24,32,38);R(x,sk,34+ox,22,28,2);R(x,sk,36+ox,62,24,3);R(x,sk2,60+ox,30,4,30);
 // hair
 R(x,hr,30+ox,16,36,10);R(x,hr,32+ox,14,30,3);R(x,hr,30+ox,24,4,14);R(x,hr,62+ox,24,4,12);R(x,'#4a3528',36+ox,17,10,2);
 // brows/eyes
 R(x,hr,37+ox,35,9,2);R(x,hr,51+ox,35,9,2);
 if(o.closed){R(x,'#6a4a3a',38+ox,40,8,1);R(x,'#6a4a3a',51+ox,40,8,1);}
 else{R(x,'#e8e2d8',38+ox,39,8,4);R(x,'#e8e2d8',51+ox,39,8,4);R(x,o.dark?'#1a1a1a':'#2a1e18',41+ox,39,3,4);R(x,o.dark?'#1a1a1a':'#2a1e18',54+ox,39,3,4);R(x,'#fff',41+ox,39,1,1);R(x,'#fff',54+ox,39,1,1);
  if(o.tired){R(x,sk2,38+ox,44,8,1);R(x,sk2,51+ox,44,8,1);R(x,'#9a7060',38+ox,45,8,1);R(x,'#9a7060',51+ox,45,8,1);}}
 // nose
 R(x,sk2,47+ox,42,3,10);R(x,sk2,45+ox,51,7,2);
 // mouth
 if(o.smile){R(x,'#7a4038',40+ox,55,2,2);R(x,'#7a4038',42+ox,57,12,2);R(x,'#7a4038',54+ox,55,2,2);R(x,'#e8e2d8',43+ox,57,10,1);}
 else{R(x,'#8a5044',41+ox,57,14,2);}
 // glass sheen
 x.fillStyle='rgba(255,255,255,.06)';x.beginPath();x.moveTo(8,8);x.lineTo(30,8);x.lineTo(8,40);x.fill();
 if(o.dark){x.fillStyle='rgba(0,0,0,.35)';x.fillRect(8,8,80,80);const g=x.createRadialGradient(48,44,4,48,44,42);g.addColorStop(0,'rgba(255,230,190,.25)');g.addColorStop(1,'rgba(0,0,0,.6)');x.fillStyle=g;x.fillRect(8,8,80,80);}
}
const CLOSEUP={
 micro(x,t,s){x.fillStyle='#000';x.fillRect(0,0,96,96);
  const g=x.createRadialGradient(48,48,4,48,48,46);g.addColorStop(0,'#cfd8b8');g.addColorStop(.8,'#9aa888');g.addColorStop(1,'#3a4436');x.fillStyle=g;x.beginPath();x.arc(48,48,44,0,7);x.fill();
  if(!s.rods){s.rods=[];const r=RNG(3);for(let i=0;i<38;i++)s.rods.push({x:16+r()*64,y:16+r()*64,a:r()*7,v:4+r()*6,w:r()*7});}
  s.al=s.al||0;s.al=lerp(s.al,s.align?1:0,.05);
  x.save();x.beginPath();x.arc(48,48,44,0,7);x.clip();
  for(const p of s.rods){if(!s.align){p.w+=.05;p.a+=Math.sin(p.w)*.06+(s.school?Math.sin(t*.7)*.03:0);p.x+=Math.cos(p.a)*p.v*.016;p.y+=Math.sin(p.a)*p.v*.016;if(dist(p.x,p.y,48,48)>42){p.a+=Math.PI;}}
   const ta=Math.atan2(48-p.y,48-p.x);const a=s.al>.01?lerp(p.a,ta,s.al):p.a;
   x.save();x.translate(p.x,p.y);x.rotate(a);x.fillStyle='rgba(60,80,50,.85)';x.fillRect(-3,-1,6,2);x.fillStyle='rgba(30,40,25,.9)';x.fillRect(s.al>.5?2:-3,-1,1,2);if(!s.align){x.fillStyle='rgba(60,80,50,.4)';x.fillRect(-5-Math.sin(t*20+p.w)*1,0,2,1);}x.restore();}
  x.restore();x.strokeStyle='#111';x.lineWidth=3;x.beginPath();x.arc(48,48,45,0,7);x.stroke();
  if(s.align){x.fillStyle=`rgba(0,0,0,${.15*Math.random()})`;x.fillRect(0,0,96,96);}},
 mirror(x,t,s){face(x,{tired:s.tired,smile:s.smile&&s.smileOn,dark:s.dark,lag:s.dark?Math.sin(t*1.3-1)*2:0,closed:s.closed});
  if(s.flicker&&Math.random()<.04){x.fillStyle='rgba(0,0,0,.6)';x.fillRect(0,0,96,96);}},
 photo(x,t,s){x.fillStyle='#e9e4d8';x.fillRect(0,0,96,96);x.fillStyle='#8a9aa4';x.fillRect(6,6,84,30);x.fillStyle='#6a7e8a';x.fillRect(6,30,84,10);x.fillStyle='#c8b48a';x.fillRect(6,40,84,32);x.fillStyle='#b8a47a';for(let i=0;i<12;i++)x.fillRect(6+((i*29)%84),42+((i*17)%28),3,1);
  // pier
  x.fillStyle='#5a5a5a';x.fillRect(60,26,30,3);for(let i=62;i<90;i+=6)x.fillRect(i,29,1,6);
  // two people
  const fig=(cx,skin,hair,coat,expr,tall)=>{R(x,coat,cx-7,44-tall,14,26+tall);R(x,skin,cx-5,30-tall,10,12);R(x,hair,cx-6,28-tall,12,5);R(x,hair,cx-6,30-tall,2,8);
   if(expr==='closed'){R(x,'#6a4a3a',cx-3,35-tall,2,1);R(x,'#6a4a3a',cx+1,35-tall,2,1);}else{R(x,'#1a1412',cx-3,35-tall,1,1);R(x,'#1a1412',cx+2,35-tall,1,1);}
   if(expr==='flat')R(x,'#8a5044',cx-2,39-tall,4,1);
   if(expr==='half'){R(x,'#8a5044',cx-2,39-tall,4,1);R(x,'#8a5044',cx+2,38-tall,1,1);}
   if(expr==='big'||expr==='closed'){R(x,'#7a4038',cx-3,38-tall,1,1);R(x,'#7a4038',cx-2,39-tall,4,1);R(x,'#7a4038',cx+2,38-tall,1,1);if(expr==='big')R(x,'#f0ece4',cx-1,39-tall,2,1);}};
  fig(34,'#c79b7d','#3b2a22','#3d4b44','flat',2);fig(56,'#d2a688','#7a4a2a','#8a4a5a',['half','big','closed'][s.stage||0],0);
  x.fillStyle='rgba(240,220,180,.12)';x.fillRect(6,6,84,66);x.fillStyle='#3a3a3a';x.font='6px monospace';x.fillText('SOUTHEND ’19',8,84);
  if(s.stage===2&&Math.random()<.03){x.fillStyle='rgba(0,0,0,.5)';x.fillRect(46,20,20,30);}},
};

function resLabel(){return {hd:'HD',med:'Medium',retro:'Retro (low-res)'}[store('lull_res')||'hd'];}
function toggleRes(){const o=['hd','med','retro'];const c=store('lull_res')||'hd';store('lull_res',o[(o.indexOf(c)+1)%3]);setRes();}
