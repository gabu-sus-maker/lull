// ================= PROPS =================
const PROP={};
function def(name,o){PROP[name]=o;}
function shade(x,c,X,Y,w,h,top,side){R(x,c,X,Y,w,h);if(top)R(x,top,X,Y,w,1);if(side)R(x,side,X+w-1,Y,1,h);}
// --- interior ---
def('bed',{w:26,h:34,box:[-12,-30,24,30],draw(x,o){shade(x,'#3f2e22',1,0,24,6,'#5a4230');R(x,'#2e2219',1,5,24,1);R(x,'#d8d6cf',3,6,20,30-6);
 const dc=o.v==='a1'?'#3d4550':o.v==='ellie'?'#a8687a':'#5f6f80';R(x,dc,2,12,22,20);R(x,sh(dc,.88),2,12,22,2);for(let i=0;i<4;i++)R(x,sh(dc,.9),4+i*5,16+i*3,4,1);
 R(x,'#e4e2dc',5,7,7,4);R(x,'#e4e2dc',14,7,7,4);R(x,'#bdbab2',5,10,16,1);R(x,'#3f2e22',1,32,24,2);if(o.v==='a1'){R(x,'#2b3038',16,20,8,9);}}});
def('wardrobe',{w:16,h:28,box:[-8,-8,16,8],draw(x){shade(x,'#56402f',0,4,16,24,null,'#45331f');R(x,'#6e523c',0,0,16,4);R(x,'#3f2e22',7,5,1,22);R(x,'#c8a65a',5,15,1,2);R(x,'#c8a65a',9,15,1,2);R(x,'#2a1e16',0,27,16,1);}});
def('sofa',{w:34,h:20,box:[-16,-14,32,14],draw(x){R(x,'#3d3243',1,1,32,8);R(x,'#4a3d51',1,1,32,1);R(x,'#55475c',4,8,26,8);R(x,'#625369',4,8,26,1);R(x,'#3f3346',16,8,1,8);R(x,'#45394c',0,4,5,13);R(x,'#45394c',29,4,5,13);R(x,'#55475c',0,4,5,1);R(x,'#55475c',29,4,5,1);R(x,'#2a2230',1,17,32,2);R(x,'#7a6a52',22,9,5,4);}});
def('tv',{w:20,h:20,box:[-9,-6,18,6],draw(x){R(x,'#2a2a2e',2,13,16,7);R(x,'#3a3a40',2,13,16,1);R(x,'#141518',1,0,18,12);R(x,'#07080a',2,1,16,10);R(x,'#1c2128',3,2,4,1);R(x,'#0e0f12',8,12,4,1);}});
def('shelf',{w:22,h:26,box:[-10,-6,20,6],draw(x,o){R(x,'#4b3627',1,0,20,26);R(x,'#2a1e16',2,1,18,24);for(let s=0;s<3;s++){const y=2+s*8;R(x,'#5a4230',2,y+6,18,2);let X=3;while(X<19){const w=1+((Math.random()*2)|0),h=4+((Math.random()*2)|0);R(x,pick(['#7a3a32','#3a5a7a','#d0c8a8','#4a6a4a','#8a7a4a','#5a3a5a']),X,y+6-h,w,h);X+=w+((Math.random()<.2)?2:0);if(s===1&&X>11)break;}}
 R(x,'#c8b27a',13,8,5,6);R(x,'#7a9ab0',14,9,3,4);R(x,'#d8d0b8',14,9,1,1);}});
def('ctable',{w:22,h:12,box:[-10,-8,20,8],draw(x){R(x,'#5a4230',1,1,20,7);R(x,'#6e523c',1,1,20,1);R(x,'#3f2e22',2,8,2,4);R(x,'#3f2e22',18,8,2,4);R(x,'#101215',12,3,4,3);R(x,'#7ab0d0',13,4,1,1);R(x,'#c8c2b5',4,3,4,3);}});
def('table',{w:26,h:20,box:[-12,-12,24,10],draw(x,o){R(x,'#5f4533',1,2,24,10);R(x,'#73563f',1,2,24,1);R(x,'#4b3627',1,11,24,2);R(x,'#3f2e22',2,12,2,7);R(x,'#3f2e22',22,12,2,7);if(o.v==='notes'){R(x,'#ded6c2',6,4,6,5);R(x,'#d2c9b0',9,5,6,5);R(x,'#2a2a3a',10,6,4,1);R(x,'#2a2a3a',10,8,3,1);}else{R(x,'#d8d6cf',8,5,4,3);R(x,'#c8c2b5',15,4,3,3);}}});
def('chair',{w:10,h:16,box:[-4,-5,8,5],draw(x){R(x,'#4b3627',1,0,8,7);R(x,'#5a4230',1,0,8,1);R(x,'#5a4230',1,7,8,4);R(x,'#3f2e22',1,11,2,5);R(x,'#3f2e22',7,11,2,5);}});
def('counter',{w:16,h:24,box:[-8,-12,16,12],draw(x,o){R(x,'#8a8478',0,4,16,8);R(x,'#9c968a',0,4,16,1);R(x,'#6c675d',0,11,16,1);R(x,'#4c453e',0,12,16,12);R(x,'#3c362f',0,12,16,1);R(x,'#3c362f',7,13,1,11);R(x,'#9a9a9a',5,16,1,2);R(x,'#9a9a9a',9,16,1,2);
 const v=o.v||'plain';
 if(v==='sink'){R(x,'#9ba3a7',3,5,10,6);R(x,'#6d767b',4,6,8,4);R(x,'#c0c6c9',7,3,2,3);}
 if(v==='hob'){R(x,'#18191b',1,5,14,6);[[4,7],[11,7],[4,9],[11,9]].forEach(([a,b])=>{R(x,'#3a3b3e',a-1,b-1,3,2);});}
 if(v==='kettle'){R(x,'#c9cdd0',5,0,6,8);R(x,'#e2e5e7',5,0,6,1);R(x,'#9aa0a4',10,2,2,3);R(x,'#9aa0a4',3,1,2,2);R(x,'#3a3d40',6,7,4,1);R(x,'#d8d6cf',12,6,3,3);}
 if(v==='radio'){R(x,'#6e4f35',2,3,12,7);R(x,'#866248',2,3,12,1);R(x,'#2a2a2a',4,5,5,4);R(x,'#c8b070',10,5,2,2);R(x,'#888',12,0,1,4);}
 if(v==='drawer'){R(x,'#3c362f',0,17,16,1);R(x,'#3c362f',0,20,16,1);}
 if(v==='kettle'||v==='plain'||v==='drawer'){}}});
def('fridge',{w:14,h:28,box:[-7,-8,14,8],draw(x,o){R(x,'#c9ccca',0,0,14,28);R(x,'#dfe2e0',0,0,14,2);R(x,'#a4a8a6',13,0,1,28);R(x,'#a4a8a6',0,11,14,1);R(x,'#7d8285',2,4,1,5);R(x,'#7d8285',2,14,1,8);R(x,'#888c8a',0,27,14,1);if(o.v==='a1'){R(x,'rgba(60,50,30,.35)',0,0,14,28);}}});
def('bowl',{w:10,h:6,draw(x,o){R(x,'#9aa2a8',1,1,8,4);R(x,'#c6ccd0',1,1,8,1);R(x,'#5a6066',2,2,6,2);if(o.v==='full'){R(x,'#7a5236',2,2,6,2);}}});
def('dogbed',{w:20,h:12,layer:0,draw(x){R(x,'#5d453b',1,2,18,9);R(x,'#6e5348',2,1,16,2);R(x,'#7c6155',3,4,14,5);}});
def('bath',{w:30,h:18,box:[-15,-16,30,16],draw(x){R(x,'#d9dad5',0,1,30,16);R(x,'#eeeeea',0,1,30,1);R(x,'#b0b4b2',2,3,26,11);R(x,'#9eb2b8',3,4,24,9);R(x,'#bccacd',4,5,6,1);R(x,'#a8acaa',0,16,30,2);R(x,'#c0c6c9',26,0,2,3);}});
def('sink',{w:12,h:16,box:[-5,-5,10,5],draw(x){R(x,'#dcdcd8',0,2,12,6);R(x,'#b6bab8',2,3,8,4);R(x,'#c0c6c9',5,0,2,3);R(x,'#cfcfcb',4,8,4,8);R(x,'#a8acaa',4,15,4,1);}});
def('toilet',{w:12,h:16,box:[-5,-8,10,8],draw(x){R(x,'#d9dad5',1,0,10,5);R(x,'#e8e8e4',2,6,8,8);R(x,'#b8bcba',3,7,6,5);R(x,'#a8acaa',3,14,6,2);}});
def('mirror',{w:12,h:12,wall:true,draw(x){R(x,'#9c978d',0,0,12,12);R(x,'#b7b2a7',0,0,12,1);R(x,'#3d4b54',1,1,10,10);R(x,'#55666f',2,2,3,1);R(x,'#55666f',2,3,1,2);}});
def('plant',{w:12,h:20,box:[-4,-4,8,4],draw(x){R(x,'#8a4a32',3,13,6,7);R(x,'#a05a3e',3,13,6,1);for(let i=0;i<9;i++)R(x,pick(['#2f4a33','#3d5c40','#4a6e4a']),1+((Math.random()*9)|0),1+((Math.random()*11)|0),3,3);}});
def('rug',{w:34,h:22,layer:0,draw(x){R(x,'#4a2f2c',0,0,34,22);R(x,'#6a423b',2,2,30,18);R(x,'#4a2f2c',5,5,24,12);R(x,'#7a5a3a',8,8,18,6);R(x,'#4a2f2c',11,10,12,2);}});
def('lampF',{w:10,h:28,box:[-2,-3,4,3],light:{dy:-20,r:52,c:'255,200,140',i:.8},draw(x,o){R(x,'#2a2a2a',3,24,4,4);R(x,'#3a3a3a',4,8,2,16);R(x,o.on?'#e8c48a':'#8a7a62',0,0,10,9);R(x,o.on?'#f4dcae':'#9a8a72',1,1,8,1);}});
def('toolbox',{w:16,h:12,box:[-7,-6,14,6],draw(x){R(x,'#8a2a24',1,4,14,8);R(x,'#a83a30',1,4,14,1);R(x,'#5a1a16',1,8,14,1);R(x,'#2a2a2a',5,1,6,1);R(x,'#2a2a2a',5,1,1,3);R(x,'#2a2a2a',10,1,1,3);}});
def('boxes',{w:16,h:16,box:[-7,-7,14,7],draw(x){R(x,'#8a6a42',1,6,14,10);R(x,'#a07c4e',1,6,14,1);R(x,'#6e5434',8,6,1,10);R(x,'#9a7a4a',3,0,10,7);R(x,'#b08c5a',3,0,10,1);R(x,'#c8b890',5,3,5,1);}});
def('bedroll',{w:26,h:12,layer:0,draw(x){R(x,'#3a4a3a',1,2,24,9);R(x,'#4a5c4a',1,2,24,1);R(x,'#2c3a2c',4,4,18,1);R(x,'#7a6a5a',2,3,5,6);}});
// --- street ---
const CARC=['#7a2e2a','#2f4a63','#b9b8b2','#3a423c','#1d1f23','#6b6f74','#5a4a6a'];
def('car',{w:36,h:24,box:[-16,-13,32,12],draw(x,o){const c=CARC[o.c||0];R(x,'#0a0b0d',3,19,6,4);R(x,'#0a0b0d',27,19,6,4);R(x,c,1,7,34,14);R(x,'rgba(255,255,255,.12)',1,7,34,1);R(x,'rgba(0,0,0,.28)',1,18,34,3);
 R(x,'rgba(0,0,0,.2)',9,3,18,12);R(x,c,10,2,16,12);R(x,'rgba(255,255,255,.08)',10,2,16,1);R(x,'#17222b',8,5,3,9);R(x,'#17222b',25,5,3,9);R(x,'#22303b',11,4,14,2);
 R(x,'#e8e2c8',34,9,1,3);R(x,'#e8e2c8',34,16,1,2);R(x,'#7a1f1a',1,9,1,3);R(x,'#7a1f1a',1,16,1,2);
 if(o.occ){R(x,'#2a2620',22,6,3,3);R(x,o.dead?'#7d8676':'#b08a6e',22,6,3,2);}
 if(o.dirty){R(x,'rgba(30,25,20,.35)',1,7,34,14);R(x,'#151a1f',12,4,3,2);}}});
def('van',{w:42,h:26,box:[-19,-15,38,14],draw(x,o){R(x,'#0a0b0d',4,21,6,4);R(x,'#0a0b0d',31,21,6,4);R(x,o.c||'#d0d0cc',1,4,40,19);R(x,'#e6e6e2',1,4,40,1);R(x,'rgba(0,0,0,.25)',1,19,40,4);R(x,'#17222b',33,7,5,12);R(x,'#9a9a96',10,6,1,14);if(o.dirty)R(x,'rgba(30,25,20,.35)',1,4,40,19);}});
def('bus',{w:72,h:30,box:[-34,-19,68,18],draw(x,o){R(x,'#0a0b0d',8,25,8,4);R(x,'#0a0b0d',54,25,8,4);R(x,'#8f241f',1,4,70,23);R(x,'#a83029',1,4,70,2);R(x,'#7a1d19',1,22,70,5);R(x,'#141c22',3,7,64,4);for(let i=6;i<66;i+=8)R(x,'#8f241f',i,7,1,4);R(x,'#141c22',3,15,60,4);for(let i=8;i<62;i+=9)R(x,'#8f241f',i,15,1,4);R(x,'#e8e2c8',70,10,1,4);R(x,'#c9b44a',66,5,4,2);if(o.dirty){R(x,'rgba(20,15,10,.4)',1,4,70,23);}if(o.tilt){}}});
def('police',{w:36,h:24,box:[-16,-13,32,12],draw(x){R(x,'#0a0b0d',3,19,6,4);R(x,'#0a0b0d',27,19,6,4);R(x,'#d9dcdf',1,7,34,14);for(let i=1;i<35;i+=4){R(x,i%8===1?'#2a4f9a':'#d6cf3a',i,15,4,3);}R(x,'#d9dcdf',10,2,16,12);R(x,'#17222b',8,5,3,9);R(x,'#17222b',25,5,3,9);R(x,'#1a2a6a',15,4,6,2);}});
def('ambulance',{w:42,h:26,box:[-19,-15,38,14],draw(x){R(x,'#0a0b0d',4,21,6,4);R(x,'#0a0b0d',31,21,6,4);R(x,'#d3c84a',1,4,40,19);R(x,'#e6dc6a',1,4,40,1);for(let i=1;i<41;i+=4){R(x,i%8===1?'#2c7a4a':'#d3c84a',i,16,4,3);}R(x,'#17222b',33,7,5,10);R(x,'#c03a2a',12,8,2,6);R(x,'#c03a2a',10,10,6,2);R(x,'#1a2a6a',20,5,8,2);}});
def('truck',{w:48,h:30,box:[-22,-18,44,17],draw(x){R(x,'#0a0b0d',5,25,8,4);R(x,'#0a0b0d',35,25,8,4);R(x,'#4a5038',1,3,32,24);R(x,'#5a6046',1,3,32,2);for(let i=4;i<32;i+=7)R(x,'#3c4230',i,5,1,21);R(x,'#3e4430',33,9,14,18);R(x,'#17222b',41,11,5,8);}});
def('bin',{w:10,h:16,box:[-4,-5,8,5],draw(x,o){const c=o.c||'#1e2a22';R(x,c,1,3,8,12);R(x,'rgba(255,255,255,.12)',1,3,8,1);R(x,'#101215',0,1,10,3);R(x,'#0a0a0a',1,14,2,2);R(x,'#0a0a0a',7,14,2,2);if(o.tip){R(x,'#2a2a2a',2,15,7,1);}}});
def('lamp',{w:10,h:48,box:[-2,-3,4,3],light:{dy:-4,r:78,c:'255,170,90',i:.92,head:-42},draw(x,o){R(x,'#1b1e22',4,8,2,38);R(x,'#2a2e33',3,43,4,5);R(x,'#272b30',1,2,8,6);R(x,'#3a3f45',1,2,8,1);R(x,o.on?'#ffd08a':'#4a4a44',2,6,6,2);R(x,'#272b30',4,0,2,2);}});
def('bench',{w:26,h:14,box:[-12,-5,24,5],draw(x){R(x,'#1c1e21',2,6,2,8);R(x,'#1c1e21',22,6,2,8);R(x,'#5a4230',0,0,26,2);R(x,'#4b3627',0,3,26,2);R(x,'#5a4230',0,6,26,2);R(x,'#6e523c',0,6,26,1);}});
def('tree',{w:38,h:48,box:[-3,-4,6,4],draw(x){R(x,'#2f241c',17,30,4,18);R(x,'#3a2c22',17,30,1,18);const blobs=[[19,16,13],[11,20,9],[27,20,9],[19,8,9],[13,12,8],[26,12,8]];blobs.forEach(([cx,cy,rr],i)=>{x.fillStyle=['#1c2a1f','#22331f','#1a2a1d','#26382a'][i%4];x.beginPath();x.arc(cx,cy,rr,0,7);x.fill();});x.fillStyle='#2e4433';for(let i=0;i<40;i++){const a=Math.random()*7,d=Math.random()*12;x.fillRect((19+Math.cos(a)*d-4)|0,(12+Math.sin(a)*d-4)|0,2,2);}x.fillStyle='#14201a';for(let i=0;i<20;i++){const a=Math.random()*7,d=Math.random()*12;x.fillRect((19+Math.cos(a)*d+3)|0,(20+Math.sin(a)*d)|0,2,2);}}});
def('shelter',{w:36,h:30,box:[-17,-5,34,5],draw(x){R(x,'#1f2328',1,0,34,4);R(x,'#3a4048',1,0,34,1);R(x,'rgba(110,140,160,.28)',2,4,32,20);R(x,'#1f2328',1,4,1,26);R(x,'#1f2328',34,4,1,26);R(x,'#1f2328',17,4,1,22);R(x,'#3a3f45',4,18,28,2);R(x,'#c03a2a',30,6,4,4);R(x,'#e8e8e0',31,7,2,2);}});
def('phonebox',{w:14,h:32,box:[-6,-8,12,8],draw(x){R(x,'#8f1f1a',1,3,12,29);R(x,'#a82a22',1,3,12,1);R(x,'#7a1814',0,1,14,3);R(x,'#b8322a',3,0,8,2);R(x,'#e8dcc0',3,4,8,2);for(let i=0;i<3;i++)for(let j=0;j<4;j++)R(x,'#1c2228',3+i*3,8+j*5,2,4);R(x,'#5a120f',1,30,12,2);}});
def('postbox',{w:8,h:16,box:[-3,-4,6,4],draw(x){R(x,'#8f1f1a',1,2,6,14);R(x,'#b8322a',1,0,6,3);R(x,'#1c1c1c',2,5,4,1);R(x,'#c8a65a',3,8,2,2);}});
def('cone',{w:8,h:10,draw(x){R(x,'#d06a2a',3,1,2,7);R(x,'#e8e8e0',3,4,2,1);R(x,'#b05a22',1,8,6,2);}});
def('barrier',{w:34,h:18,box:[-16,-4,32,4],draw(x){R(x,'#8f969c',1,2,32,2);R(x,'#8f969c',1,14,32,1);for(let i=1;i<33;i+=3)R(x,'#7d8489',i,2,1,13);R(x,'#5a6066',2,15,3,3);R(x,'#5a6066',29,15,3,3);}});
def('barrierR',{w:34,h:16,box:[-16,-5,32,5],draw(x){R(x,'#d9dcdf',1,4,32,5);for(let i=1;i<33;i+=6)R(x,'#c0302a',i,4,3,5);R(x,'#3a3d40',3,9,2,7);R(x,'#3a3d40',29,9,2,7);}});
def('sandbags',{w:26,h:12,box:[-12,-6,24,6],draw(x){for(let i=0;i<3;i++)R(x,'#7a6e52',1+i*8,5,8,6);for(let i=0;i<2;i++)R(x,'#8a7e60',5+i*8,1,8,5);R(x,'#5a5038',1,10,24,2);}});
def('stretcher',{w:24,h:12,box:[-11,-6,22,6],draw(x){R(x,'#3a3d40',2,9,2,3);R(x,'#3a3d40',20,9,2,3);R(x,'#7a8085',1,6,22,3);R(x,'#dcdcd8',1,1,22,6);R(x,'#c8c8c4',3,1,6,4);R(x,'#b8b8b4',10,2,12,4);}});
def('fruit',{w:26,h:16,box:[-12,-7,24,7],draw(x){R(x,'#6e5434',1,6,24,10);R(x,'#8a6a42',1,6,24,1);for(let i=0;i<3;i++){R(x,'#4e3a24',2+i*8,2,7,5);for(let j=0;j<5;j++)R(x,['#c8402e','#d8b03a','#6a9a3a','#e0802a'][i%4],3+i*8+((Math.random()*5)|0),2+((Math.random()*3)|0),2,2);}}});
def('bags',{w:16,h:12,box:[-6,-4,12,4],draw(x){R(x,'#121416',1,4,8,8);R(x,'#16181b',6,2,9,9);R(x,'#2a2e33',7,3,2,1);R(x,'#2a2e33',2,5,2,1);}});
def('burnt',{w:36,h:24,box:[-16,-13,32,12],draw(x){R(x,'#0a0b0d',3,19,6,4);R(x,'#0a0b0d',27,19,6,4);R(x,'#1a1816',1,7,34,14);R(x,'#2a2420',1,7,34,1);R(x,'#100e0c',10,2,16,12);for(let i=0;i<12;i++)R(x,pick(['#3a2a20','#2a201a','#5a3a20']),2+((Math.random()*32)|0),8+((Math.random()*12)|0),2,1);}});
def('sign',{w:16,h:32,box:[-2,-3,4,3],draw(x){R(x,'#2a2e33',7,10,2,22);R(x,'#d9dcdc',1,0,14,11);R(x,'#2f8a83',1,0,14,3);R(x,'#2a2e33',3,5,10,1);R(x,'#2a2e33',3,7,7,1);}});
// --- lab ---
def('bench2',{w:50,h:22,box:[-24,-12,48,12],draw(x,o){R(x,'#2b3033',1,2,48,9);R(x,'#3a4044',1,2,48,1);R(x,'#d3d7d4',1,11,48,11);R(x,'#b7bcb9',1,11,48,1);for(let i=13;i<48;i+=12)R(x,'#a3a8a5',i,12,1,10);
 const v=o.v||'';if(v.includes('rack')){R(x,'#cfd3d6',18,3,12,5);for(let i=0;i<5;i++)R(x,['#b8a04a','#8a6a3a','#9ab0a0','#7a5a3a','#c8c070'][i],19+i*2,1,1,5);}
 if(v.includes('beak')){R(x,'rgba(170,210,230,.6)',6,3,4,5);R(x,'rgba(170,210,230,.6)',40,4,3,4);R(x,'#cfe8f0',6,3,4,1);}
 if(v.includes('micro')){R(x,'#e8eaea',34,0,6,8);R(x,'#2a2e33',36,0,2,4);R(x,'#9aa0a4',33,7,8,2);}}});
def('hood',{w:34,h:36,box:[-16,-10,32,10],light:{dy:-18,r:34,c:'210,235,255',i:.55},draw(x){R(x,'#c9cdca',1,0,32,36);R(x,'#dfe2df',1,0,32,2);R(x,'#9aa0a0',1,24,32,1);R(x,'rgba(160,200,215,.55)',4,5,26,17);R(x,'#e8f4f8',4,5,26,1);R(x,'#7a8085',4,14,26,1);R(x,'#1a6a3a',27,27,3,2);R(x,'#d03a2a',23,27,3,2);R(x,'#a8acaa',1,26,32,10);}});
def('sfridge',{w:16,h:30,box:[-7,-8,14,8],light:{dy:-14,r:26,c:'190,220,255',i:.45},draw(x){R(x,'#9aa0a4',0,0,16,30);R(x,'#b8bec2',0,0,16,1);R(x,'#cfe6f2',2,2,12,22);for(let i=0;i<4;i++){R(x,'#8a9aa8',2,6+i*5,12,1);for(let j=0;j<5;j++)R(x,pick(['#b8a04a','#9a6a3a','#5a8aa8']),3+j*2,3+i*5,1,3);}R(x,'#6a7074',13,10,1,6);}});
def('desk',{w:28,h:20,box:[-13,-10,26,10],draw(x,o){R(x,'#9a8464',1,4,26,8);R(x,'#ae9876',1,4,26,1);R(x,'#6a5a44',1,12,26,2);R(x,'#3a3d40',2,13,2,7);R(x,'#3a3d40',24,13,2,7);R(x,'#17191c',7,0,12,8);R(x,o.on===false?'#0e1012':'#4a6e8e',8,1,10,6);R(x,'#7aa2c2',9,2,3,1);R(x,'#2a2d30',12,8,2,1);R(x,'#2a2d30',8,9,10,2);if(o.v==='mess')R(x,'#e8e4d8',20,5,5,4);}});
def('lockers',{w:34,h:30,box:[-16,-8,32,8],draw(x){R(x,'#626a70',1,0,32,30);R(x,'#7a8288',1,0,32,2);for(let i=1;i<33;i+=8){R(x,'#4c5358',i,2,1,28);for(let j=0;j<3;j++)R(x,'#4c5358',i+2,5+j*2,4,1);R(x,'#a0a6aa',i+5,16,1,2);}}});
def('whiteboard',{w:34,h:14,wall:true,draw(x){R(x,'#9a9e9e',0,0,34,14);R(x,'#e8ecea',1,1,32,11);R(x,'#3a5a9a',3,3,10,1);R(x,'#3a5a9a',3,5,14,1);R(x,'#9a3a3a',20,3,8,6);R(x,'#e8ecea',21,4,6,4);R(x,'#3a5a9a',4,8,7,1);R(x,'#707474',2,12,30,2);}});
def('labsink',{w:16,h:22,box:[-7,-11,14,11],draw(x){R(x,'#2b3033',1,4,14,8);R(x,'#5a6266',3,5,10,6);R(x,'#c0c6c9',7,1,2,5);R(x,'#d3d7d4',1,12,14,10);}});
def('panel',{w:12,h:20,box:[-5,-5,10,5],draw(x){R(x,'#5a6066',2,0,8,13);R(x,'#6e757b',2,0,8,1);R(x,'#1a6a3a',3,3,2,2);R(x,'#c0a03a',6,3,2,2);R(x,'#101315',3,7,6,3);R(x,'#3a3e42',5,13,2,7);}});
def('tank',{w:84,h:84,box:[-36,-76,72,68],dyn:true,draw(x){x.fillStyle='#5b5f62';x.beginPath();x.arc(42,42,41,0,7);x.fill();x.fillStyle='#6c7073';x.beginPath();x.arc(42,41,40,Math.PI,0);x.fill();x.fillStyle='#46494c';x.beginPath();x.arc(42,42,37,0,7);x.fill();x.fillStyle='#14201f';x.beginPath();x.arc(42,42,35,0,7);x.fill();x.fillStyle='#1b2c2a';x.beginPath();x.arc(42,42,30,0,7);x.fill();x.fillStyle='#46494c';x.beginPath();x.arc(42,42,5,0,7);x.fill();}});
// --- shop ---
const GOODS=['#b04a3a','#d9c060','#4a7a5a','#3a5a8a','#e0e0d0','#8a4a7a','#d07a3a','#5a8aa0'];
def('gondola',{w:34,h:24,box:[-16,-14,32,13],draw(x,o){const v=o.v||'full',fill=v==='full'?.95:v==='half'?.45:v==='empty'?.06:.15;R(x,'#5a5e62',1,4,32,16);R(x,'#7a7e82',1,4,32,1);R(x,'#3a3e42',1,11,32,2);
 for(const y of[5,13])for(let i=2;i<32;i+=3)if(Math.random()<fill){R(x,pick(GOODS),i,y,2,5);R(x,'rgba(255,255,255,.2)',i,y,2,1);}
 if(v==='looted')for(let i=0;i<5;i++)R(x,pick(GOODS),((Math.random()*30)|0),20+((Math.random()*3)|0),2,2);R(x,'#3a3e42',1,20,32,2);}});
def('wshelf',{w:16,h:24,box:[-8,-8,16,8],draw(x,o){const v=o.v||'full',fill=v==='full'?.95:v==='half'?.45:.08;R(x,'#4c5054',0,0,16,24);for(let s=0;s<3;s++){R(x,'#6a6e72',0,6+s*6,16,1);for(let i=1;i<15;i+=3)if(Math.random()<fill)R(x,pick(GOODS),i,2+s*6,2,4);}R(x,'#2a2d30',0,22,16,2);}});
def('scounter',{w:36,h:22,box:[-17,-11,34,11],draw(x,o){R(x,'#3a3226',1,2,34,8);R(x,'#4a4030',1,2,34,1);R(x,'#5a4a36',1,10,34,12);R(x,'#4a3c2a',1,10,34,1);R(x,'#1a1c1e',22,0,9,6);R(x,o.on?'#5a8a6a':'#0e1012',23,1,7,3);R(x,'#c8c4b8',6,4,8,3);}});
def('dfridge',{w:16,h:30,box:[-7,-8,14,8],draw(x,o){R(x,'#2a2e33',0,0,16,30);R(x,o.on?'#d8eef4':'#121820',2,2,12,25);for(let i=0;i<4;i++){R(x,o.on?'#9ab0b8':'#1a2028',2,7+i*6,12,1);if(o.v!=='empty')for(let j=0;j<5;j++)if(Math.random()<(o.v==='half'?.4:.9))R(x,pick(['#c03a2a','#3a7aba','#e8e8e0','#3a9a5a','#d8a03a']),3+j*2,3+i*6,1,4);}R(x,'#555a60',13,10,1,8);}});
def('news',{w:14,h:16,box:[-6,-5,12,5],draw(x){R(x,'#3a3d40',1,4,12,12);R(x,'#e8e4d8',2,1,10,6);R(x,'#2a2a2a',3,2,8,1);R(x,'#c03a2a',3,4,4,2);}});
def('telly',{w:22,h:16,wall:true,draw(x){R(x,'#121316',0,0,22,14);R(x,'#3a4a5a',1,1,20,11);R(x,'#5a6a7a',2,2,8,4);R(x,'#c03a2a',2,9,18,2);R(x,'#2a2a2e',9,14,4,2);}});
const PIMG={};
function propImg(name,o){const k=name+'|'+(o.v||'')+'|'+(o.c||0)+'|'+(o.on?1:0)+'|'+(o.occ?1:0)+(o.dead?'d':'')+(o.dirty?'x':'');if(PIMG[k])return PIMG[k];const d=PROP[name];const [c,x]=mkC(d.w,d.h);d.draw(x,o);PIMG[k]=c;return c;}

// ================= CHARACTERS =================
const STY={
 rowan:{skin:'#c79b7d',hair:'#3b2a22',hs:'short',coat:'#3d4b44',coat2:'#2f3a35',pants:'#262a31',shoe:'#141619',scarf:'#7a3a32'},
 priya:{skin:'#9c6b4e',hair:'#191311',hs:'long',coat:'#e2e5e2',coat2:'#bfc4c0',pants:'#2a2f3a',shoe:'#1c1c1c'},
 dev:{skin:'#b07e5e',hair:'#14100e',hs:'short',coat:'#e2e5e2',coat2:'#bfc4c0',pants:'#34404d',shoe:'#2a2a2a'},
 gary:{skin:'#d8ab90',hair:'#8a8a86',hs:'bald',coat:'#d1a028',coat2:'#a97e1c',pants:'#2b3340',shoe:'#1a1a1a',hivis:1},
 tunde:{skin:'#5b3a29',hair:'#121212',hs:'short',coat:'#7a2f2b',coat2:'#5e2420',pants:'#2b2b30',shoe:'#1a1a1a'},
 okafor:{skin:'#6a4532',hair:'#d9d4cc',hs:'bun',coat:'#6b5a7a',coat2:'#54465f',pants:'#3a3340',shoe:'#2a2020'},
 lena:{skin:'#e0b49a',hair:'#a5652e',hs:'pony',coat:'#4a6b8a',coat2:'#3a566f',pants:'#2a2e3a',shoe:'#e0e0e0',baby:1},
 police:{skin:'#d3a588',hair:'#2a2a2a',hs:'hat',coat:'#1b222e',coat2:'#12171f',pants:'#151a22',shoe:'#0e0e0e',hivis:2},
 police2:{skin:'#8a5a40',hair:'#2a2a2a',hs:'hat',coat:'#1b222e',coat2:'#12171f',pants:'#151a22',shoe:'#0e0e0e',hivis:2},
 soldier:{skin:'#c4977a',hair:'#3a3a2a',hs:'helmet',coat:'#4b533b',coat2:'#3c432f',pants:'#43493a',shoe:'#1e1e1a'},
 jogger:{skin:'#d6ad94',hair:'#5a3a22',hs:'short',coat:'#2f5e8a',coat2:'#244a6e',pants:'#1a1c20',shoe:'#e8e8e8'},
 para:{skin:'#b88468',hair:'#2a2a2a',hs:'short',coat:'#2c6a4a',coat2:'#22553a',pants:'#22553a',shoe:'#111',hivis:1},
 p1:{skin:'#d9b096',hair:'#6a4a2a',hs:'short',coat:'#5a4a3a',coat2:'#46392c',pants:'#2a2e36',shoe:'#1a1a1a'},
 p2:{skin:'#7a5038',hair:'#121212',hs:'long',coat:'#2a3a4a',coat2:'#1f2c38',pants:'#1e2228',shoe:'#3a2a2a'},
 p3:{skin:'#e4c0a6',hair:'#c8a060',hs:'pony',coat:'#8a3a4a',coat2:'#6c2e3a',pants:'#2a2a30',shoe:'#e0e0e0'},
 p4:{skin:'#a8785a',hair:'#3a2a1a',hs:'hood',coat:'#3a3e44',coat2:'#2c3035',pants:'#25282d',shoe:'#d0d0d0'},
 p5:{skin:'#c8a080',hair:'#9a9a9a',hs:'cap',coat:'#4a5a3a',coat2:'#3a472d',pants:'#3a3a3a',shoe:'#1a1a1a'},
 t1:{skin:'#b8876a',hair:'#2a1a12',hs:'hood',coat:'#4a3a5a',coat2:'#3a2d47',pants:'#22252a',shoe:'#c8c8c8'},
 t2:{skin:'#6a4430',hair:'#101010',hs:'short',coat:'#5a3a2a',coat2:'#472d20',pants:'#2a2a30',shoe:'#1a1a1a'},
 t3:{skin:'#e2bea4',hair:'#c89a5a',hs:'long',coat:'#2a4a3a',coat2:'#20392c',pants:'#2a2e3a',shoe:'#e0e0e0'},
};
const HIMG={};
function human(st,dir,pose,fr,o={}){
 const key=st+dir+pose+fr+(o.smile?'s':'')+(o.closed?'c':'')+(o.dead?'d':'')+(o.weapon||'');
 if(HIMG[key])return HIMG[key];
 const S=Object.assign({},STY[st]||STY.p1);
 if(o.dead){S.skin='#7f887a';}
 const [c,x]=mkC(16,24);
 const flip=dir===2,d=dir===2?1:dir;
 if(pose==='lie'){HIMG[key]=lying(S,o);return HIMG[key];}
 const sit=pose==='sit';
 const bob=(pose==='walk'&&(fr===1||fr===3))?1:0;
 const Y=bob+(sit?3:0);
 // legs
 if(!sit){
  let l1=0,l2=0;if(pose==='walk'){if(fr===1)l1=-1;if(fr===3)l2=-1;}
  if(d===1){const a=pose==='walk'?(fr===1?-1:fr===3?1:0):0;R(x,S.pants,6+a,17+Y,2,5-Y);R(x,S.pants,8-a,17+Y,2,5-Y);R(x,S.shoe,5+a,22,3,2);R(x,S.shoe,7-a,22,3,2);}
  else{R(x,S.pants,5,17+Y,2,5+l1-Y);R(x,S.pants,9,17+Y,2,5+l2-Y);R(x,S.shoe,5,22+l1,2,2);R(x,S.shoe,9,22+l2,2,2);}
 }else{R(x,S.pants,5,19,6,2);R(x,S.pants,5,21,2,1);R(x,S.pants,9,21,2,1);R(x,S.shoe,5,22,2,2);R(x,S.shoe,9,22,2,2);}
 // torso
 if(d===1){R(x,S.coat,5,9+Y,6,9);R(x,S.coat2,10,9+Y,1,9);}else{R(x,S.coat,4,9+Y,8,9);R(x,S.coat2,11,9+Y,1,9);R(x,S.coat2,4,17+Y,8,1);}
 if(S.hivis===1){R(x,'#e0e050',4,13+Y,8,1);R(x,'#e0e050',4,15+Y,8,1);}
 if(S.hivis===2){R(x,'#c8d040',d===1?5:4,10+Y,d===1?6:8,4);R(x,'#9aa030',d===1?5:4,13+Y,d===1?6:8,1);}
 if(st==='rowan'&&d!==3){R(x,S.scarf,d===1?5:5,9+Y,d===1?5:6,2);}
 if(d===0&&(st==='priya'||st==='dev')){R(x,'#9ab0c8',7,10+Y,2,5);}
 // arms
 let a1=0,a2=0;if(pose==='walk'){if(fr===1){a1=1;a2=-1;}if(fr===3){a1=-1;a2=1;}}
 if(pose==='swing'){if(d===0){R(x,S.coat2,3,10+Y,2,5);R(x,S.coat,11,13+Y,2,6);R(x,S.skin,11,19+Y,2,2);}else if(d===3){R(x,S.coat2,3,8+Y,2,5);R(x,S.coat,11,8+Y,2,4);R(x,S.skin,11,6+Y,2,2);}else{R(x,S.coat2,2,11+Y,6,2);R(x,S.skin,0,11+Y,2,2);}}
 else if(d===1){R(x,S.coat2,7+a1,10+Y,2,6);R(x,S.skin,7+a1,16+Y,2,1);}
 else if(!sit){R(x,S.coat2,3,10+Y+a1,1,6);R(x,S.coat,2,10+Y+a1,1,6);R(x,S.skin,2,16+Y+a1,2,1);R(x,S.coat2,12,10+Y+a2,2,6);R(x,S.skin,12,16+Y+a2,2,1);}
 else{R(x,S.coat2,3,11+Y,2,5);R(x,S.coat2,11,11+Y,2,5);R(x,S.skin,5,16+Y,2,1);R(x,S.skin,9,16+Y,2,1);}
 if(S.baby&&d!==3){R(x,'#e8e0d0',5,11+Y,6,4);R(x,'#e8c4a8',6,11+Y,3,2);}
 // head
 const hx=5,hy=2+Y+(sit&&o.closed?1:0);
 R(x,S.skin,hx,hy+1,6,6);R(x,S.skin,hx+1,hy,4,1);R(x,S.skin,7,hy+7,2,1);
 const hs=S.hs;
 if(d===3){R(x,S.hair,hx,hy,6,6);R(x,S.hair,hx+1,hy-1,4,1);if(hs==='long')R(x,S.hair,hx,hy+6,6,3);if(hs==='bald'){R(x,S.skin,hx+1,hy,4,4);}}
 else{
  if(hs==='short'||hs==='pony'||hs==='long'||hs==='bun'){R(x,S.hair,hx,hy-1,6,2);R(x,S.hair,hx+1,hy-2,4,1);if(d===0){R(x,S.hair,hx,hy+1,1,2);R(x,S.hair,hx+5,hy+1,1,2);}else{R(x,S.hair,hx+3,hy,3,4);}}
  if(hs==='long'){if(d===0){R(x,S.hair,hx-1,hy,1,8);R(x,S.hair,hx+6,hy,1,8);}else R(x,S.hair,hx+4,hy,3,8);}
  if(hs==='pony'&&d===1)R(x,S.hair,hx+6,hy+1,2,4);
  if(hs==='bun'){R(x,S.hair,hx+2,hy-3,2,2);}
  if(hs==='bald'){R(x,S.hair,hx,hy+2,1,2);R(x,S.hair,hx+5,hy+2,1,2);}
  if(hs==='hat'){R(x,'#14171c',hx-1,hy-2,8,3);R(x,'#c8c8c8',hx,hy-1,6,1);R(x,'#0a0c0f',hx-1,hy+1,8,1);}
  if(hs==='helmet'){R(x,'#3c432f',hx-1,hy-2,8,4);R(x,'#4b533b',hx,hy-2,6,1);}
  if(hs==='hood'){R(x,S.coat,hx-1,hy-2,8,3);R(x,S.coat,hx-1,hy,1,7);R(x,S.coat,hx+6,hy,1,7);}
  if(hs==='cap'){R(x,'#2a2e34',hx,hy-2,6,2);R(x,'#2a2e34',d===1?hx-2:hx,hy,d===1?3:6,1);}
  if(hs==='beanie'){R(x,S.hat||'#3a2a2a',hx-1,hy-2,8,4);}
  // face
  const ec=o.closed?'#8a6a5a':(o.dead?'#2a2e2a':'#1a1412');
  if(d===0){if(o.closed){R(x,ec,hx+1,hy+3,2,1);R(x,ec,hx+3,hy+3,2,1);}else{R(x,ec,hx+1,hy+3,1,1);R(x,ec,hx+4,hy+3,1,1);}
   if(o.smile){R(x,'#7a4038',hx+1,hy+4,1,1);R(x,'#7a4038',hx+2,hy+5,2,1);R(x,'#7a4038',hx+4,hy+4,1,1);}
   else if(o.dead){R(x,'#3a3a3a',hx+2,hy+5,2,1);}}
  else{R(x,ec,hx+1,hy+3,1,1);R(x,S.skin,hx-1,hy+3,1,1);if(o.smile)R(x,'#7a4038',hx,hy+5,2,1);}
 }
 if(S.beard&&!o.dead&&d!==3){if(d===0){R(x,S.beard,hx,hy+4,1,2);R(x,S.beard,hx+5,hy+4,1,2);R(x,S.beard,hx+1,hy+5,4,2);}else R(x,S.beard,hx,hy+4,3,3);}
 if(o.weapon&&pose!=='swing'){const wc=o.weapon==='pipe'?'#6a6e72':'#8a8e92';if(d===0)R(x,wc,13,12+Y,1,8);else if(d===1)R(x,wc,6,13+Y,1,7);else if(d===3)R(x,wc,3,6+Y,1,8);}
 if(flip){const [c2,x2]=mkC(16,24);x2.translate(16,0);x2.scale(-1,1);x2.drawImage(c,0,0);HIMG[key]=c2;return c2;}
 HIMG[key]=c;return c;
}
function lying(S,o){const [c,x]=mkC(24,12);
 R(x,S.shoe,22,4,2,2);R(x,S.shoe,22,7,2,2);R(x,S.pants,16,4,6,2);R(x,S.pants,16,7,6,2);R(x,S.coat,7,3,10,7);R(x,S.coat2,7,9,10,1);R(x,S.coat2,9,2,6,1);R(x,S.coat2,9,10,6,1);R(x,S.skin,12,1,2,1);R(x,S.skin,12,10,2,1);
 R(x,S.skin,1,3,6,6);R(x,S.hair,0,3,2,6);R(x,S.hair,1,2,4,1);
 if(o.dead){R(x,'#2a2e2a',4,4,1,1);R(x,'#2a2e2a',4,7,1,1);R(x,'#3a3a3a',6,5,1,2);R(x,'rgba(40,10,10,.5)',7,9,6,3);}
 else{R(x,'#8a6a5a',3,4,2,1);R(x,'#8a6a5a',3,7,2,1);if(o.smile){R(x,'#7a4038',6,4,1,1);R(x,'#7a4038',6,5,1,2);R(x,'#7a4038',6,7,1,1);}}
 return c;}
// --- the Hollowed ---
const HOLLOW=[];
function buildHollow(){
 for(let f=0;f<6;f++){const [c,x]=mkC(20,30);const r=RNG(900+f);
  const lunge=f>=4;const j=()=>((r()*3)|0)-1;
  x.fillStyle='#050607';
  // legs
  R(x,'#050607',7+j(),20,2,9);R(x,'#050607',11+j(),20,2,9);
  // torso, hunched
  for(let y=8;y<21;y++){const w=lunge?6:5+((y>14)?1:0);R(x,'#060708',10-((w/2)|0)+(lunge?-(20-y)/5|0:0),y,w,1);}
  // arms long
  if(lunge){R(x,'#050607',2,10,8,2);R(x,'#050607',1,12,3,1);R(x,'#050607',12,11,7,2);R(x,'#050607',17,13,3,1);}
  else{R(x,'#050607',5+j(),10,2,13);R(x,'#050607',13+j(),10,2,13);R(x,'#050607',4,22,2,3);R(x,'#050607',14,22,2,3);}
  // head tilted
  const hx=lunge?6:8+j(),hy=2+((r()*2)|0);R(x,'#060708',hx,hy,5,6);R(x,'#060708',hx+1,hy-1,3,1);R(x,'#060708',hx+1,hy+6,3,2);
  // rim light
  for(let i=0;i<14;i++){R(x,'#1a1d22',hx-1+((r()*1)|0),hy+((r()*20)|0),1,1);}
  R(x,'#22262c',hx,hy,1,4);R(x,'#1b1e23',8,9,1,10);
  // rags
  for(let i=0;i<7;i++)R(x,'#08090b',6+((r()*9)|0),18+((r()*6)|0),1,2+((r()*3)|0));
  // eyes
  R(x,'#e8e2d4',hx+1,hy+3,1,1);R(x,'#e8e2d4',hx+3,hy+3,1,1);if(f%2)R(x,'#fff6e6',hx+1,hy+3,1,1);
  HOLLOW.push(c);}
}
// --- dog ---
const DIMG={};
function dog(dir,pose,fr){const key=dir+pose+fr;if(DIMG[key])return DIMG[key];
 const [c,x]=mkC(20,14);const B='#7b5735',B2='#5f4128',L='#a07a52',W='#d9d0c0';
 const sit=pose==='sit',gr=pose==='growl';
 // body
 if(sit){R(x,B,6,5,8,6);R(x,B2,10,4,5,7);R(x,W,5,6,2,3);R(x,B,6,11,2,3);R(x,B2,11,11,4,3);}
 else{R(x,B,4,5,11,5);R(x,B2,4,9,11,1);R(x,L,6,9,7,1);R(x,W,3,6,2,3);
  const l=pose==='walk'?(fr%2?1:0):0;R(x,B2,5,10,1,3-l);R(x,B2,7,10,1,2+l);R(x,B2,12,10,1,3-l);R(x,B2,14,10,1,2+l);}
 // tail
 if(gr){R(x,B2,15,7,4,1);}else if(sit){R(x,B2,15,10,3,1);}else{const t=fr%2;R(x,B2,15,4-t,1,2);R(x,B2,16,3-t,2,1);}
 // head
 const hy=gr?4:sit?1:2;R(x,B,0,hy+1,5,4);R(x,B,1,hy,4,1);R(x,B2,-1+1,hy+3,2,2);R(x,'#141010',0,hy+3,1,1);R(x,B2,3,hy-1,2,3);R(x,'#141010',2,hy+1,1,1);
 if(gr){R(x,'#f0ece0',1,hy+5,2,1);}
 if(dir===2){const [c2,x2]=mkC(20,14);x2.translate(20,0);x2.scale(-1,1);x2.drawImage(c,0,0);DIMG[key]=c2;return c2;}
 DIMG[key]=c;return c;}

// ================= ICONS =================
const ICON={};
const ICONDRAW={
 water(x){R(x,'#cfe6f2',6,1,4,2);R(x,'#3a7aba',6,3,4,1);R(x,'rgba(150,200,230,.85)',4,4,8,11);R(x,'#e8f6fc',5,5,1,8);R(x,'#3a7aba',4,8,8,3);},
 crisps(x){R(x,'#b8302a',3,2,10,12);R(x,'#d8483a',3,2,10,1);R(x,'#e8c050',5,6,6,4);R(x,'#8a1f1a',3,13,10,1);},
 beans(x){R(x,'#9aa0a4',4,3,8,11);R(x,'#3a6aba',4,5,8,6);R(x,'#d8603a',6,7,4,2);R(x,'#c0c6c9',4,3,8,1);},
 choc(x){R(x,'#5a2a6a',2,5,12,6);R(x,'#7a3a8a',2,5,12,1);R(x,'#d8c8a0',5,7,6,2);},
 bread(x){R(x,'#c08a4a',2,5,12,8);R(x,'#d8a060',3,4,10,2);R(x,'#e8c890',4,6,8,5);},
 pastry(x){R(x,'#c8883a',3,6,10,6);R(x,'#e0a85a',4,5,8,2);R(x,'#a86a2a',5,8,6,1);},
 pills(x){R(x,'#d8dcdf',3,4,10,8);for(let i=0;i<3;i++)for(let j=0;j<2;j++)R(x,'#ffffff',4+i*3,5+j*3,2,2);},
 bandage(x){R(x,'#e8e2d4',2,6,12,4);R(x,'#c8c2b4',2,9,12,1);R(x,'#c03a2a',7,6,2,4);},
 batt(x){R(x,'#2a2a2a',4,3,4,11);R(x,'#c8a03a',4,3,4,3);R(x,'#888',5,2,2,1);R(x,'#2a2a2a',9,3,4,11);R(x,'#c8a03a',9,3,4,3);R(x,'#888',10,2,2,1);},
 torch(x){R(x,'#2a2e33',3,7,9,3);R(x,'#3a3f45',11,6,3,5);R(x,'#f4e0a0',14,7,1,3);R(x,'#c03a2a',6,7,1,1);},
 crowbar(x){R(x,'#7a2a24',2,13,2,2);for(let i=0;i<11;i++)R(x,'#8a8e92',3+i,13-i,2,1);R(x,'#8a8e92',13,2,2,2);R(x,'#8a8e92',12,1,1,1);},
 knife(x){R(x,'#2a2220',3,10,5,3);for(let i=0;i<7;i++)R(x,'#c8ccd0',8+i,9-((i/2)|0),1,2);},
 treats(x){R(x,'#c8a03a',3,3,10,11);R(x,'#e8c050',3,3,10,1);R(x,'#7a5236',6,7,4,3);},
 inhaler(x){R(x,'#3a6aba',5,3,5,9);R(x,'#9aa0a4',4,11,7,3);R(x,'#5a8ada',5,3,5,1);},
 idcard(x){R(x,'#e8e4d8',2,4,12,9);R(x,'#3a5a8a',2,4,12,2);R(x,'#c8a080',3,7,4,4);R(x,'#7a7a7a',8,7,5,1);R(x,'#7a7a7a',8,9,4,1);},
 ring(x){x.strokeStyle='#d8b84a';x.lineWidth=2;x.beginPath();x.arc(8,9,4,0,7);x.stroke();R(x,'#f0e0a0',6,5,2,1);},
 photo(x){R(x,'#e8e4d8',2,3,12,10);R(x,'#7a9ab0',3,4,10,6);R(x,'#c8b080',3,8,10,2);R(x,'#3a2a22',5,6,2,3);R(x,'#6a4a3a',9,6,2,3);},
 notebook(x){R(x,'#3a2a22',3,2,10,12);R(x,'#5a3a2a',3,2,10,1);R(x,'#e8e2d0',12,3,1,10);R(x,'#c03a2a',5,2,1,12);},
 tea(x){R(x,'#e8e8e4',4,5,7,8);R(x,'#7a4a2a',5,6,5,2);R(x,'#e8e8e4',11,7,2,3);},
 fist(x){R(x,'#c79b7d',4,5,8,7);R(x,'#a77a60',4,8,8,1);R(x,'#a77a60',6,5,1,3);R(x,'#a77a60',9,5,1,3);},
 phone(x){R(x,'#101215',5,2,6,12);R(x,'#3a5a7a',6,3,4,9);},
 key(x){x.strokeStyle='#c8a85a';x.lineWidth=2;x.beginPath();x.arc(5,8,3,0,7);x.stroke();R(x,'#c8a85a',8,7,6,2);R(x,'#c8a85a',12,9,1,2);},
};
function buildIcons(){for(const k in ICONDRAW){const [c,x]=mkC(16,16);ICONDRAW[k](x);ICON[k]=c.toDataURL();}}
