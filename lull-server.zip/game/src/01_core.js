'use strict';
// ================= CORE =================
const W=480,H=270,TS=16;
const $=s=>document.querySelector(s);
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const lerp=(a,b,t)=>a+(b-a)*t;
const rand=(a=1,b)=>b===undefined?Math.random()*a:a+Math.random()*(b-a);
const irand=(a,b)=>Math.floor(a+Math.random()*(b-a+1));
const pick=a=>a[(Math.random()*a.length)|0];
const dist=(ax,ay,bx,by)=>Math.hypot(ax-bx,ay-by);
const RNG=seed=>{let a=seed>>>0;return()=>{a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};};
const hashStr=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;};
function mkC(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.imageSmoothingEnabled=false;return [c,x];}
function store(k,v){try{if(v===undefined){const s=localStorage.getItem(k);return s?JSON.parse(s):null;}localStorage.setItem(k,JSON.stringify(v));return true;}catch(e){return null;}}
function storeDel(k){try{localStorage.removeItem(k);}catch(e){}}
const GLY='█▓▒░#%&@$?/\\|~';
function corrupt(s,amt){let o='';for(const ch of s){if(ch!==' '&&Math.random()<amt)o+=Math.random()<.5?pick(GLY):ch+String.fromCharCode(0x0300+irand(0,40));else o+=ch;}return o;}

// ================= INPUT =================
const Input={down:new Set(),pressed:new Set(),
 map:{up:['KeyW','ArrowUp'],down:['KeyS','ArrowDown'],left:['KeyA','ArrowLeft'],right:['KeyD','ArrowRight'],
  attack:['Space','KeyJ'],interact:['KeyE','KeyK','Enter'],sprint:['ShiftLeft','ShiftRight'],dodge:['KeyQ','KeyL'],
  torch:['KeyF'],inv:['KeyI','Tab'],note:['KeyN'],pause:['Escape','KeyP'],
  s1:['Digit1'],s2:['Digit2'],s3:['Digit3'],s4:['Digit4'],s5:['Digit5'],drop:['KeyX'],ok:['KeyE','Enter','Space','KeyK']},
 is(a){return this.map[a].some(k=>this.down.has(k));},
 hit(a){return this.map[a].some(k=>this.pressed.has(k));},
 eat(a){this.map[a].forEach(k=>this.pressed.delete(k));},
 any(){return this.pressed.size>0;},
 clear(){this.pressed.clear();},
 end(){this.pressed.clear();}};
addEventListener('keydown',e=>{
 if(e.target&&(e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA'))return;
 if(['Space','Tab','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();
 if(!e.repeat)Input.pressed.add(e.code);
 Input.down.add(e.code);Snd.unlock();
});
addEventListener('keyup',e=>Input.down.delete(e.code));
addEventListener('blur',()=>{if(document.activeElement&&document.activeElement.tagName==='INPUT')return;Input.down.clear();if(typeof G!=='undefined'&&G.state==='play'&&!G.lull)UI.pause();});

// ================= AUDIO =================
const Snd={ctx:null,beds:{},music:null,
 unlock(){
  if(this.ctx){if(this.ctx.state==='suspended')this.ctx.resume();return;}
  const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
  try{this.ctx=new C();}catch(e){return;}
  const c=this.ctx;
  this.master=c.createGain();this.master.gain.value=.85;
  const comp=c.createDynamicsCompressor();comp.threshold.value=-14;
  this.master.connect(comp).connect(c.destination);
  this.bus=c.createGain();this.bus.connect(this.master);
  // simple echo send
  this.send=c.createGain();this.send.gain.value=.35;
  const d=c.createDelay(1);d.delayTime.value=.27;const fb=c.createGain();fb.gain.value=.38;const lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.value=1700;
  this.send.connect(d);d.connect(lp).connect(fb).connect(d);lp.connect(this.master);
  this.nb=this.mkNoise(3);
  this.mkBeds();
  if(this.want)for(const k in this.want)this.set(k,this.want[k],.1);
 },
 mkNoise(s){const c=this.ctx,b=c.createBuffer(1,c.sampleRate*s,c.sampleRate),d=b.getChannelData(0);let l=0;for(let i=0;i<d.length;i++){const w=Math.random()*2-1;l=(l+.02*w)/1.02;d[i]=w*.6+l*3;}return b;},
 nsrc(){const s=this.ctx.createBufferSource();s.buffer=this.nb;s.loop=true;return s;},
 mkBeds(){
  const c=this.ctx,B=this.beds;
  const g=v=>{const n=c.createGain();n.gain.value=v;n.connect(this.master);return n;};
  // rain
  B.rain=g(0);{const s=this.nsrc(),f=c.createBiquadFilter();f.type='bandpass';f.frequency.value=1900;f.Q.value=.35;const h=c.createBiquadFilter();h.type='highpass';h.frequency.value=380;s.connect(f).connect(h).connect(B.rain);s.start();}
  // wind
  B.wind=g(0);{const s=this.nsrc(),f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=320;f.Q.value=2;const l=c.createOscillator();l.frequency.value=.09;const lg=c.createGain();lg.gain.value=180;l.connect(lg).connect(f.frequency);l.start();s.connect(f).connect(B.wind);s.start(.5);}
  // room tone
  B.room=g(0);{const s=this.nsrc(),f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=160;s.connect(f).connect(B.room);s.start(1);}
  // drone
  B.drone=g(0);{const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=300;f.Q.value=5;this.droneF=f;
   this.droneO=[[49,'sawtooth'],[49.35,'sawtooth'],[73.4,'sine'],[98.2,'triangle']].map(([fr,t])=>{const o=c.createOscillator();o.type=t;o.frequency.value=fr;o.connect(f);o.start();return o;});
   const l=c.createOscillator();l.frequency.value=.05;const lg=c.createGain();lg.gain.value=140;l.connect(lg).connect(f.frequency);l.start();f.connect(B.drone);}
  // hum
  B.hum=g(0);{const tr=c.createGain();tr.gain.value=.75;const l=c.createOscillator();l.frequency.value=.43;const lg=c.createGain();lg.gain.value=.25;l.connect(lg).connect(tr.gain);l.start();
   this.humO=[[57.8,1],[115.7,.42],[173.3,.2],[231.9,.08],[347,.03]].map(([fr,a])=>{const o=c.createOscillator();o.frequency.value=fr;const og=c.createGain();og.gain.value=a;o.connect(og).connect(tr);o.start();return o;});
   tr.connect(B.hum);}
  // fluorescent buzz
  B.buzz=g(0);{const o=c.createOscillator();o.type='sawtooth';o.frequency.value=100;const f=c.createBiquadFilter();f.type='bandpass';f.frequency.value=2400;f.Q.value=8;o.connect(f).connect(B.buzz);o.start();}
  // fire crackle bed
  B.fire=g(0);{const s=this.nsrc(),f=c.createBiquadFilter();f.type='bandpass';f.frequency.value=700;f.Q.value=.8;s.connect(f).connect(B.fire);s.start(2);}
  // static
  B.static=g(0);{const s=this.nsrc(),f=c.createBiquadFilter();f.type='highpass';f.frequency.value=1200;s.connect(f).connect(B.static);s.start(.2);}
 },
 set(name,v,t=1.2){
  if(!this.ctx){(this.want=this.want||{})[name]=v;return;}
  const b=this.beds[name];if(!b)return;const n=this.ctx.currentTime;b.gain.cancelScheduledValues(n);b.gain.setTargetAtTime(v,n,Math.max(.01,t/3));
 },
 humPitch(k){if(!this.humO)return;const n=this.ctx.currentTime;this.humO.forEach((o,i)=>o.frequency.setTargetAtTime([57.8,115.7,173.3,231.9,347][i]*k,n,.5));},
 dronePitch(k){if(!this.droneO)return;const n=this.ctx.currentTime;this.droneO.forEach((o,i)=>o.frequency.setTargetAtTime([49,49.35,73.4,98.2][i]*k,n,1.5));},
 env(g,t0,a,peak,dec){g.gain.setValueAtTime(0,t0);g.gain.linearRampToValueAtTime(peak,t0+a);g.gain.exponentialRampToValueAtTime(.0001,t0+a+dec);},
 tone(f,dur,o={}){
  if(!this.ctx)return;const c=this.ctx,t0=c.currentTime+(o.delay||0);
  const os=c.createOscillator();os.type=o.type||'sine';os.frequency.setValueAtTime(f,t0);
  if(o.slide)os.frequency.exponentialRampToValueAtTime(Math.max(20,f*o.slide),t0+dur);
  if(o.detune)os.detune.value=o.detune;
  const g=c.createGain();this.env(g,t0,o.a||.005,o.vol||.2,dur);
  let node=os.connect(g);
  if(o.lp){const f2=c.createBiquadFilter();f2.type='lowpass';f2.frequency.value=o.lp;node=g.connect(f2);}
  if(o.pan!==undefined&&c.createStereoPanner){const p=c.createStereoPanner();p.pan.value=o.pan;node.connect(p);node=p;}
  node.connect(this.bus);if(o.echo)node.connect(this.send);
  os.start(t0);os.stop(t0+(o.a||.005)+dur+.05);
 },
 noise(dur,o={}){
  if(!this.ctx)return;const c=this.ctx,t0=c.currentTime+(o.delay||0);
  const s=c.createBufferSource();s.buffer=this.nb;
  const f=c.createBiquadFilter();f.type=o.ft||'bandpass';f.frequency.setValueAtTime(o.f||1000,t0);f.Q.value=o.q||1;
  if(o.slide)f.frequency.exponentialRampToValueAtTime(Math.max(30,(o.f||1000)*o.slide),t0+dur);
  const g=c.createGain();this.env(g,t0,o.a||.003,o.vol||.2,dur);
  let node=s.connect(f).connect(g);
  if(o.pan!==undefined&&c.createStereoPanner){const p=c.createStereoPanner();p.pan.value=o.pan;node.connect(p);node=p;}
  node.connect(this.bus);if(o.echo)node.connect(this.send);
  s.start(t0,Math.random()*2);s.stop(t0+dur+.1);
 },
 play(n,o={}){
  if(!this.ctx)return;
  switch(n){
  case 'step':{const s=o.s||'hard';const f={hard:900,road:700,soft:420,grass:520,wood:600,tile:1300,metal:1600,gravel:1100}[s]||900;this.noise(.06,{f:f*rand(.85,1.15),q:1.4,vol:(o.v||1)*(s==='soft'?.05:.085)});if(s==='metal')this.tone(rand(500,700),.05,{vol:.02,type:'triangle'});break;}
  case 'swing':this.noise(.16,{f:600,slide:3.5,q:1.2,vol:.13});break;
  case 'hit':this.noise(.12,{f:300,q:.8,vol:.35});this.tone(140,.14,{type:'triangle',slide:.5,vol:.22});break;
  case 'hitMetal':this.tone(820,.25,{type:'triangle',vol:.08,slide:.98});this.noise(.08,{f:2500,vol:.15});this.tone(140,.12,{type:'triangle',slide:.5,vol:.2});break;
  case 'hurt':this.noise(.18,{f:250,q:.6,vol:.35});this.tone(90,.25,{slide:.6,vol:.25});this.flashTone();break;
  case 'enemyHurt':this.noise(.14,{f:500,q:1,vol:.22});break;
  case 'pickup':this.tone(660,.08,{type:'triangle',vol:.08});this.tone(990,.12,{type:'triangle',vol:.06,delay:.06});break;
  case 'ui':this.tone(520,.04,{type:'square',vol:.025,lp:1800});break;
  case 'uiOk':this.tone(700,.06,{type:'square',vol:.03,lp:2000});this.tone(1050,.08,{type:'square',vol:.02,lp:2400,delay:.05});break;
  case 'type':this.tone(rand(900,1300),.012,{type:'square',vol:.006,lp:2500});break;
  case 'door':this.noise(.25,{f:180,q:.7,vol:.25});this.noise(.08,{f:1400,vol:.08,delay:.18});break;
  case 'kettle':this.noise(2.2,{f:2600,q:.5,vol:.05,a:1.6,slide:1.3});this.tone(2800,.4,{vol:.015,delay:1.9});this.tone(240,.06,{type:'square',vol:.04,lp:900,delay:2.4});break;
  case 'eat':for(let i=0;i<4;i++)this.noise(.05,{f:rand(1200,2200),q:2,vol:.07,delay:i*.13});break;
  case 'drink':for(let i=0;i<4;i++)this.tone(rand(280,360),.08,{vol:.06,slide:1.4,delay:i*.18});break;
  case 'torch':this.tone(1800,.02,{type:'square',vol:.04,lp:3000});this.noise(.02,{f:3000,vol:.05});break;
  case 'alarm':for(let i=0;i<6;i++){this.tone(880,.09,{type:'square',vol:.035,lp:2200,delay:i*.32});this.tone(880,.09,{type:'square',vol:.035,lp:2200,delay:i*.32+.12});}break;
  case 'ring':for(let i=0;i<(o.n||2);i++){const d=i*3;this.tone(400,.4,{vol:.05,delay:d,type:'sine'});this.tone(450,.4,{vol:.05,delay:d});this.tone(400,.4,{vol:.05,delay:d+.6});this.tone(450,.4,{vol:.05,delay:d+.6});}break;
  case 'buzz':for(let i=0;i<3;i++)this.noise(.18,{f:180,q:4,vol:.18,delay:i*.3});break;
  case 'beep':this.tone(1400,.12,{type:'sine',vol:.05});this.tone(1400,.12,{type:'sine',vol:.05,delay:.25});this.tone(1400,.12,{type:'sine',vol:.05,delay:.5});break;
  case 'glitch':{const n=irand(3,7);for(let i=0;i<n;i++)this.tone(rand(80,2400),rand(.02,.07),{type:pick(['square','sawtooth']),vol:.035,delay:i*.035});this.noise(.1,{f:rand(800,4000),q:6,vol:.08});break;}
  case 'whisper':{const p=rand(-.9,.9);for(let i=0;i<irand(4,8);i++)this.noise(rand(.08,.22),{f:rand(1400,3600),q:rand(4,9),vol:.05,delay:i*rand(.07,.16),pan:p,echo:true});break;}
  case 'heart':this.tone(58,.16,{vol:.32,slide:.7});this.tone(52,.18,{vol:.26,slide:.7,delay:.22});break;
  case 'sting':{[0,1,6,7,11].forEach((s,i)=>this.tone(110*Math.pow(2,s/12),2.6,{type:'sawtooth',vol:.035,a:.8,lp:1200,detune:rand(-12,12),echo:true}));this.noise(2.2,{f:300,q:.5,vol:.12,a:1.2,slide:3});break;}
  case 'bark':for(let i=0;i<2;i++){this.noise(.09,{f:900,q:1.5,vol:.18,delay:i*.28});this.tone(320,.09,{type:'sawtooth',slide:.6,vol:.08,lp:1400,delay:i*.28});}break;
  case 'growl':{const c=this.ctx,t0=c.currentTime,os=c.createOscillator();os.type='sawtooth';os.frequency.value=68;const am=c.createOscillator();am.frequency.value=23;const ag=c.createGain();ag.gain.value=.5;const g=c.createGain();this.env(g,t0,.15,.09,1.1);const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=600;am.connect(ag).connect(g.gain);os.connect(f).connect(g).connect(this.bus);os.start();am.start();os.stop(t0+1.4);am.stop(t0+1.4);break;}
  case 'whine':this.tone(900,.5,{vol:.03,slide:1.3,type:'sine'});this.tone(1000,.4,{vol:.03,slide:.8,type:'sine',delay:.5});break;
  case 'splash':this.noise(.5,{f:1200,q:.6,vol:.2,slide:.4});break;
  case 'tear':this.noise(.12,{f:3000,q:2,vol:.15});this.tone(4200,.6,{vol:.05,type:'sine',delay:.1});break;
  case 'siren':{for(let i=0;i<4;i++){this.tone(620,.55,{type:'triangle',vol:.03,slide:1.4,delay:i*1.1,lp:1500,echo:true});this.tone(870,.55,{type:'triangle',vol:.03,slide:.71,delay:i*1.1+.55,lp:1500,echo:true});}break;}
  case 'thud':this.tone(70,.3,{vol:.35,slide:.5});this.noise(.15,{f:200,vol:.2});break;
  case 'dodge':this.noise(.14,{f:900,slide:.4,q:.8,vol:.09});break;
  case 'death':this.tone(110,2.5,{type:'sawtooth',vol:.08,slide:.3,lp:600,echo:true});this.noise(1.5,{f:200,vol:.2,slide:.3});break;
  case 'shriek':this.noise(.4,{f:2200,q:3,vol:.12,slide:.6,pan:o.pan});this.tone(rand(500,700),.4,{type:'sawtooth',vol:.04,slide:1.5,lp:2000,pan:o.pan});break;
  case 'voice':{const p=o.pitch||1;this.tone(rand(180,260)*p,.08,{type:'triangle',vol:.03,lp:900});break;}
  case 'micro':this.tone(1200,.05,{type:'sine',vol:.03});this.noise(.4,{f:3000,q:2,vol:.03,a:.2});break;
  case 'flies':for(let i=0;i<5;i++)this.tone(rand(180,240),rand(.3,.7),{type:'sawtooth',vol:.008,lp:800,delay:i*.2,pan:rand(-1,1)});break;
  case 'box':this.mbox(o.f||440,o.v||.07,o.det||0);break;
  }
 },
 flashTone(){},
 mbox(f,v,det){if(!this.ctx)return;this.tone(f,1.6,{type:'triangle',vol:v,a:.004,detune:det,echo:true});this.tone(f*2,.6,{type:'sine',vol:v*.35,detune:det});this.tone(f*3.01,.25,{type:'sine',vol:v*.12,detune:det});},
 // music box sequencer
 seq:null,
 song(notes,bpm,o={}){this.seq={notes,i:0,t:0,step:60/bpm,det:0,detRate:o.detRate||0,loop:o.loop!==false,v:o.v||.07};},
 stopSong(){this.seq=null;},
 update(dt){const s=this.seq;if(!s||!this.ctx)return;s.t-=dt;s.det+=s.detRate*dt;
  if(s.t<=0){const n=s.notes[s.i];if(n!==null&&n!==undefined){const f=440*Math.pow(2,(n-69)/12);this.mbox(f,s.v,s.det+rand(-s.det*.3,s.det*.3));}
   s.t+=s.step;s.i++;if(s.i>=s.notes.length){if(s.loop)s.i=0;else this.seq=null;}}}
};
// original melodies (MIDI note numbers, null = rest)
const MEL_TITLE=[69,null,72,76,74,null,72,69,67,null,69,null,null,null,64,null,65,null,69,72,71,null,67,null,69,null,null,null,null,null,null,null];
const MEL_LULL=[72,76,79,76,74,77,81,77,72,76,79,84,83,79,76,null,74,77,81,77,72,76,79,76,74,71,67,71,72,null,null,null];
