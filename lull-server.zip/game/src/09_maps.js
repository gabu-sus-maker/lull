// ================= MAP BUILDERS =================
def('sofaB',{w:34,h:18,box:[-16,-10,32,10],draw(x){R(x,'#3d3243',0,3,34,13);R(x,'#55475c',2,3,30,2);R(x,'#4a3d51',2,5,30,9);R(x,'#3f3346',16,5,1,9);R(x,'#45394c',0,1,5,15);R(x,'#45394c',29,1,5,15);R(x,'#5d4f64',0,1,5,1);R(x,'#5d4f64',29,1,5,1);R(x,'#231c28',1,16,32,2);}});
const PH=()=>G.phase;
const is=(...a)=>a.includes(G.phase);
const AMB={dawn:{a:.52,c:'12,16,30'},day:{a:.3,c:'16,18,26'},grey:{a:.44,c:'18,20,26'},dusk:{a:.64,c:'22,12,24'},night:{a:.86,c:'5,7,15'},dark:{a:.95,c:'2,3,8'}};
// ---------------- FLAT ----------------
function buildFlat(){
 const m=new GMap('flat',24,12,T.void);
 m.ascii([
 'PPPQQPPPPPPPPPPPPQQPPQQP',
 'PccccccccPbbbbbPkkkkkkkP',
 'PccccccccPbbbbbPkkkkkkkP',
 'PccccccccPbbbbbPkkkkkkkP',
 'PccccccccPbbbbbPwwwwwwwP',
 'PccccccccPPPdPPPwwwwwwwP',
 'PccccccccPwwwwwwwwwwwwwQ',
 'PPPPdPPPPPwwwwwwwwwwwwwP',
 'PwwwwwwwwdwwwwwwwwwwwwwP',
 'PwwwwwwwwdwwwwwwwwwwwwwQ',
 'PwwwwwwwwPwwwwwwwwwwwwwP',
 'PPPPPPEPPPPPPPPPPPPPPPPP'],{P:'P',Q:'Q',c:'carpet',b:'btile',k:'ktile',w:'wood',d:'doorway',E:'exitP'});
 const ph=PH(),a2=ph==='a2_flat',a1=is('a1_flat','a2_flat'),night=is('d1_night','d3_night'),d3=is('d3_wake','d3_night');
 m.ambient=a2?{a:.74,c:'12,14,22'}:a1?AMB.dark:night?{a:.8,c:'8,8,16'}:d3?{a:.5,c:'16,18,24'}:{a:.46,c:'14,14,24'};
 m.snd={room:.05,rain:a1?.05:.04,drone:a1?.1:d3?.02:0};
 m.prop('rug',72,86);
 m.prop('bed',30,50,{v:a1?'a1':'',interact:I('Bed',S.flatBed)});
 m.prop('wardrobe',120,30,{interact:I('Wardrobe',S.flatWardrobe)});
 m.prop('plant',122,96);
 m.prop('bath',176,34);
 m.prop('mirror',216,16,{dyn:1});
 m.prop('sink',216,34,{interact:I('Mirror',S.flatMirror)});
 m.prop('toilet',232,66);
 m.prop('fridge',264,40,{v:a1?'a1':'',interact:I('Fridge',S.flatFridge)});
 m.prop('counter',280,40);
 m.prop('counter',296,40,{v:'sink',interact:I('Sink',S.flatSink)});
 m.prop('counter',312,40,{v:'kettle',interact:I(()=>G.flags['tea_'+ph]?'Kettle':'Make tea',S.flatKettle)});
 m.prop('counter',328,40,{v:'hob'});
 m.prop('counter',344,40,{v:'radio',interact:I('Radio',S.flatRadio)});
 m.prop('counter',360,40,{v:'drawer',interact:I(()=>a1&&!G.flags.torch?'Search the drawer':'Drawer',S.flatDrawer)});
 const bowl=m.prop('bowl',290,66,{v:G.flags.fed||!is('d1_wake')?'full':'',interact:is('d1_wake')?I(()=>G.flags.fed?'Bowl':'Feed Biscuit',S.feedDog):null});
 m.prop('dogbed',352,92);
 m.prop('table',312,94,{v:a1?'notes':'',interact:ph==='a1_flat'?I(()=>G.flags.notes_a1?'Table':'Pages on the table',S.flatNotes):null});
 m.prop('chair',294,90);m.prop('chair',330,90);
 m.prop('tv',184,108,{interact:I('Television',S.flatTV)});
 m.prop('shelf',226,108,{interact:I('Photograph',S.flatPhoto)});
 m.prop('ctable',184,138,{interact:I('Phone',S.flatPhone)});
 m.prop('sofaB',184,166);
 m.prop('lampF',252,110,{on:night});
 m.prop('plant',360,112);
 m.prop('toolbox',30,172,{interact:I(()=>a1&&!G.flags.crowbar?'Open the toolbox':'Toolbox',S.flatToolbox)});
 if(night)m.light(312,52,74,.75,'255,210,150');
 if(night&&!d3)m.light(52,34,40,.6,'255,200,140');
 const win=a2?['175,185,205',.5]:a1?['150,165,205',.22]:d3?['205,215,232',.7]:night?null:['255,232,200',.78];
 if(win){[[64,26],[296,26],[352,26]].forEach(([x,y])=>m.light(x,y,a1?60:96,win[1],win[0],{gk:.6}));m.light(366,104,a1?50:80,win[1]*.9,win[0],{gk:.6});m.light(366,152,a1?50:70,win[1]*.8,win[0],{gk:.6});
  if(!a1){const c=win[0];[[56,16],[288,16],[344,16]].forEach(([x,y])=>m.shafts.push({x,y,w:18,dx:26,dy:62,c,a:d3?.06:.1}));}}
 // dog
 const dogMode=is('d1_wake')?(G.flags.fed?'follow':'idle'):is('d1_night')?'idle':'hide';
 const dp=is('d1_wake')?[290,78]:is('d1_night')?[352,92]:[338,102];
 if(!a2){const dg=new Dog(dp[0],dp[1],{mode:dogMode,interact:I('Biscuit',S.petDog),idlePose:is('d1_night')?'sit':'sit'});m.ents.push(dg);G.dog=dg;}
 else{m.decals.push((c,ox,oy)=>{c.fillStyle='rgba(60,42,28,.55)';const pts=[[300,80],[290,96],[276,108],[262,122],[246,134],[226,146],[206,156],[180,162],[156,166],[132,168],[116,172],[106,180]];pts.forEach(([x,y],i)=>{const o=i%2?3:-3;c.fillRect(x+o-ox,y-oy,2,2);c.fillRect(x+o-1-ox,y-2-oy,1,1);c.fillRect(x+o+2-ox,y-2-oy,1,1);});});
  spot(m,tx(7),ty(10)-2,'Paper on the floor',S.a2Page);}
 spot(m,360,112,'Window',S.flatWindow);
 m.exit(6,11,'Front door',S.flatDoor);
 m.finalize();return m;
}
// ---------------- STREET ----------------
const HOUSE_DOOR=[[1,9],[4,9],[7,9],[10,9],[13,9],[16,9],[19,9],[22,9],[25,9],[28,9],[31,9],[34,9]];
function buildStreet(){
 const m=new GMap('street',64,40,T.pave);m.outdoor=true;
 const ph=PH(),a2=ph==='a2_street',a1=is('a1_street','title','a2_street'),night=is('d2_walk','a1_street','title'),dusk=ph==='d3_dusk',d1=ph==='d1_street',d3=is('d3_street','d3_dusk');
 m.rect(0,0,64,8,T.roof);
 // terraces x0..37 (12 houses x3)
 const r=RNG(42);
 for(let h=0;h<12;h++){const x0=h*3+0,yel=h%3===1;const lit=(id)=>{if(a1)return T[id];if(night||d1||dusk)return r()<.45?T.brickWinLit:T[id];return T[id];};
  m.set(x0,8,yel?T.brickWinY:lit('brickWin'));m.set(x0+1,8,yel?T.brickY:T.brick);m.set(x0+2,8,yel?T.brickWinY:lit('brickWin'));
  m.set(x0,9,h===3?T.brickDoor:(yel?T.brickDoorY:T.brickDoorX));m.set(x0+1,9,yel?T.brickY:T.brick);m.set(x0+2,9,yel?T.brickWinY:lit('brickWin'));}
 m.set(9,9,T.brickDoor);m.set(10,9,T.brick);
 // shop x38..44
 for(let x=38;x<=44;x++){m.set(x,8,T.shopSign);m.set(x,9,a1?T.shopFrontBroken:(night||dusk)&&!is('d2_walk')?T.shopFrontDark:T.shopFront);}
 m.set(42,9,a1?T.shopDoorBroken:T.shopDoor);
 for(let x=45;x<=54;x++){m.set(x,8,x%3?T.brick:T.brickWin);m.set(x,9,T.shutter);}
 for(let x=55;x<64;x++){m.set(x,8,T.stationF);m.set(x,9,T.stationF);}
 const shut=is('d3_street','d3_dusk','a1_street','title');
 m.set(59,9,shut?T.stationShut:T.stationIn);m.set(60,9,shut?T.stationShut:T.stationIn);
 // pavement / road
 for(let x=0;x<64;x++){m.set(x,11,T.paveCB);m.set(x,12,T.asphYelT);m.set(x,13,T.asph);m.set(x,14,T.asphDash);m.set(x,15,T.asph);m.set(x,16,T.asph);m.set(x,17,T.asphYelB);m.set(x,18,T.paveCT);m.set(x,20,T.fenceP);}
 m.rect(18,20,2,1,T.pave);m.rect(46,20,2,1,T.pave);
 m.rect(0,21,64,10,T.grass);m.rect(18,21,2,10,T.gravel);m.rect(46,21,2,10,T.gravel);m.rect(18,25,30,2,T.gravel);
 m.rect(0,31,64,1,T.gravel);m.rect(0,32,64,1,T.coping);m.rect(0,33,64,4,T.water);m.rect(0,37,64,1,T.copingT);m.rect(0,38,64,1,T.gravel);m.rect(0,39,64,1,T.hedge);
 m.rect(0,21,1,10,T.hedge);m.rect(63,21,1,10,T.hedge);
 // ambience
 m.ambient=a2?{a:.66,c:'14,16,22'}:a1?{a:.93,c:'3,4,10'}:night?AMB.night:dusk?AMB.dusk:d3?AMB.grey:{a:.5,c:'12,16,30'};
 m.rain=a2?.4:a1?.85:is('d2_walk')?.25:d1?.55:0;m.fog=a1?.055:d3?.07:.045;
 m.snd={rain:m.rain*.5,wind:a1?.12:.05,drone:a1?.12:d3?.03:0};
 if(dusk)m.grade={c:'rgba(255,140,90,.35)',op:'soft-light'};
 if(d3)m.grade={c:'rgba(120,130,140,.4)',op:'saturation'};
 // lamps
 const lampsOn=!d3||dusk;
 const lamp=(x,y,flick)=>{const on=a2?false:a1?!!flick:lampsOn;const p=m.prop('lamp',x,y,{on});if(on){const L=m.lights[m.lights.length-1];if(flick)L.flick=.7;if(d1){L.i=.7;}}};
 [6,26,38,52].forEach((t,i)=>lamp(tx(t),ty(19)-2,a1&&i===2));
 [14,30,50].forEach((t,i)=>lamp(tx(t),ty(10)-2,a1&&i===0));
 [10,30,52].forEach((t,i)=>lamp(tx(t),ty(31)-4,a1&&i===1));
 m.prop('shelter',tx(28),ty(19)-1);
 m.prop('phonebox',tx(35),ty(19)-2,{interact:I('Phone box',S.phoneBox)});
 m.prop('postbox',tx(12),ty(10)-2);
 m.prop('sign',tx(57),ty(10)-2);
 [[2,10],[8,10],[17,10],[23,10],[33,10],[46,10]].forEach(([x,y],i)=>m.prop('bin',tx(x)+4,ty(y)-3,{c:['#1e2a22','#22283a','#2a2a2a'][i%3],tip:a1&&i%2}));
 // trees, benches
 [[4,24],[10,28],[25,23],[33,29],[40,23],[55,25],[60,29],[14,22]].forEach(([x,y])=>m.prop('tree',tx(x),ty(y)));
 m.prop('bench',tx(8),ty(25)-4);
 const jb=m.prop('bench',tx(31),ty(31)-3);
 // parked cars
 const cars=[[4,13,0],[15,13,2],[22,13,4],[33,13,1],[49,13,5],[8,17,3],[26,17,6],[41,17,2],[55,17,0]];
 cars.forEach(([x,y,c],i)=>{if(a1&&i===4)return;const o={c,dirty:a1,occ:a1&&(i%3===0),dead:false};const p=m.prop('car',tx(x),ty(y)-2,o);
  if(a1&&o.occ)p.interact=I('Car',S.carSleeper);if(a1&&i===5)p.interact=I('Search the car',S.searchCar);});
 // per-phase dressing
 if(d1){
  m.prop('fruit',tx(40)+8,ty(10)-1);
  const t=npc(m,tx(41),ty(10)-4,'tunde',{watch:60,interact:I('Tunde',S.tunde1)});t.fixedDir=0;
  npc(m,tx(27),ty(19)-8,'p2',{fixedDir:0,barks:['…three on my cousin’s ward. Just didn’t wake up.','…peaceful, she said. Like they were dreaming.'],barkR:60,solid:true});
  npc(m,tx(29),ty(19)-8,'p5',{fixedDir:0,barks:['Bus is late again.'],barkR:50});
  [[ 'p1',[[tx(2),ty(10)-4],[tx(36),ty(10)-4]]],['p3',[[tx(50),ty(10)-4],[tx(16),ty(10)-4]]],['p4',[[tx(60),ty(19)-6],[tx(3),ty(19)-6]]],['p1',[[tx(10),ty(19)-6],[tx(58),ty(19)-6]]]].forEach(([s,path],i)=>{const e=npc(m,path[0][0]+i*40,path[0][1]-6,s,{path:path.map(p=>[p[0],p[1]-6,rand(.5,2)]),speed:rand(20,28),barks:i===1?['Morning.']:null,ghost:1,solid:false});});
  m.ents.push(new Vehicle(tx(-2),ty(13)-2,1,'bus'),new Vehicle(tx(30),ty(16)-2,-1,'car',3),new Vehicle(tx(60),ty(13)-2,1,'car',6));
 }
 if(is('d2_walk')){
  m.prop('ambulance',tx(22),ty(13)-1,{dyn:1,flash:1});Object.assign(m.light(tx(22),ty(13)-8,60,.5,'90,130,255'),{pulse:12});
  m.prop('stretcher',tx(21),ty(11)-2);
  npc(m,tx(20),ty(11)-6,'para',{fixedDir:0});npc(m,tx(23),ty(10)-4,'para',{fixedDir:1});
  npc(m,tx(24)+8,ty(10)-4,'okafor',{watch:50,interact:I('Mrs Okafor',S.okafor2)});
  if(G.flags.jogger){const pc=m.prop('police',tx(19),ty(16)-1,{dyn:1,flash:1});Object.assign(m.light(tx(19),ty(16)-8,60,.5,'90,130,255'),{pulse:11});}
  const jg=new Sleeper(tx(31),ty(31)-1,'jogger',{pose:'sit',smile:true,dir:0,interact:I('The man on the bench',S.jogger)});m.ents.push(jg);
  if(G.flags.jogger){npc(m,tx(29),ty(31)-2,'police',{fixedDir:2,interact:I('PC Walsh',S.walshAfter)});npc(m,tx(33),ty(31)-2,'police2',{fixedDir:1});}
  m.zone(tx(17),ty(20),tx(20)-tx(17),ty(22)-ty(20),()=>murmur('The park smells of wet leaves and fox. Biscuit approves of both.'));
  m.zone(tx(27),ty(28),tx(35)-tx(27),ty(31)-ty(28),S.joggerNear);
  const dg=new Dog(P.x+12,P.y,{mode:'follow',interact:I('Biscuit',S.petDog)});m.ents.push(dg);G.dog=dg;
 }
 if(d3){
  m.prop('barrierR',tx(22)+8,ty(10)+2);m.prop('barrierR',tx(26)-8,ty(10)+2);
  m.prop('truck',tx(52),ty(16)-1);m.prop('sandbags',tx(58),ty(11)-2);m.prop('barrier',tx(60)+8,ty(11)-2);
  const sd=npc(m,tx(57),ty(10)-2,'soldier',{fixedDir:0,interact:I('Soldier',S.soldier),barks:dusk?['Inside! Now, please!','Curfew’s in force. Go home.']:['Move along, please.'],barkR:80});
  npc(m,tx(61),ty(10)-2,'soldier',{fixedDir:0});
  if(!dusk){
   npc(m,tx(41),ty(10)-2,'okafor',{fixedDir:0,smile:true,infected:1,interact:I('Mrs Okafor',S.okafor3)});
   npc(m,tx(40),ty(10)-3,'p1',{fixedDir:2,barks:['They’re only letting three in at a time.'],barkR:50});
   npc(m,tx(39),ty(10)-2,'lena',{fixedDir:2,clean:1,interact:I('Woman with a baby',S.lenaOut),barks:['Come on, come on…'],barkR:50});
   npc(m,tx(37),ty(10)-3,'p3',{fixedDir:2});
   npc(m,tx(5),ty(19)-6,'p5',{path:[[tx(5),ty(19)-6,2],[tx(30),ty(19)-6,1]],speed:18,smile:true,infected:1});
  }else{
   npc(m,tx(20),ty(10)-4,'p4',{path:[[tx(20),ty(10)-4,0],[tx(1),ty(10)-4,0,'warp'],[tx(36),ty(10)-4,0]],speed:40});
   npc(m,tx(40),ty(19)-6,'p3',{path:[[tx(44),ty(19)-6,0],[tx(62),ty(19)-6,0,'warp'],[tx(30),ty(19)-6,0]],speed:42});
   const s2=npc(m,tx(30),ty(15),'soldier',{path:[[tx(16),ty(15),2],[tx(44),ty(15),2]],speed:22,barks:['Get inside!','Off the street, please!'],barkR:90});
  }
 }
 if(a1||ph==='title'){
  m.prop('burnt',tx(34),ty(15)-2);if(!a2){m.light(tx(34),ty(15)-6,96,.85,'255,140,60',{flick:.3,gk:2});m.emitters.push({x:tx(34),y:ty(15)-8,w:12});}else m.emitters.push({x:tx(34),y:ty(15)-8,w:8,rate:.12,cols:['#2a2a2c','#3a3a3c','#4a4a4c']});
  m.prop('bus',tx(20),ty(16),{dirty:1});
  m.prop('barrierR',tx(58),ty(12)+4);m.prop('barrierR',tx(61),ty(12)+4);m.prop('sandbags',tx(57),ty(11)-2);
  m.prop('bags',tx(44),ty(10)-2);m.prop('bags',tx(36),ty(19)-2);m.prop('cone',tx(31),ty(14));m.prop('cone',tx(37),ty(13));
  m.decals.push((c,ox,oy)=>{c.fillStyle='rgba(20,10,8,.55)';[[tx(33),ty(14)],[tx(42),ty(11)-4],[tx(12),ty(18)]].forEach(([x,y])=>{c.beginPath();c.ellipse(x-ox,y-oy,12,4,0,0,7);c.fill();});
   c.fillStyle='#9aa8b0';for(let i=0;i<14;i++){const r2=RNG(i+3);c.fillRect((tx(40)+r2()*48|0)-ox,(ty(10)+r2()*12|0)-oy,1,1);}});
  if(ph==='a1_street'||a2){
   if(!a2)m.light(tx(30),ty(10)-6,40,.35,'255,180,90',{flick:.9});
   if(a2&&!G.flags.h4)m.ents.push(new Hollow(tx(20),ty(24),{guard:80,flag:'h4',truth:'t2'}));
   m.ents.push(new Sleeper(tx(4)+4,ty(10)-2,'okafor',{pose:'sit',smile:true,dir:0,interact:I('Mrs Okafor',S.okaforA1)}));
   m.ents.push(new Sleeper(tx(28),ty(19)-8,'p2',{pose:'sit',smile:true,dir:0,interact:I('Someone at the bus stop',S.sleeperGeneric)}));
   m.ents.push(new Sleeper(tx(16),ty(11)-2,'p1',{pose:'lie',smile:true,interact:I('Someone on the pavement',S.sleeperGeneric)}));
   m.ents.push(new Sleeper(tx(47),ty(19)-4,'p3',{pose:'lie',smile:true,interact:I('Someone on the pavement',S.sleeperGeneric)}));
   m.ents.push(new Sleeper(tx(24),ty(28),'jogger',{pose:'lie',smile:true,interact:I('Someone in the grass',S.sleeperGeneric)}));
   if(!G.flags.h1)m.ents.push(new Hollow(tx(43),ty(11)-2,{guard:80,flag:'h1',drop:{item:'inhaler',flag:'inh'},truth:'t1'}));
   if(!G.flags.h2)m.ents.push(new Hollow(tx(24),ty(14),{guard:70,flag:'h2',truth:'t2'}));
   if(!G.flags.h3)m.ents.push(new Hollow(tx(30),ty(26),{guard:90,flag:'h3',drop:{item:'idcard',flag:'idc'},truth:'t3',lines:['Get away from her!','STAY BACK!','Please, she’s only a kid—']}));
   if(!G.flags.pk_crisps)m.ents.push(new Pickup(tx(27),ty(19)-4,'crisps',1,{flag:'pk_crisps'}));
   if(!G.flags.pk_band)m.ents.push(new Pickup(tx(36),ty(19)-1,'bandage',1,{flag:'pk_band'}));
   if(!G.flags.pk_choc)m.ents.push(new Pickup(tx(9),ty(28),'choc',1,{flag:'pk_choc'}));
  }
 }
 // exits
 m.exit(9,9,'Your front door',S.streetHome);
 m.exit(42,9,a1?'Adeyemi’s (broken in)':'Adeyemi’s',S.shopDoor);
 m.exit(59,9,'Bow Church station',S.station);m.exit(60,9,'Bow Church station',S.station);
 if(a2){m.exit(0,31,'Towpath west',S.towpathWest);m.exit(0,30,'Towpath west',S.towpathWest);m.set(0,30,T.gravel);}
 if(is('d1_street'))m.zone(0,ty(20),64*16,160,()=>murmur('The canal is the colour of strong tea.'));
 m.finalize();return m;
}
// ---------------- LAB ----------------
function buildLab(){
 const m=new GMap('lab',36,26,T.conc);
 const rows=[];rows.push('C'.repeat(36));
 for(let j=1;j<=13;j++){if(j===6||j===7)rows.push('C'+'l'.repeat(7)+'d'+'l'.repeat(26)+'C');else rows.push('C'+'l'.repeat(7)+'C'+'l'.repeat(26)+'C');}
 rows.push('CCCCECCCC'+'CCC'+'VVV'+'CCCCCCC'+'d'+'CCCCC'+'VVV'+'CCCCC');
 for(let j=15;j<25;j++)rows.push('F'+'f'.repeat(34)+'F');rows.push('F'.repeat(36));
 m.ascii(rows,{C:'C',V:'V',l:'lino',d:'doorwayL',E:'exitC',f:'conc',F:'rail'});
 m.rect(20,15,5,1,T.grate);m.rect(22,15,1,3,T.grate);
 const d2=PH()==='d2_lab';
 m.ambient={a:.62,c:'14,12,22'};m.snd={buzz:.012,room:.04};m.outdoor=false;
 // lights (fluorescent)
 [[13,3],[20,3],[27,3],[33,4],[13,10],[21,10],[29,10],[4,4],[4,10]].forEach(([x,y],i)=>{const L=m.light(tx(x),ty(y)-8,i>6?70:96,.82,'225,238,255',{gk:.4});if(i===5)L.flicker=7.3;});
 m.light(tx(10),ty(21),80,.55,'255,150,80',{gk:1.3});m.light(tx(26),ty(17),70,.5,'255,150,80',{gk:1.3});
 m.grade={c:'rgba(150,200,190,.12)',op:'soft-light'};
 // props
 m.prop('lockers',tx(3),ty(1)+12);m.prop('lockers',tx(5)+6,ty(1)+12);
 m.prop('whiteboard',tx(20),16);
 m.prop('bench2',tx(12)+8,ty(4),{v:'rack beak',interact:I('Sample rack one',S.rack(1))});
 m.prop('bench2',tx(18)+8,ty(4),{v:'rack',interact:I('Sample rack two',S.rack(2))});
 m.prop('bench2',tx(24)+8,ty(4),{v:'rack beak',interact:I('Sample rack three',S.rack(3))});
 m.prop('bench2',tx(30)+4,ty(4),{v:'micro beak',interact:I('Microscope',S.microscope)});
 m.prop('sfridge',tx(34),ty(2)+4);
 m.prop('hood',tx(33),ty(9)+6,{on:1,interact:I('Fume hood',S.hood)});
 m.prop('labsink',tx(34),ty(12)+6);
 m.prop('desk',tx(13)+8,ty(11)+4,{interact:d2?I('Priya’s computer',S.priyaDesk):null,v:'mess'});
 m.prop('desk',tx(19),ty(11)+4,{});
 m.prop('desk',tx(25),ty(11)+4,{on:false});
 m.prop('plant',tx(1),ty(12)+6);
 // yard
 m.prop('tank',tx(10),ty(24)+4,{ph:0});m.prop('tank',tx(28),ty(24)+4,{ph:2});
 m.prop('panel',tx(21),ty(17),{interact:I('Control panel',S.panel)});
 m.prop('lamp',tx(18),ty(16),{on:true});
 if(!d2){
  npc(m,tx(13)+8,ty(10)+10,'priya',{fixedDir:0,pose:'sit',interact:I('Priya',S.priya)});
  npc(m,tx(19),ty(10)+10,'dev',{fixedDir:0,pose:'sit',interact:I('Dev',S.dev1)});
  const g=npc(m,tx(28),ty(18)-4,'gary',{fixedDir:0,interact:I('Gary',S.gary)});g.smile=false;
 }else{
  npc(m,tx(6),ty(11),'dev',{fixedDir:1,interact:I('Dev',S.dev2)});
 }
 m.exit(4,14,'Leave work',S.labExit);
 m.finalize();return m;
}
// ---------------- SHOP ----------------
function buildShop(){
 const m=new GMap('shop',16,11,T.void);
 m.ascii([
 'PPPPPPPPPPPPPPPP',
 'PsssssssssPwwwwP',
 'PsssssssssPwwwwP',
 'PsssssssssPwwwwP',
 'PsssssssssPPdPPP',
 'PssssssssssssssP',
 'PssssssssssssssP',
 'PssssssssssssssP',
 'PssssssssssssssP',
 'PssssssssssssssP',
 'QQQQQQQEQQQQQQQQ'],{P:'P',Q:'Q',s:'shopfl',w:'wood',d:'doorway',E:'exitP'});
 const a2=PH()==='a2_shop',a1=is('a1_shop','a2_shop');
 m.ambient=a2?{a:.8,c:'12,14,20'}:a1?{a:.94,c:'3,4,9'}:{a:.32,c:'14,16,20'};m.snd={buzz:a1?0:.01,room:.05,rain:a1?.06:0,drone:a1?.1:0};
 if(!a1){[[3,3],[8,3],[5,7],[11,7]].forEach(([x,y])=>m.light(tx(x),ty(y)-8,80,.8,'235,240,230',{gk:.3}));}
 else{m.light(tx(7),ty(10)-4,a2?90:46,a2?.55:.3,'150,165,205');if(a2)m.light(tx(3),ty(10)-4,70,.45,'160,170,200');}
 const v=a1?'looted':'half';
 for(let i=1;i<=9;i+=2){}
 [[2,1],[3,1],[4,1],[5,1],[6,1],[7,1],[8,1]].forEach(([x,y])=>m.prop('wshelf',tx(x),ty(y)+8,{v:a1?'empty':'half'}));
 m.prop('gondola',tx(3)+8,ty(5)+6,{v});m.prop('gondola',tx(3)+8,ty(7)+10,{v:a1?'looted':'empty'});
 m.prop('gondola',tx(7)+8,ty(5)+6,{v:a1?'looted':'empty'});
 m.prop('scounter',tx(11)+8,ty(7)+8,{on:!a1});
 m.prop('dfridge',tx(14),ty(5)+12,{on:!a1,v:a1?'empty':'half',interact:a1?null:I('Drinks fridge',S.waterDilemma)});
 m.prop('dfridge',tx(14),ty(7)+12,{on:!a1,v:'empty'});
 m.prop('news',tx(9),ty(9)+4);
 m.prop('telly',tx(10)+8,78,{dyn:1,on:!a1,interact:a1?null:I('Television',S.shopTV)});
 // stockroom
 m.prop('boxes',tx(11),ty(1)+12);m.prop('boxes',tx(14),ty(1)+14);m.prop('boxes',tx(14),ty(3)+6);
 if(a1){
  m.prop('bedroll',tx(12)+8,ty(3)+4,{interact:I('Bedroll',S.rest)});
  spot(m,tx(14),ty(3)+2,'Radio',S.radioA1);
  if(!G.flags.pk_water1)m.ents.push(new Pickup(tx(12),ty(8)+4,'water',1,{flag:'pk_water1'}));
  if(!G.flags.pk_water2)m.ents.push(new Pickup(tx(13),ty(2)+8,'water',1,{flag:'pk_water2'}));
  if(!G.flags.pk_batt)m.ents.push(new Pickup(tx(2),ty(8),'batt',1,{flag:'pk_batt'}));
  if(!G.flags.pk_beans)m.ents.push(new Pickup(tx(6),ty(9),'beans',1,{flag:'pk_beans'}));
  m.decals.push((c,ox,oy)=>{c.fillStyle='#8a8a7a';for(let i=0;i<30;i++){const r=RNG(i*7);c.fillRect((16+r()*200|0)-ox,(80+r()*80|0)-oy,2,1);}});
  m.safe=true;
 }else{
  npc(m,tx(12),ty(7)-2,'tunde',{fixedDir:0,interact:I('Tunde',S.tunde3)});
  npc(m,tx(9),ty(6)+4,'okafor',{fixedDir:1,smile:true,infected:1,interact:I('Mrs Okafor',S.okaforShop)});
  const ln=npc(m,tx(13),ty(6)+2,'lena',{fixedDir:2,clean:1,interact:I('The woman with the baby',S.lenaShop)});G.lena=ln;
  npc(m,tx(3),ty(9),'p4',{path:[[tx(2),ty(9),2],[tx(6),ty(9),2]],speed:16});
  const items=[['beans',2,6,'s_b1'],['beans',6,6,'s_b2'],['crisps',5,9,'s_c1'],['choc',11,9,'s_ch'],['batt',8,2,'s_bt'],['pills',4,2,'s_p'],['bread',2,9,'s_br']];
  items.forEach(([it,x,y,f])=>{if(!G.flags[f])m.ents.push(new Pickup(tx(x),ty(y),it,1,{flag:f}));});
 }
 m.exit(7,10,'Leave the shop',S.shopLeave);
 m.finalize();return m;
}
const BUILD={flat:buildFlat,street:buildStreet,lab:buildLab,shop:buildShop};
// ---------------- moving traffic ----------------
class Vehicle extends Actor{
 constructor(x,y,dirx,type,c){super(x,y,{});this.kind='veh';this.dx=dirx;this.type=type;this.c=c||0;this.sp=type==='bus'?40:55;this.hw=type==='bus'?34:16;this.hh=10;this.solid=true;}
 hbox(){return{x0:this.x-this.hw,y0:this.y-this.hh,x1:this.x+this.hw,y1:this.y};}
 update(dt){const front=this.x+this.dx*(this.hw+4);const blockedP=Math.abs(P.y-this.y+4)<14&&((this.dx>0&&P.x>this.x&&P.x-front<26)||(this.dx<0&&P.x<this.x&&front-P.x<26));
  if(!blockedP)this.x+=this.dx*this.sp*dt;else if(!this.honk){this.honk=1;Snd.tone(330,.25,{type:'square',vol:.03,lp:900});setTimeout(()=>this.honk=0,2500);}
  if(this.dx>0&&this.x>G.map.w*16+60)this.x=-60;if(this.dx<0&&this.x<-60)this.x=G.map.w*16+60;}
 draw(c,ox,oy){const d=PROP[this.type];const img=HDon()&&HD2Q[this.type]?propImg2(this.type,{c:this.c}):propImg(this.type,{c:this.c});c.save();const X=(q(this.x)-ox),Y=(q(this.y)-oy);if(this.dx<0){c.translate(X,0);c.scale(-1,1);c.drawImage(img,-d.w/2,Y-d.h,d.w,d.h);}else c.drawImage(img,X-d.w/2,Y-d.h,d.w,d.h);c.restore();
  // headlights
  c.globalCompositeOperation='lighter';const hx=X+this.dx*this.hw;const g=c.createRadialGradient(hx,Y-6,0,hx+this.dx*20,Y-6,34);g.addColorStop(0,'rgba(255,240,200,.25)');g.addColorStop(1,'rgba(255,240,200,0)');c.fillStyle=g;c.fillRect(hx-40,Y-40,80,60);c.globalCompositeOperation='source-over';}
}
