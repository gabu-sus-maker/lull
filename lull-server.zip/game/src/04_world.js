// ================= ITEMS =================
const ITEMS={
 water:{name:'Bottle of water',icon:'water',desc:'Still water, half a litre. Clean.',use:{thirst:38},sfx:'drink'},
 crisps:{name:'Crisps',icon:'crisps',desc:'Ready salted. Mostly air.',use:{hunger:12,thirst:-3},sfx:'eat'},
 beans:{name:'Tin of beans',icon:'beans',desc:'Cold beans, eaten straight from the tin.',use:{hunger:32},sfx:'eat'},
 choc:{name:'Chocolate bar',icon:'choc',desc:'A small, specific comfort.',use:{hunger:10,sanity:7},sfx:'eat'},
 bread:{name:'Bread',icon:'bread',desc:'Half a loaf. Slightly stale.',use:{hunger:20},sfx:'eat'},
 pastry:{name:'Pastry',icon:'pastry',desc:'From Tunde’s stall. Still warm.',use:{hunger:16,sanity:3},sfx:'eat'},
 pills:{name:'Painkillers',icon:'pills',desc:'Paracetamol. Takes the edge off.',use:{health:15},sfx:'drink'},
 bandage:{name:'Bandage',icon:'bandage',desc:'A clean dressing.',use:{health:28},sfx:'pickup'},
 batt:{name:'Batteries',icon:'batt',desc:'Two AA batteries. Restores torch power.',use:{battery:55},sfx:'torch'},
 torch:{name:'Torch',icon:'torch',desc:'A heavy rubber torch. Press F to switch it on and off.',key:true},
 crowbar:{name:'Crowbar',icon:'crowbar',desc:'From your toolbox. Heavy, slow, reliable.',weapon:{dmg:21,reach:21,cd:.52,stam:17,knock:150}},
 knife:{name:'Kitchen knife',icon:'knife',desc:'Short reach, quick.',weapon:{dmg:13,reach:15,cd:.28,stam:9,knock:60}},
 treats:{name:'Dog treats',icon:'treats',desc:'Biscuit’s favourites.'},
 inhaler:{name:'Inhaler',icon:'inhaler',desc:'A blue asthma inhaler. Half used.',clue:'inhaler'},
 idcard:{name:'School ID',icon:'idcard',desc:'AMARA OSEI · YEAR 9. The photo is of a girl trying not to laugh.',clue:'idcard'},
 notebook:{name:'Notebook',icon:'notebook',desc:'Your notebook. Press N to read it.',key:true},
};
const FISTS={dmg:6,reach:15,cd:.34,stam:8,knock:70};
const ICONC={};
function buildIconCanvases(){for(const k in ICONDRAW){const [c,x]=mkC(16,16);ICONDRAW[k](x);ICONC[k]=c;}}

// ================= MAP =================
class GMap{
 constructor(id,w,h,fill){this.id=id;this.w=w;this.h=h;this.t=new Uint8Array(w*h).fill(fill||0);this.v=new Uint8Array(w*h);
  this.props=[];this.ents=[];this.lights=[];this.zones=[];this.decals=[];this.shafts=[];this.exits={};this.solids=[];this.ambient={a:.3,c:'6,8,14'};
  this.outdoor=false;this.rain=0;this.fog=0;this.snd={};this.grade=null;this.emitters=[];}
 tile(x,y){if(x<0||y<0||x>=this.w||y>=this.h)return 0;return this.t[y*this.w+x];}
 set(x,y,id){if(x<0||y<0||x>=this.w||y>=this.h)return;this.t[y*this.w+x]=id;}
 rect(x,y,w,h,id){for(let j=y;j<y+h;j++)for(let i=x;i<x+w;i++)this.set(i,j,id);}
 solidAt(px,py){return TL[this.tile(Math.floor(px/16),Math.floor(py/16))].solid;}
 opaqueAt(px,py){return TL[this.tile(Math.floor(px/16),Math.floor(py/16))].opaque;}
 ascii(rows,leg,ox=0,oy=0){rows.forEach((row,j)=>{for(let i=0;i<row.length;i++){const ch=row[i];if(leg[ch]!==undefined)this.set(ox+i,oy+j,T[leg[ch]]);}});}
 // props: base point = bottom-centre in px
 prop(name,x,y,o={}){const d=PROP[name];const p={kind:'prop',name,x,y,o,d,layer:d.layer!==undefined?d.layer:1,interact:o.interact||null,hidden:false};
  if(d.box&&!o.nobox){p.box={x0:x+d.box[0],y0:y+d.box[1],x1:x+d.box[0]+d.box[2],y1:y+d.box[1]+d.box[3]};this.solids.push(p.box);}
  if(d.light&&o.on){this.light(x,y+(d.light.dy||0),d.light.r,d.light.i,d.light.c,{prop:p,head:d.light.head});}
  this.props.push(p);return p;}
 light(x,y,r,i,c,o={}){const L=Object.assign({x,y,r,i,c:c||'255,220,180',on:true,flick:0},o);this.lights.push(L);return L;}
 zone(x,y,w,h,fn,o={}){const z=Object.assign({x,y,w,h,fn,once:true,done:false},o);this.zones.push(z);return z;}
 exit(tx,ty,label,fn){this.exits[tx+','+ty]={label,fn};}
 finalize(){
  const r=RNG(hashStr(this.id));
  for(let i=0;i<this.v.length;i++)this.v[i]=(r()*4)|0;
  this.lights.forEach(L=>{if(!L.cone)L.poly=castPoly(this,L.x,L.y,L.r,0,Math.PI*2,72);});
 }
}
function castPoly(m,x,y,r,a0,a1,n){
 const pts=[x,y];
 for(let i=0;i<=n;i++){const a=a0+(a1-a0)*i/n,dx=Math.cos(a),dy=Math.sin(a);let d=0,hit=false;
  while(d<r){d+=2.5;if(m.opaqueAt(x+dx*d,y+dy*d)){hit=true;break;}}
  if(hit)d=Math.min(r,d+7);else d=r;
  pts.push(x+dx*d,y+dy*d);}
 return pts;
}
// px helpers
const tx=t=>t*16+8, ty=t=>t*16+16;

// ================= COLLISION =================
function blocked(m,x,y,hw,hh,self){
 const x0=x-hw,x1=x+hw-.01,y0=y-hh,y1=y-.01;
 if(m.solidAt(x0,y0)||m.solidAt(x1,y0)||m.solidAt(x0,y1)||m.solidAt(x1,y1))return true;
 for(const b of m.solids)if(x1>b.x0&&x0<b.x1&&y1>b.y0&&y0<b.y1)return true;
 for(const e of m.ents)if(e!==self&&e.solid&&!e.dead&&!e.hidden){const b=e.hbox();if(x1>b.x0&&x0<b.x1&&y1>b.y0&&y0<b.y1)return true;}
 if(self!==P&&self&&self.solid!==false&&G.map===m){const b=P.hbox();if(x1>b.x0&&x0<b.x1&&y1>b.y0&&y0<b.y1)return true;}
 return false;
}
function moveActor(a,dx,dy){
 const m=G.map;
 if(dx){const nx=a.x+dx;if(!blocked(m,nx,a.y,a.hw,a.hh,a))a.x=nx;else{a.bumpX=true;}}
 if(dy){const ny=a.y+dy;if(!blocked(m,a.x,ny,a.hw,a.hh,a))a.y=ny;else{a.bumpY=true;}}
}
