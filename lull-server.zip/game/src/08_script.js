// ================= SCRIPT RUNNER =================
const PEND={pend:1};
const Script={cur:null,q:[],
 run(fn){const g=typeof fn==='function'?fn():fn;if(!g||!g.next)return;if(this.cur){this.q.push(g);return;}this.cur=g;this.step();},
 busy(){return !!this.cur;},
 step(v){while(this.cur){let r;try{r=this.cur.next(v);}catch(e){console.error(e);r={done:true};}
   if(r.done){this.cur=null;G.cut=false;if(this.q.length){this.cur=this.q.shift();v=undefined;continue;}return;}
   const c=r.value;if(c===undefined||c===null){v=undefined;continue;}
   const res=this.exec(c);if(res===PEND)return;v=res;}},
 resume(v){G.timers.push({t:0,fn:()=>this.step(v),raw:1});},
 kill(){this.cur=null;this.q=[];G.cut=false;UI.closeDlg();},
 exec(c){
  switch(c.t){
   case 'say':{G.cut=true;const o=Object.assign({},c.o||{});if(c.who==='N'&&G.sanityOn&&G.stats.sanity<18&&!G.lull)o.corrupt=.05+(18-G.stats.sanity)/120;UI.say(c.who,c.text,o,()=>this.resume());return PEND;}
   case 'choice':G.cut=true;UI.choice(c.who,c.text,c.opts,i=>this.resume(i));return PEND;
   case 'wait':G.cut=c.lock!==false;G.timers.push({t:c.s,fn:()=>this.step()});return PEND;
   case 'card':G.cut=true;UI.card(c.title,c.sub,()=>this.resume(),c.hold);return PEND;
   case 'fade':G.cut=true;UI.fade(c.to,c.d,()=>this.resume());return PEND;
   case 'cu':UI.closeup(c.kind,c.state);return UI.cu.state;
   case 'cuClose':UI.cuClose();return;
   case 'phone':G.cut=true;UI.phone(c.html);UI.onModalClose=()=>this.resume();return PEND;
   case 'note':addNote(c.n);UI.notebook();UI.noteI=G.notes.length-1;UI.noteDraw();UI.onModalClose=()=>this.resume();G.cut=true;return PEND;
   case 'walk':G.cut=c.lock!==false;c.ent.target=[c.x,c.y];c.ent.onArrive=()=>this.resume();return PEND;
   case 'go':G.cut=true;Story.goto(c.phase,c.o||{},()=>this.resume());return PEND;
   case 'until':G.waiters.push({cond:c.cond,fn:()=>this.resume()});return PEND;
  }
  return;
 }
};
const say=(who,text,o)=>({t:'say',who,text,o});
const N=(text,o)=>({t:'say',who:'N',text,o});
const ask=(opts,who,text)=>({t:'choice',opts,who,text});
const wait=(s,lock)=>({t:'wait',s,lock});
const card=(title,sub,hold)=>({t:'card',title,sub,hold});
const fade=(to,d=.8)=>({t:'fade',to,d});
const cu=(kind,state)=>({t:'cu',kind,state});
const cuClose=()=>({t:'cuClose'});
const phone=html=>({t:'phone',html});
const note=n=>({t:'note',n});
const walk=(ent,x,y,lock)=>({t:'walk',ent,x,y,lock});
const go=(phase,o)=>({t:'go',phase,o});
const until=cond=>({t:'until',cond});
function addNote(n){if(n.id&&G.notes.some(q=>q.id===n.id))return;G.notes.push(n);if(!hasItem('notebook'))giveItem('notebook',1,true);}
// interaction helper
function I(label,gen,o={}){return Object.assign({label,fn:()=>Script.run(gen)},o);}
function npc(m,x,y,style,o={}){const e=new NPC(x,y,style,o);m.ents.push(e);return e;}
function spot(m,x,y,label,gen,o={}){const e=new Actor(x,y,Object.assign({kind:'spot',solid:false,draw(){},interact:I(label,gen,o)},o));m.ents.push(e);return e;}
function* talk(e,gen){e.talking=true;e.facePlayer();P.dir=Math.abs(e.x-P.x)>Math.abs(e.y-P.y)?(e.x<P.x?1:2):(e.y<P.y?3:0);try{yield* gen();}finally{e.talking=false;}}
function msgs(list){return list.map(([who,t,me])=>`<div style="margin:.5em 0;display:flex;justify-content:${me?'flex-end':'flex-start'}"><div style="max-width:80%;padding:.5em .75em;border-radius:.8em;font-size:.62em;line-height:1.45;background:${me?'#2c5a8a':'#1d232b'};color:#e9edf0">${who?`<div style="font-size:.8em;color:#9aa5b1;margin-bottom:.2em">${who}</div>`:''}${t}</div></div>`).join('')+'<div class="foot" style="text-align:center"><kbd>E</kbd> CLOSE</div>';}
