// ================= HIGH-DETAIL ART (drawn at 2x, displayed at world size) =================
function sh(h,f){const n=parseInt(h.slice(1),16);let r=n>>16,g=n>>8&255,b=n&255;
 if(f<1){r*=f;g*=f;b*=f;}else{const k=f-1;r+=(255-r)*k;g+=(255-g)*k;b+=(255-b)*k;}
 return '#'+((1<<24)|((r|0)<<16)|((g|0)<<8)|(b|0)).toString(16).slice(1);}
function mix(a,b,t){const A=parseInt(a.slice(1),16),B=parseInt(b.slice(1),16);const f=(s)=>[(s>>16)&255,(s>>8)&255,s&255];const x=f(A),y=f(B);return '#'+((1<<24)|(((x[0]+(y[0]-x[0])*t)|0)<<16)|(((x[1]+(y[1]-x[1])*t)|0)<<8)|((x[2]+(y[2]-x[2])*t)|0)).toString(16).slice(1);}
const HDon=()=>RS>=2;
const H2IMG={};
// ---------- humans ----------
function human2(st,dir,pose,fr,o={}){
 const key=st+dir+pose+fr+(o.smile?'s':'')+(o.closed?'c':'')+(o.dead?'d':'')+(o.weapon||'');
 if(H2IMG[key])return H2IMG[key];
 const S=Object.assign({},STY[st]||STY.p1);
 if(o.dead){S.skin='#8c9585';}
 if(pose==='lie'){H2IMG[key]=lying2(S,o,st);return H2IMG[key];}
 const [c,x]=mkC(32,48);
 const flip=dir===2,d=flip?1:dir,sit=pose==='sit',walk=pose==='walk';
 const bob=walk&&(fr===1||fr===3)?1:0,Y=bob+(sit?6:0);
 const sk=S.skin,skD=sh(sk,.8),skDD=sh(sk,.66),skL=sh(sk,1.1);
 const co=S.coat,coD=S.coat2,coL=sh(co,1.14),coDD=sh(S.coat2,.75);
 const pa=S.pants,paD=sh(pa,.72),paL=sh(pa,1.18);
 const hr=S.hair,hrL=sh(hr,1.35),hrD=sh(hr,.7);
 const shoe=S.shoe,shoeL=sh(shoe,1.5);
 const lab=st==='priya'||st==='dev';
 const lip=mix(skDD,'#7a3030',.35);
 // ---- legs ----
 if(sit){
  R(x,pa,9,38,14,3);R(x,paL,9,38,14,1);R(x,paD,15,38,2,3);
  R(x,pa,10,41,4,4);R(x,pa,18,41,4,4);R(x,paD,13,41,1,4);R(x,paD,18,41,1,4);
  R(x,shoe,9,45,6,3);R(x,shoe,17,45,6,3);R(x,shoeL,9,45,6,1);R(x,shoeL,17,45,6,1);
 }else if(d===1){
  const s=walk?[0,3,0,-3,0][fr]:0;
  R(x,paD,15+s,33,4,11);R(x,sh(shoe,.8),13+s,44,6,3);R(x,'#050505',13+s,46,6,1);
  R(x,pa,13-s,33,4,11);R(x,paL,13-s,33,1,11);R(x,shoe,11-s,44,6,3);R(x,shoeL,11-s,44,6,1);R(x,'#050505',11-s,46,6,1);
 }else{
  let l1=0,l2=0;if(walk){if(fr===1)l1=2;if(fr===3)l2=2;}
  R(x,pa,11,33,4,11-l1);R(x,paL,11,33,1,11-l1);R(x,paD,14,33,1,11-l1);
  R(x,pa,17,33,4,11-l2);R(x,paD,17,33,1,11-l2);R(x,paD,20,33,1,11-l2);
  R(x,shoe,10,44-l1,5,3);R(x,shoeL,10,44-l1,5,1);R(x,'#050505',10,46-l1,5,1);
  R(x,shoe,17,44-l2,5,3);R(x,shoeL,17,44-l2,5,1);R(x,'#050505',17,46-l2,5,1);
 }
 // ---- torso ----
 const ty=18+Y;
 if(d===1){
  R(x,co,11,ty,9,1);R(x,co,10,ty+1,11,15);R(x,coL,10,ty+1,1,14);R(x,coD,18,ty+1,3,15);R(x,coDD,10,ty+15,11,1);
  R(x,coD,11,ty+1,2,4);
  if(S.hivis===1){R(x,'#e2da52',10,ty+6,11,1);R(x,'#e2da52',10,ty+10,11,1);}
  if(S.hivis===2){R(x,'#cdd43a',10,ty+1,11,9);R(x,'#c8ccd0',10,ty+5,11,1);R(x,'#9aa030',10,ty+9,11,1);}
  if(st==='rowan'){R(x,S.scarf,11,ty-1,8,3);R(x,sh(S.scarf,.75),11,ty+1,8,1);R(x,S.scarf,10,ty+2,3,6);R(x,sh(S.scarf,.7),10,ty+7,3,1);}
  if(lab){R(x,'#3c5a8a',11,ty+1,2,3);}
  if(S.baby){R(x,'#e8e0d0',6,ty+4,8,7);R(x,'#e8c4a8',6,ty+5,3,3);}
 }else{
  R(x,co,9,ty,14,1);R(x,co,8,ty+1,16,15);R(x,coL,8,ty+1,1,14);R(x,coD,21,ty+1,3,15);R(x,coDD,8,ty+15,16,1);
  if(d===0){
   if(lab){R(x,'#9ab0c8',14,ty+1,4,6);R(x,'#3c5a8a',15,ty+1,2,6);R(x,coD,13,ty+1,1,8);R(x,coD,18,ty+1,1,8);R(x,'#c8ccc8',10,ty+9,4,4);R(x,'#3a5a9a',20,ty+5,1,3);}
   else{R(x,coD,14,ty+1,1,7);R(x,coD,17,ty+1,1,7);R(x,mix(co,'#d8d2c4',.6),15,ty+1,2,5);R(x,coDD,15,ty+9,1,1);R(x,coDD,15,ty+12,1,1);R(x,coD,10,ty+11,4,1);R(x,coD,18,ty+11,4,1);}
   if(S.hivis===1){R(x,'#e2da52',9,ty+6,14,1);R(x,'#e2da52',9,ty+10,14,1);R(x,sh('#e2da52',1.3),9,ty+6,14,1);}
   if(S.hivis===2){R(x,'#cdd43a',9,ty+1,14,10);R(x,'#c8ccd0',9,ty+5,14,1);R(x,'#c8ccd0',9,ty+8,14,1);R(x,'#9aa030',9,ty+10,14,1);R(x,'#0e1012',10,ty+2,2,3);R(x,'#e8e8e0',19,ty+2,2,1);}
   if(st==='rowan'){R(x,S.scarf,11,ty-1,10,3);R(x,sh(S.scarf,1.2),11,ty-1,10,1);R(x,S.scarf,17,ty+2,3,8);R(x,sh(S.scarf,.72),19,ty+2,1,8);for(let i=0;i<3;i++)R(x,sh(S.scarf,.8),17+i,ty+10,1,1);}
   if(S.baby){R(x,'#e8e0d0',11,ty+3,10,7);R(x,'#d0c8b8',11,ty+9,10,1);R(x,'#e8c4a8',13,ty+4,4,3);R(x,'#b08070',14,ty+5,1,1);R(x,'#b08070',16,ty+5,1,1);}
  }else{ // back
   R(x,coD,15,ty+1,2,14);R(x,coDD,9,ty,14,1);
   if(S.hivis===2){R(x,'#cdd43a',9,ty+1,14,10);R(x,'#c8ccd0',9,ty+5,14,1);R(x,'#c8ccd0',9,ty+8,14,1);}
   if(st==='rowan')R(x,S.scarf,11,ty-1,10,3);
  }
 }
 // ---- arms ----
 let a1=0,a2=0;if(walk){if(fr===1){a1=2;a2=-2;}if(fr===3){a1=-2;a2=2;}}
 const arm=(X,Yo,len,front)=>{R(x,front?co:coD,X,ty+1+Yo,3,len);R(x,front?coL:coDD,X,ty+1+Yo,1,len);R(x,coDD,X,ty+len+Yo,3,1);R(x,sk,X,ty+len+1+Yo,3,3);R(x,skD,X+2,ty+len+1+Yo,1,3);};
 if(pose==='swing'){
  if(d===0){arm(5,0,10,false);R(x,co,23,ty+3,3,11);R(x,coDD,23,ty+13,3,1);R(x,sk,23,ty+14,3,3);}
  else if(d===3){arm(5,0,10,false);R(x,co,23,ty-7,3,9);R(x,sk,23,ty-10,3,3);}
  else{R(x,co,4,ty+3,10,3);R(x,coL,4,ty+3,10,1);R(x,sk,1,ty+3,3,3);}
 }else if(d===1){
  if(!sit){const s=walk?[0,-2,0,2,0][fr]:0;R(x,co,14+s,ty+1,3,12);R(x,coL,14+s,ty+1,1,12);R(x,coDD,14+s,ty+12,3,1);R(x,sk,14+s,ty+13,3,3);}
  else{R(x,co,12,ty+2,3,9);R(x,sk,10,ty+10,4,2);}
 }else if(!sit){arm(5,a1,11,false);arm(24,a2,11,true);}
 else{R(x,coD,6,ty+2,3,9);R(x,coD,23,ty+2,3,9);R(x,sk,9,ty+10,3,2);R(x,sk,20,ty+10,3,2);}
 // ---- head ----
 const hy=2+Y+(sit&&o.closed?1:0);const hs=S.hs;
 if(d===1){
  R(x,skD,14,hy+13,4,4);
  R(x,sk,11,hy+1,9,11);R(x,sk,12,hy,7,1);R(x,sk,12,hy+12,6,1);R(x,sk,13,hy+13,4,1);R(x,sk,10,hy+6,1,3);R(x,skD,10,hy+8,1,1);
  R(x,skD,17,hy+2,3,9);R(x,skD,16,hy+5,2,3);R(x,skDD,17,hy+6,1,1);
  if(o.dead){R(x,'#2e332e',12,hy+6,2,2);R(x,'#4a4a52',11,hy+10,3,1);}
  else if(o.closed){R(x,skDD,12,hy+7,2,1);if(o.smile){R(x,lip,11,hy+10,3,1);R(x,lip,14,hy+9,1,1);}else R(x,lip,11,hy+10,2,1);}
  else{R(x,'#ece6dc',12,hy+6,2,2);R(x,'#1a1412',12,hy+6,1,2);if(o.smile){R(x,'#3a1a18',11,hy+10,3,1);R(x,'#3a1a18',14,hy+9,1,1);R(x,'#f0ece4',11,hy+10,2,1);}else R(x,lip,11,hy+10,2,1);}
  R(x,hrD,12,hy+4,3,1);
  // hair (side)
  if(hs==='short'||hs==='long'||hs==='pony'||hs==='bun'){R(x,hr,11,hy-1,10,4);R(x,hr,12,hy-2,7,1);R(x,hr,16,hy+2,5,7);R(x,hr,11,hy+2,2,2);R(x,hrL,13,hy-1,4,1);R(x,hrL,17,hy+3,1,3);R(x,hrD,20,hy+2,1,7);
   if(hs==='long'){R(x,hr,17,hy+8,4,9);R(x,hrD,20,hy+8,1,9);}
   if(hs==='pony'){R(x,hr,21,hy+3,3,8);R(x,hrL,21,hy+3,1,3);}
   if(hs==='bun'){R(x,hr,16,hy-3,5,4);R(x,hrL,17,hy-3,2,1);}}
  if(hs==='bald'){R(x,skL,13,hy,4,1);R(x,hr,16,hy+4,4,3);}
  if(hs==='hat'){R(x,'#101318',10,hy-3,12,6);for(let i=10;i<22;i+=2)R(x,'#e8e8e8',i,hy+1,1,1);R(x,'#06080a',8,hy+2,8,1);}
  if(hs==='helmet'){R(x,'#3c432f',10,hy-3,12,7);R(x,'#4b533b',11,hy-3,9,1);R(x,'#2e3424',9,hy+3,13,1);}
  if(hs==='hood'){R(x,co,12,hy-3,10,4);R(x,co,17,hy+1,5,13);R(x,coD,17,hy+1,1,12);}
  if(hs==='cap'){R(x,'#2a2e34',11,hy-2,10,4);R(x,'#1e2226',7,hy+1,7,1);R(x,hr,17,hy+2,4,4);}
  if(hs==='beanie'){const ht=S.hat||'#3a2a2a';R(x,ht,10,hy-3,12,7);R(x,sh(ht,1.2),11,hy-3,8,1);R(x,sh(ht,.8),10,hy+2,12,2);}
 }else{
  R(x,skD,14,hy+13,4,4);
  R(x,sk,11,hy,10,1);R(x,sk,10,hy+1,12,10);R(x,sk,11,hy+11,10,2);R(x,sk,12,hy+13,8,1);
  R(x,skD,20,hy+2,2,9);R(x,skD,19,hy+11,2,2);R(x,sk,9,hy+5,1,3);R(x,skD,22,hy+5,1,3);
  if(d===3){
   R(x,hr,10,hy-1,12,12);R(x,hr,11,hy-2,10,1);R(x,hr,11,hy+11,10,1);R(x,hrL,12,hy,5,1);R(x,hrL,14,hy+2,1,6);R(x,hrD,20,hy,2,11);
   if(hs==='long'){R(x,hr,9,hy+4,14,13);R(x,hrD,21,hy+4,2,13);R(x,hrL,13,hy+6,1,9);}
   if(hs==='pony'){R(x,hr,14,hy+11,4,8);R(x,hrL,15,hy+11,1,5);}
   if(hs==='bun'){R(x,hr,13,hy-4,6,4);R(x,hrL,14,hy-4,2,1);}
   if(hs==='bald'){R(x,sk,11,hy-1,10,9);R(x,skL,13,hy,4,2);R(x,hr,10,hy+6,12,4);}
   if(hs==='hat'){R(x,'#101318',9,hy-3,14,6);for(let i=9;i<23;i+=2)R(x,'#e8e8e8',i,hy+1,1,1);}
   if(hs==='helmet'){R(x,'#3c432f',9,hy-3,14,8);R(x,'#4b533b',10,hy-3,12,1);}
   if(hs==='hood'){R(x,co,8,hy-3,16,15);R(x,coD,15,hy-2,2,13);}
   if(hs==='cap'){R(x,'#2a2e34',10,hy-2,12,5);}
   if(hs==='beanie'){const ht=S.hat||'#3a2a2a';R(x,ht,9,hy-3,14,8);R(x,sh(ht,.8),9,hy+3,14,2);}
  }else{
   // face
   if(o.dead){R(x,'#2e332e',12,hy+6,3,2);R(x,'#2e332e',17,hy+6,3,2);R(x,'#3a3f3a',12,hy+8,3,1);R(x,'#3a3f3a',17,hy+8,3,1);R(x,'#4a4a52',14,hy+11,4,1);R(x,'#2a2a2e',15,hy+12,2,1);}
   else{
    R(x,hrD,12,hy+4,3,1);R(x,hrD,17,hy+4,3,1);
    if(o.closed){R(x,skDD,12,hy+7,3,1);R(x,skDD,17,hy+7,3,1);R(x,skD,12,hy+6,3,1);R(x,skD,17,hy+6,3,1);}
    else{R(x,'#ece6dc',12,hy+6,3,2);R(x,'#ece6dc',17,hy+6,3,2);R(x,'#1a1412',13,hy+6,1,2);R(x,'#1a1412',18,hy+6,1,2);R(x,'#ffffff',13,hy+6,1,1);R(x,'#ffffff',18,hy+6,1,1);R(x,skD,12,hy+8,3,1);R(x,skD,17,hy+8,3,1);}
    R(x,skD,15,hy+7,2,3);R(x,skDD,16,hy+9,1,1);R(x,skL,15,hy+7,1,1);
    if(o.smile){R(x,'#3a1a18',13,hy+10,1,1);R(x,'#3a1a18',18,hy+10,1,1);R(x,'#f0ece4',14,hy+11,4,1);R(x,'#3a1a18',14,hy+12,4,1);}
    else R(x,lip,14,hy+11,4,1);
   }
   // hair (front)
   if(hs==='short'||hs==='long'||hs==='pony'||hs==='bun'){R(x,hr,10,hy-1,12,4);R(x,hr,11,hy-2,10,1);R(x,hr,10,hy+3,2,4);R(x,hr,20,hy+3,2,4);R(x,hr,12,hy+3,3,1);R(x,hr,16,hy+3,2,1);R(x,hrL,13,hy-1,4,1);R(x,hrL,12,hy,2,1);R(x,hrD,20,hy,2,3);
    if(hs==='long'){R(x,hr,8,hy+1,3,15);R(x,hr,21,hy+1,3,15);R(x,hrL,9,hy+3,1,9);R(x,hrD,23,hy+2,1,14);}
    if(hs==='bun'){R(x,hr,13,hy-4,6,3);R(x,hrL,14,hy-4,2,1);}}
   if(hs==='bald'){R(x,skL,13,hy,4,1);R(x,hr,10,hy+3,1,3);R(x,hr,21,hy+3,1,3);}
   if(hs==='hat'){R(x,'#101318',9,hy-3,14,6);for(let i=9;i<23;i+=2)R(x,'#e8e8e8',i,hy+1,1,1);R(x,'#06080a',9,hy+3,14,1);R(x,'#c8c8b0',15,hy-2,2,2);}
   if(hs==='helmet'){R(x,'#3c432f',9,hy-3,14,7);R(x,'#4b533b',10,hy-3,12,1);R(x,'#2e3424',9,hy+3,14,1);}
   if(hs==='hood'){R(x,co,8,hy-3,16,4);R(x,co,8,hy+1,2,13);R(x,co,22,hy+1,2,13);R(x,coD,10,hy+1,12,1);R(x,coD,10,hy+1,1,10);R(x,coD,21,hy+1,1,10);}
   if(hs==='cap'){R(x,'#2a2e34',10,hy-2,12,4);R(x,'#1e2226',9,hy+2,14,1);R(x,hr,10,hy+3,1,3);R(x,hr,21,hy+3,1,3);}
   if(hs==='beanie'){const ht=S.hat||'#3a2a2a';R(x,ht,9,hy-3,14,6);R(x,sh(ht,1.2),11,hy-3,8,1);R(x,sh(ht,.8),9,hy+1,14,2);for(let i=10;i<22;i+=2)R(x,sh(ht,.7),i,hy-2,1,3);}
  }
 }
 if(S.beard&&!o.dead&&d!==3){if(d===1){R(x,S.beard,11,hy+8,6,5);R(x,S.beard,12,hy+13,4,1);R(x,o.smile?'#f0ece4':lip,11,hy+10,2,1);}else{R(x,S.beard,10,hy+8,2,5);R(x,S.beard,20,hy+8,2,5);R(x,S.beard,11,hy+11,10,2);R(x,S.beard,12,hy+13,8,1);R(x,S.beard,13,hy+10,6,1);R(x,sh(S.beard,1.3),14,hy+12,4,1);R(x,o.smile?'#f0ece4':lip,14,hy+11,4,1);}}
 if(o.weapon&&pose!=='swing'){const wc='#6a6e72';if(d===0){R(x,wc,26,ty+6,2,18);R(x,sh(wc,1.4),26,ty+6,1,18);}else if(d===1){R(x,wc,13,ty+8,2,16);}else R(x,wc,6,ty-4,2,16);}
 let out=c;
 if(flip){const [c2,x2]=mkC(32,48);x2.translate(32,0);x2.scale(-1,1);x2.drawImage(c,0,0);out=c2;}
 H2IMG[key]=out;return out;
}
function lying2(S,o,st){
 const [c,x]=mkC(48,24);const sk=S.skin,skD=sh(sk,.8),co=S.coat,coD=S.coat2,pa=S.pants,hr=S.hair;
 // shoes + legs
 R(x,S.shoe,44,7,3,4);R(x,S.shoe,44,13,3,4);R(x,pa,33,7,11,4);R(x,pa,33,13,11,4);R(x,sh(pa,.75),33,10,11,1);R(x,sh(pa,.75),33,16,11,1);
 // body
 R(x,co,14,4,20,16);R(x,sh(co,1.12),14,4,20,1);R(x,coD,14,17,20,3);R(x,coD,32,4,2,16);
 if(st==='rowan')R(x,S.scarf,13,8,3,8);
 if(S.hivis===1){R(x,'#e2da52',20,4,1,16);R(x,'#e2da52',25,4,1,16);}
 // arms
 R(x,coD,16,2,13,3);R(x,coD,16,19,13,3);R(x,sk,29,2,3,3);R(x,sk,29,19,3,3);
 // head
 R(x,skD,12,9,3,6);R(x,sk,2,6,11,12);R(x,sk,3,5,9,1);R(x,sk,3,18,9,1);R(x,skD,2,15,11,3);
 R(x,hr,0,5,4,14);R(x,hr,1,4,3,1);R(x,sh(hr,1.3),1,7,1,6);if(S.hs==='long')R(x,hr,0,3,5,18);
 if(o.dead){R(x,'#2e332e',6,7,2,3);R(x,'#2e332e',6,14,2,3);R(x,'#4a4a52',10,10,1,4);R(x,'#2a2a2e',11,11,1,2);x.fillStyle='rgba(40,8,8,.55)';x.fillRect(16,18,16,5);x.fillRect(30,12,10,3);}
 else{R(x,sh(sk,.62),7,7,1,3);R(x,sh(sk,.62),7,14,1,3);if(o.smile){R(x,'#3a1a18',9,9,1,1);R(x,'#3a1a18',10,10,1,4);R(x,'#f0ece4',10,11,1,2);R(x,'#3a1a18',9,14,1,1);}else R(x,sh(sk,.66),10,11,1,2);}
 return c;
}
function drawHum(c,st,dir,pose,fr,o,X,Y){const hd=HDon();const im=hd?human2(st,dir,pose,fr,o):human(st,dir,pose,fr,o);const bw=hd?im.width/2:im.width,bh=hd?im.height/2:im.height,s=o.scale||1;
 c.drawImage(im,X+(bw-bw*s)/2,Y+(bh-bh*s),bw*s,bh*s);}
// ---------- the Hollowed ----------
const HOLLOW2=[];
function buildHollow2(){
 for(let f=0;f<6;f++){const [c,x]=mkC(40,60);const r=RNG(1900+f*7);const j=()=>((r()*3)|0)-1;const lunge=f>=4;
  const B='#040506',B2='#08090b',RIM='#1c2027',RIM2='#2b3038';
  // legs
  const l1=j(),l2=j();R(x,B,15+l1,38,3,20);R(x,B,22+l2,38,3,20);R(x,B,14+l1,57,5,2);R(x,B,21+l2,57,5,2);R(x,RIM,15+l1,40,1,16);
  // torso (hunched, narrowing)
  for(let y=16;y<40;y++){const w=y<22?8+(y-16):y<32?13:13-(y-32)/2|0;const lean=lunge?-((40-y)/4|0):(y<24?-((24-y)/5|0):0);R(x,y%3?B:B2,20-((w/2)|0)+lean,y,w,1);}
  for(let y=20;y<34;y+=3)R(x,RIM,15,y,1,1);
  R(x,RIM2,14,18,1,10);
  // arms
  if(lunge){R(x,B,2,20,14,3);R(x,B,0,22,4,1);R(x,B,0,19,3,1);R(x,B,24,22,14,3);R(x,B,36,24,4,1);R(x,B,36,21,3,1);R(x,RIM,2,20,12,1);}
  else{const a1=j(),a2=j();R(x,B,10+a1,19,3,30);R(x,B,27+a2,19,3,30);for(let k=0;k<3;k++){R(x,B,9+a1+k,49,1,5+((r()*3)|0));R(x,B,27+a2+k,49,1,5+((r()*3)|0));}R(x,RIM,10+a1,21,1,24);}
  // head, tilted
  const hx=lunge?9:15+j(),hy=3+((r()*2)|0);
  R(x,B2,hx,hy,9,11);R(x,B2,hx+1,hy-1,7,1);R(x,B2,hx+2,hy+11,6,4);R(x,B,hx+3,hy+15,4,2);
  R(x,RIM2,hx,hy+1,1,8);R(x,RIM,hx+1,hy,3,1);
  // eyes + mouth
  R(x,'#e8e2d4',hx+2,hy+5,2,1);R(x,'#e8e2d4',hx+6,hy+5,2,1);if(f%2){R(x,'#fffaf0',hx+2,hy+5,1,1);R(x,'#fffaf0',hx+6,hy+5,1,1);}
  R(x,'#000',hx+4,hy+9,2,5);
  // rags
  for(let i=0;i<12;i++){const X=12+((r()*16)|0),Y=30+((r()*10)|0);R(x,r()<.5?B:B2,X,Y,1,3+((r()*6)|0));}
  for(let i=0;i<10;i++)R(x,RIM,13+((r()*14)|0),16+((r()*22)|0),1,1);
  HOLLOW2.push(c);}
}
function drawHollowImg(c,f,X,Y,flipX){const hd=HDon();const im=hd?HOLLOW2[f]:HOLLOW[f];c.save();if(flipX){c.translate(X+10,0);c.scale(-1,1);c.drawImage(im,-10,Y,20,30);}else c.drawImage(im,X,Y,20,30);c.restore();}
// ---------- Biscuit ----------
const D2IMG={};
function dog2(dir,pose,fr){const key=dir+pose+fr;if(D2IMG[key])return D2IMG[key];
 const [c,x]=mkC(40,28);const B='#7b5735',BD='#5a3e25',BL='#9a7048',BEL='#b08a62',W='#e2d9c8',WD='#bfb4a0',N='#141010';
 const sit=pose==='sit',gr=pose==='growl',walk=pose==='walk';const s=walk?(fr%2?2:-2):0;
 if(sit){
  R(x,BD,22,14,10,10);R(x,B,12,8,14,12);R(x,BL,13,8,10,2);R(x,W,10,11,5,8);R(x,WD,10,17,5,2);
  R(x,B,13,19,3,7);R(x,BD,13,25,4,2);R(x,BD,24,22,8,4);R(x,B,22,22,6,4);R(x,BD,30,22,6,2);
 }else{
  // far legs
  R(x,BD,12-s,18,3,8);R(x,BD,26+s,18,3,8);
  // body
  R(x,B,10,8,22,11);R(x,B,11,7,19,1);R(x,BD,10,17,22,2);R(x,BL,12,8,16,2);R(x,BEL,14,16,12,2);R(x,BD,28,9,4,9);
  R(x,W,8,10,5,8);R(x,WD,8,16,5,2);
  // near legs
  R(x,B,10+s,18,3,8);R(x,W,10+s,25,3,2);R(x,B,24-s,18,3,8);R(x,BD,25-s,18,2,2);R(x,W,24-s,25,3,2);
 }
 // tail
 if(gr){R(x,BD,31,13,7,2);}else if(sit){R(x,BD,32,23,6,2);}else{const t=fr%2;R(x,BD,31,7-t,2,3);R(x,BD,33,5-t,2,3);R(x,B,35,3-t,2,3);}
 // head
 const hy=gr?6:sit?1:2;
 R(x,B,2,hy+3,11,9);R(x,B,3,hy+2,9,1);R(x,BL,4,hy+3,6,2);R(x,BD,0,hy+7,5,4);R(x,mix(BD,'#2a1a10',.5),0,hy+8,3,3);R(x,N,0,hy+7,2,2);
 R(x,N,6,hy+5,2,2);R(x,'#fff',6,hy+5,1,1);
 R(x,BD,9,hy+1,4,8);R(x,mix(BD,'#3a2414',.4),11,hy+2,2,7);
 R(x,'#9a2a24',9,hy+11,4,3);R(x,'#d8b84a',10,hy+14,2,2);
 if(gr){R(x,'#f4f0e4',1,hy+10,4,1);R(x,'#6a2020',1,hy+11,4,1);R(x,BD,4,hy+3,4,1);}
 let out=c;if(dir===2){const [c2,x2]=mkC(40,28);x2.translate(40,0);x2.scale(-1,1);x2.drawImage(c,0,0);out=c2;}
 D2IMG[key]=out;return out;}
function drawDogImg(c,dir,pose,fr,X,Y){if(HDon())c.drawImage(dog2(dir,pose,fr),X,Y,20,14);else c.drawImage(dog(dir,pose,fr),X,Y);}
