import asyncio,random,string
from playwright.async_api import async_playwright
U=''.join(random.choice(string.ascii_lowercase) for _ in range(6))
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome');pg=await b.new_page();await pg.goto((__import__('sys').argv[1] if len(__import__('sys').argv)>1 else 'http://127.0.0.1:9000')+'/')
    ev=pg.evaluate
    await ev("async()=>{const r=await Acct.api('/api/register','POST',{u:'"+U+"',p:'quiet streets 9'});Acct.set(r.j.u,r.j.token);await NetUI.reconcile();NetUI.close();}")
    await ev("()=>{resetGame();storeDel('lull_save');LULL.G.state='play';Story.goto('d1_wake',{});}")
    for i in range(10):
      await pg.wait_for_timeout(1000)
      print(i, await ev("()=>({local:(JSON.parse(localStorage.getItem('lull_save')||'null')||{}).phase,phase:LULL.G.phase,dirty:Cloud.dirtyT,busy:Cloud.busy,status:Cloud.status,tok:!!Acct.tok})"))
    s=await ev("async()=>(await Acct.api('/api/save')).j")
    print('cloud:', s['rev'], s['data'] and s['data']['save'] and s['data']['save']['phase'])
    await b.close()
asyncio.run(main())
