// A TCP proxy that adds latency + jitter in both directions (strictly in order),
// so the game can be tested the way a real network behaves.
// Usage: node tests/lagproxy.mjs <listenPort> <targetPort> <oneWayMs> <jitterMs>
import net from "node:net";
const [lp, tp, delay, jitter] = process.argv.slice(2).map(Number);
net.createServer(c => {
  const s = net.connect(tp, "127.0.0.1");
  const pipe = (a, b) => {
    const q = []; let busy = false, ended = false, last = 0;
    const pump = () => {
      if (!q.length) { busy = false; if (ended && !b.destroyed) b.end(); return; }
      busy = true; const w = q[0].t - Date.now();
      setTimeout(() => { const it = q.shift(); if (!b.destroyed) b.write(it.d); pump(); }, Math.max(0, w));
    };
    a.on("data", d => { last = Math.max(last, Date.now() + delay + Math.random() * jitter); q.push({ t: last, d }); if (!busy) pump(); });
    a.on("end", () => { ended = true; if (!busy) pump(); });
  };
  pipe(c, s); pipe(s, c);
  c.on("error", () => s.destroy()); s.on("error", () => c.destroy());
}).listen(lp, "127.0.0.1", () => console.log(`lag proxy :${lp} -> :${tp} (${delay}±${jitter} ms each way)`));
