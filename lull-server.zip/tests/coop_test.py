# Four real browsers, real Cloudflare runtime (wrangler dev), real WebSockets,
# through a lag proxy (default 60±40 ms each way). Drives the actual UI by keyboard where it matters.
# Usage: python3 tests/coop_test.py [BASE] [SHOTS_DIR]
import asyncio, sys, random, string, os, json
from playwright.async_api import async_playwright
BASE = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:9000'
SH = sys.argv[2] if len(sys.argv) > 2 else '/tmp/claude-0/-home-claude/080949e3-c506-5252-83b1-2c60697bff54/scratchpad/shots/'
os.makedirs(SH, exist_ok=True)
U = ''.join(random.choice(string.ascii_lowercase) for _ in range(5))
fails = []; passes = [0]
def ok(c, m):
    if c: passes[0] += 1; print('  ok  ', m)
    else: fails.append(m); print('  FAIL', m)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--autoplay-policy=no-user-gesture-required'])
        P = []; errs = {}
        for i in range(4):
            ctx = await b.new_context(viewport={'width': 960, 'height': 540})
            pg = await ctx.new_page(); n = 'ABCD'[i]; errs[n] = []
            pg.on('console', lambda m, n=n: errs[n].append(m.text) if m.type == 'error' and 'favicon' not in m.text else None)
            pg.on('pageerror', lambda e, n=n: errs[n].append('PAGEERR ' + str(e)))
            await pg.goto(BASE); P.append(pg)
        await P[0].wait_for_timeout(1500)
        A, B, C, D = P
        ev = lambda pg, js: pg.evaluate(js)
        async def wait(pg, js, ms=6000):
            for _ in range(ms // 100):
                if await pg.evaluate(js): return True
                await pg.wait_for_timeout(100)
            return False

        print('\n[1] Account by keyboard (player A)')
        for _ in range(8):
            if (await ev(A, "()=>document.querySelector('#tm .sel').textContent")) == 'Sign in': break
            await A.keyboard.press('ArrowDown')
        await A.keyboard.press('Enter'); await A.wait_for_timeout(200)
        ok(await ev(A, "()=>NetUI.open&&NetUI.view==='acct'"), 'account overlay opens from title')
        await A.keyboard.press('ArrowDown'); await A.keyboard.press('Enter'); await A.wait_for_timeout(200)
        ok(await ev(A, "()=>NetUI.view==='reg'&&document.activeElement.id==='ni_user'"), 'register form, username box focused')
        await A.keyboard.type(U + 'a'); await A.keyboard.press('Enter')
        await A.keyboard.type('quiet streets 9'); await A.keyboard.press('Enter')
        await A.keyboard.type('quiet streets 9'); await A.keyboard.press('Enter')
        ok(await wait(A, "()=>Acct.u&&NetUI.view==='acct'"), 'registered + signed in via keyboard (spaces in password work)')
        ok(await ev(A, "()=>LULL.G.state==='title'&&!LULL.G.paused"), 'typing did not leak into the game')
        await A.keyboard.press('Escape'); await A.wait_for_timeout(200)
        ok(await ev(A, "()=>!NetUI.open&&document.querySelector('#tm').textContent.includes('Account: "+U+"a')"), 'title shows account name')

        print('\n[2] Saves follow the account (device progress import)')
        await ev(B, "()=>{localStorage.setItem('lull_save',JSON.stringify({phase:'a2_canal',stats:{},inv:[],flags:{},notes:[]}));localStorage.setItem('lull_endings',JSON.stringify({wall:1}));}")
        await ev(B, "async()=>{const r=await Acct.api('/api/register','POST',{u:'"+U+"b',p:'quiet streets 9b'});Acct.set(r.j.u,r.j.token);await NetUI.reconcile();}")
        ok(await ev(B, "()=>NetUI.view==='reconcile'&&NetUI.rec&&NetUI.rec.opts.length===2"), 'B asked whether to attach this computer\'s progress')
        await ev(B, "async()=>{await NetUI.act({id:'r_attach'});}")
        s = await ev(B, "async()=>(await Acct.api('/api/save')).j")
        ok(s['rev'] >= 1 and s['data']['save']['phase'] == 'a2_canal' and s['data']['endings']['wall'] == 1, 'B progress now in the cloud')
        await ev(B, "()=>NetUI.close()")
        # same account on another "computer" (C's browser) with different local progress -> asked which to keep; endings merged
        await ev(C, "()=>{localStorage.setItem('lull_save',JSON.stringify({phase:'a1_shop'}));localStorage.setItem('lull_endings',JSON.stringify({river:1}));}")
        await ev(C, "async()=>{const r=await Acct.api('/api/login','POST',{u:'"+U+"b',p:'quiet streets 9b'});Acct.set(r.j.u,r.j.token);await NetUI.reconcile();}")
        ok(await ev(C, "()=>NetUI.view==='reconcile'&&NetUI.rec.q.includes('Which')"), 'conflicting progress -> asked which to keep')
        await ev(C, "async()=>{await NetUI.act({id:'r_cloud'});}")
        e = await ev(C, "()=>({e:JSON.parse(localStorage.getItem('lull_endings')),s:JSON.parse(localStorage.getItem('lull_save')).phase,b:!!localStorage.getItem('lull_backup')})")
        ok(e['s'] == 'a2_canal' and e['e'].get('wall') and e['e'].get('river') and e['b'], 'used account save, endings merged, old one backed up')
        await ev(C, "async()=>{await Acct.api('/api/logout','POST');Acct.clear();localStorage.clear();NetUI.close();}")

        print('\n[3] Room by keyboard')
        for _ in range(8):
            if (await ev(A, "()=>document.querySelector('#tm .sel').textContent")) == 'Together (online)': break
            await A.keyboard.press('ArrowUp')
        await A.keyboard.press('Enter'); await A.wait_for_timeout(200)
        await A.keyboard.press('Enter')  # Make a room
        ok(await wait(A, "()=>NetUI.view==='room'&&Net.code"), 'room made')
        code = await ev(A, "()=>Net.code"); print('     code', code)
        for pg, n in ((B, 'b'), (C, 'c'), (D, 'd')):
            if n != 'b': await ev(pg, "async()=>{const r=await Acct.api('/api/register','POST',{u:'"+U+n+"',p:'quiet streets 9"+n+"'});Acct.set(r.j.u,r.j.token);}")
            await ev(pg, "()=>{NetUI.show('together');}")
        # D joins by typing the code
        await D.keyboard.press('ArrowDown'); await D.keyboard.press('Enter'); await D.wait_for_timeout(150)
        await D.keyboard.type(code.lower()); await D.keyboard.press('Enter')
        await ev(B, "()=>Net.join('"+code+"')"); await ev(C, "()=>Net.join('"+code+"')")
        ok(await wait(A, "()=>Net.roster.length===4&&Net.roster.every(r=>r.on)"), 'four in the room')
        ok(await ev(D, "()=>NetUI.view==='room'"), 'D joined by typing the code (lower case accepted)')
        chars = await ev(A, "()=>Net.roster.map(r=>r.char)"); ok(len(set(chars)) == 4, 'everyone has a different character ' + str(chars))
        await C.keyboard.press('ArrowLeft'); await C.wait_for_timeout(500)
        c2 = await ev(A, "()=>Net.roster.map(r=>r.char)"); ok(len(set(c2)) == 4, 'C switched character, still unique ' + str(c2))
        ok(await ev(A, "()=>NetUI.items.find(i=>i.id==='start').dis"), 'host cannot start before everyone is ready')
        for pg in (B, C, D):
            await pg.keyboard.press('ArrowDown'); await pg.keyboard.press('Enter'); await pg.wait_for_timeout(100)
        ok(await wait(A, "()=>Net.roster.filter(r=>r.u!==Net.me).every(r=>r.ready)"), 'B, C, D ready (keyboard)')
        await A.wait_for_timeout(300)
        await ev(A, "()=>{NetUI.sel=NetUI.items.findIndex(i=>i.id==='start');NetUI.focusSel();}")
        await A.keyboard.press('Enter')
        okall = True
        for pg in P: okall = okall and await wait(pg, "()=>LULL.G.coop&&LULL.G.phase==='co_test'")
        ok(okall, 'game started on all four')
        await A.wait_for_timeout(1500)
        ok(all([await ev(pg, "()=>[...Net.remotes.values()].filter(r=>!r.hidden).length===3") for pg in P]), 'each player sees the other three')
        ok(await ev(A, "()=>Net.isHost()") and not await ev(B, "()=>Net.isHost()"), 'A hosts')

        print('\n[4] Movement sync under lag')
        await A.keyboard.down('KeyD'); await A.wait_for_timeout(900); await A.keyboard.up('KeyD'); await A.wait_for_timeout(700)
        ax = await ev(A, "()=>LULL.P.x")
        bx = await ev(B, "()=>[...Net.remotes.values()].find(r=>r.u==='"+U+"a').x")
        ok(abs(ax - bx) < 4, f'B sees A where A is (A {ax:.1f}, B sees {bx:.1f})')
        for i, pg in enumerate(P): await pg.screenshot(path=f'{SH}co_start_{"ABCD"[i]}.png')

        print('\n[5] Pickup race: B and C grab the same bottle')
        cntB0 = await ev(B, "()=>countItem('water')"); cntC0 = await ev(C, "()=>countItem('water')")
        await asyncio.gather(ev(B, "()=>LULL.G.map.ents.find(e=>e.pid==='p1').interact.fn()"), ev(C, "()=>LULL.G.map.ents.find(e=>e.pid==='p1').interact.fn()"))
        await A.wait_for_timeout(900)
        d = (await ev(B, "()=>countItem('water')")) - cntB0 + (await ev(C, "()=>countItem('water')")) - cntC0
        ok(d == 1, 'exactly one of them got it')
        ok(all([not await ev(pg, "()=>LULL.G.map.ents.some(e=>e.pid==='p1')") for pg in P]), 'bottle gone for everyone')

        print('\n[6] Giving: B hands water to C')
        await ev(B, "()=>{const c=[...Net.remotes.values()].find(r=>r.u==='"+U+"c');LULL.P.x=c.x+12;LULL.P.y=c.y;NetGame.sendState(true);}"); await B.wait_for_timeout(600)
        b0 = await ev(B, "()=>countItem('water')"); c0 = await ev(C, "()=>countItem('water')")
        await B.keyboard.press('KeyI'); await B.wait_for_timeout(150)
        await ev(B, "()=>{UI.invSel=LULL.G.inv.findIndex(s=>s.id==='water');UI.invDraw();}")
        await B.keyboard.press('KeyG'); await B.wait_for_timeout(900); await B.keyboard.press('KeyI')
        ok((await ev(B, "()=>countItem('water')")) == b0 - 1 and (await ev(C, "()=>countItem('water')")) == c0 + 1, 'item moved B -> C (keyboard G in bag)')
        await ev(D, "()=>{LULL.P.x=tx(2);LULL.P.y=ty(20);NetGame.sendState(true);}")  # far from everyone, away from Hollowed; await D.wait_for_timeout(400)
        await ev(D, "()=>{UI.invSel=LULL.G.inv.findIndex(s=>s.id==='water');NetGame.giveSelected();}")
        ok((await ev(D, "()=>countItem('water')")) >= 1, 'giving with nobody near does nothing')

        print('\n[7] Say aloud (near only) and radio (everyone on the channel, no names)')
        await ev(A, "()=>{const c=[...Net.remotes.values()].find(r=>r.u==='"+U+"b');LULL.P.x=c.x-10;LULL.P.y=c.y;NetGame.sendState(true);}"); await A.wait_for_timeout(500)
        await A.keyboard.down('KeyT'); await A.keyboard.press('Digit4'); await A.keyboard.up('KeyT'); await A.wait_for_timeout(800)
        lb = await ev(B, "()=>document.querySelector('#chatlog').textContent"); ld = await ev(D, "()=>document.querySelector('#chatlog').textContent")
        ok('Wait.' in lb and 'Wait.' not in ld, 'B (near) heard "Wait." with a name; D (far) did not')
        ok(await ev(A, "()=>LULL.G.inv.length")==await ev(A, "()=>LULL.G.inv.length"), 'digit keys during T did not use hotbar items')
        await A.keyboard.down('KeyR'); await A.keyboard.press('Digit5'); await A.keyboard.up('KeyR'); await A.wait_for_timeout(800)
        ld = await ev(D, "()=>document.querySelector('#chatlog').innerHTML")
        ok('Where are you?' in ld or 'CH 1' in ld, 'D (far) heard the radio')
        ok(U + 'a' not in ld and 'Rowan' not in ld, 'radio carries no name')
        await D.keyboard.press('KeyC'); await D.wait_for_timeout(400)
        await A.keyboard.down('KeyR'); await A.keyboard.press('Digit2'); await A.keyboard.up('KeyR'); await A.wait_for_timeout(800)
        ld = await ev(D, "()=>document.querySelector('#chatlog').textContent")
        ok('I’m fine' not in ld, 'D on channel 2 did not hear channel 1')
        await A.keyboard.down('KeyR')
        for _ in range(3): await A.keyboard.press('Space'); await A.wait_for_timeout(120)
        await A.keyboard.up('KeyR'); await A.wait_for_timeout(900)
        ok('3 clicks' in await ev(B, "()=>document.querySelector('#chatlog').textContent"), 'click code arrived (3 clicks)')
        ok(await ev(A, "()=>LULL.P.swing<0"), 'Space during radio did not swing the crowbar')
        await B.screenshot(path=f'{SH}co_chat_B.png')

        print('\n[8] Fighting a Hollowed together (B is not the host)')
        await ev(A, "()=>{LULL.P.x=tx(33);LULL.P.y=ty(7);LULL.P.dir=2;LULL.P.fx=1;LULL.P.fy=0;NetGame.sendState(true);}")
        await ev(B, "()=>{LULL.P.x=tx(34);LULL.P.y=ty(8)-4;LULL.P.dir=2;LULL.P.fx=1;LULL.P.fy=0;NetGame.sendState(true);}")
        alerted = await wait(A, "()=>{const h=LULL.G.map.ents.find(e=>e.nid==='h1');return h.state!=='idle'}", 8000)
        ok(alerted, 'h1 noticed the players (host AI)')
        ok(await wait(B, "()=>{const h=LULL.G.map.ents.find(e=>e.nid==='h1');return h.state!=='idle'}", 3000), 'B sees h1 react too (snapshot)')
        await B.screenshot(path=f'{SH}co_fight_B.png'); await A.screenshot(path=f'{SH}co_fight_A.png')
        hp0 = await ev(A, "()=>LULL.G.map.ents.find(e=>e.nid==='h1').hp")
        sanB0 = await ev(B, "()=>LULL.G.stats.sanity"); sanA0 = await ev(A, "()=>LULL.G.stats.sanity")
        dead = False
        for i in range(40):
            # like a player: step in if it backs off, face it, swing
            await ev(B, "()=>{const h=LULL.G.map.ents.find(e=>e.nid==='h1');let dx=h.x-LULL.P.x,dy=h.y-LULL.P.y,l=Math.hypot(dx,dy)||1;if(l>18){LULL.P.x=h.x-dx/l*14;LULL.P.y=h.y-dy/l*14;NetGame.sendState(true);dx=h.x-LULL.P.x;dy=h.y-LULL.P.y;l=Math.hypot(dx,dy)||1;}LULL.P.fx=dx/l;LULL.P.fy=dy/l;LULL.P.dir=Math.abs(dx)>Math.abs(dy)?(dx<0?1:2):(dy<0?3:0);LULL.P.stam=100;if(LULL.G.stats.health<40)LULL.G.stats.health=100;}")
            await B.keyboard.press('Space'); await B.wait_for_timeout(330)
            if await ev(A, "()=>LULL.G.map.ents.find(e=>e.nid==='h1').dead"): dead = True; break
        hp1 = await ev(A, "()=>LULL.G.map.ents.find(e=>e.nid==='h1').hp")
        ok(hp1 < hp0, f'B\'s hits counted on the host (hp {hp0} -> {hp1})')
        ok(dead, 'h1 killed by B')
        ok(await wait(C, "()=>LULL.G.map.ents.find(e=>e.nid==='h1').dead", 3000), 'C sees h1 dead')
        await A.wait_for_timeout(600)
        sanB1 = await ev(B, "()=>LULL.G.stats.sanity"); kB = await ev(B, "()=>LULL.G.flags.kills||0"); kA = await ev(A, "()=>LULL.G.flags.kills||0")
        ok(kB == 1 and kA == 0, f'the kill counts for B only (B {kB}, A {kA})')
        hurt = await ev(A, "()=>LULL.G.stats.health<100") or await ev(B, "()=>LULL.G.stats.health<100")
        print('     (someone took damage during the fight:', hurt, ')')

        print('\n[9] Down and revive')
        await ev(C, "()=>{LULL.P.x=tx(12);LULL.P.y=ty(19);NetGame.sendState(true);LULL.G.stats.health=5;hurtPlayer(30,'hollow');}")
        ok(await wait(C, "()=>!!NetGame.down&&LULL.P.pose==='lie'", 2000), 'C is down, not dead')
        ok(await wait(D, "()=>[...Net.remotes.values()].find(r=>r.u==='"+U+"c').dn===1", 3000), 'D sees C down')
        ok(not await ev(D, "()=>!!NetGame.down"), 'D is on their feet')
        await ev(D, "()=>{LULL.P.x=tx(12)+14;LULL.P.y=ty(19);NetGame.sendState(true);}"); await D.wait_for_timeout(700)
        await D.keyboard.down('KeyE'); await D.wait_for_timeout(1900); await D.keyboard.up('KeyE')
        ok(await wait(C, "()=>!NetGame.down&&LULL.G.stats.health>=40", 3000), 'D held E and helped C up')
        await D.screenshot(path=f'{SH}co_revive_D.png')

        print('\n[10] Torches in the dark')
        await ev(B, "()=>{LULL.P.x=tx(56);LULL.P.y=ty(19);LULL.P.dir=2;LULL.P.fx=1;LULL.P.fy=0;LULL.P.torch=true;LULL.P.battery=80;NetGame.sendState(true);}")
        await ev(C, "()=>{LULL.P.x=tx(52);LULL.P.y=ty(19);LULL.P.torch=false;NetGame.sendState(true);}")
        await C.wait_for_timeout(900)
        ok(await ev(C, "()=>[...Net.remotes.values()].find(r=>r.u==='"+U+"b').tc===1"), 'C knows B\'s torch is on')
        await C.screenshot(path=f'{SH}co_torch_C.png')

        print('\n[11] Reconnect without losing anything')
        inv0 = await ev(D, "()=>JSON.stringify(LULL.G.inv)")
        await ev(D, "()=>Net.ws.close()")
        ok(await wait(D, "()=>Net.ws&&Net.ws.readyState===1", 8000), 'D reconnected by itself')
        await D.wait_for_timeout(800)
        ok((await ev(D, "()=>JSON.stringify(LULL.G.inv)")) == inv0 and await ev(D, "()=>LULL.G.coop"), 'D kept their bag and stayed in the game')
        ok(not await ev(D, "()=>LULL.G.map.ents.some(e=>e.pid==='p1')"), 'taken pickups stay taken after reconnect')

        print('\n[12] Host leaves: someone else takes over the Hollowed')
        await ev(A, "()=>Game.toTitle()"); await B.wait_for_timeout(1500)
        hosts = [await ev(pg, "()=>Net.isHost()") for pg in (B, C, D)]
        ok(sum(hosts) == 1, 'exactly one new host ' + str(hosts))
        newh = (B, C, D)[hosts.index(True)]
        await ev(newh, "()=>{LULL.P.x=tx(47);LULL.P.y=ty(8);NetGame.sendState(true);}")
        moved = await wait(newh, "()=>{const h=LULL.G.map.ents.find(e=>e.nid==='h2');return h.state!=='idle'}", 8000)
        ok(moved, 'Hollowed still think after the host left')
        ok(await ev(A, "()=>LULL.G.state==='title'&&!LULL.G.coop"), 'A is back at the title')
        ok(await ev(A, "()=>!localStorage.getItem('lull_save')"), 'co-op never wrote a solo save')

        print('\n[13] Errors')
        for n, e in errs.items():
            e2 = [x for x in e if 'ERR_CONNECTION' not in x and 'ERR_TUNNEL' not in x and 'WebSocket' not in x]
            ok(not e2, f'no console errors on {n}' + ('' if not e2 else ': ' + ' | '.join(e2[:3])))
        print(f'\n{passes[0]} passed, {len(fails)} failed')
        if fails: print('FAILED:', fails)
        await b.close()

asyncio.run(main())
