// Server tests against a running server (wrangler dev or the real deployment).
// Usage: node tests/api.test.mjs http://127.0.0.1:8787 [adminKey]
const BASE = process.argv[2] || "http://127.0.0.1:8787";
const ADMIN = process.argv[3] || "test-admin-key-123456";
let fails = 0, passes = 0;
const ok = (c, m) => { if (c) { passes++; } else { fails++; console.log("FAIL:", m); } };
const H = (tok) => ({ "content-type": "application/json", ...(tok ? { authorization: "Bearer " + tok } : {}), origin: BASE });
async function call(path, method = "GET", body, tok, extra = {}) {
  const r = await fetch(BASE + path, { method, headers: { ...H(tok), ...extra }, body: body ? JSON.stringify(body) : undefined });
  let j = null; try { j = await r.json(); } catch (e) { }
  return { s: r.status, j };
}
const uniq = "t" + Math.random().toString(36).slice(2, 8);
const sleep = ms => new Promise(r => setTimeout(r, ms));

function sock(code, tok) {
  return new Promise((res, rej) => {
    const ws = new WebSocket(BASE.replace("http", "ws") + "/ws/room/" + code, ["lull", tok]);
    const inbox = [];
    ws.onmessage = e => inbox.push(JSON.parse(e.data));
    ws.onopen = () => res({ ws, inbox, send: o => ws.send(JSON.stringify(o)), wait: async (pred, ms = 3000) => { const t = Date.now(); while (Date.now() - t < ms) { const i = inbox.findIndex(pred); if (i >= 0) return inbox.splice(i, 1)[0]; await sleep(20); } return null; } });
    ws.onerror = e => rej(new Error("ws error"));
  });
}

(async () => {
  // --- validation
  let r = await call("/api/register", "POST", { u: "ab", p: "longenough1" }); ok(r.s === 400, "short username rejected");
  r = await call("/api/register", "POST", { u: uniq + "a", p: "password" }); ok(r.s === 400 && /easy/.test(r.j.error), "common password rejected");
  r = await call("/api/register", "POST", { u: uniq + "a", p: "x" + uniq + "a1" }); ok(r.s === 400, "password containing username rejected");
  r = await call("/api/register", "POST", { u: "admin", p: "longenough1" }); ok(r.s === 400, "reserved name rejected");
  // --- register + login
  const A = uniq + "a", B = uniq + "b", PW = "rainy-tuesday-7";
  r = await call("/api/register", "POST", { u: A.toUpperCase(), p: PW }); ok(r.s === 200 && r.j.token && r.j.u === A, "register A (case-folded) " + JSON.stringify(r.j));
  const tA = r.j.token;
  r = await call("/api/register", "POST", { u: A, p: PW }); ok(r.s === 400 && /taken/.test(r.j.error), "duplicate rejected");
  r = await call("/api/register", "POST", { u: B, p: PW + "b" }); const tB = r.j.token; ok(!!tB, "register B");
  r = await call("/api/me", "GET", null, tA); ok(r.j && r.j.u === A, "me with token");
  r = await call("/api/me", "GET", null, "nonsense-token-nonsense-token"); ok(r.s === 401, "bad token rejected");
  r = await call("/api/login", "POST", { u: A, p: PW }); ok(r.s === 200 && r.j.token, "login ok");
  // --- cross-site origin blocked
  r = await call("/api/login", "POST", { u: A, p: PW }, null, { origin: "https://evil.example" }); ok(r.s === 403, "foreign origin blocked");
  // --- lockout after 5 wrong
  for (let i = 0; i < 5; i++) r = await call("/api/login", "POST", { u: B, p: "wrong-password-" + i });
  r = await call("/api/login", "POST", { u: B, p: PW + "b" }); ok(r.s === 401 && /Wait/.test(r.j.error), "locked after 5 wrong: " + JSON.stringify(r.j));
  // --- saves
  r = await call("/api/save", "GET", null, tA); ok(r.j.rev === 0 && r.j.data === null, "empty save");
  r = await call("/api/save", "PUT", { data: { v: 1, save: { phase: "a2_canal" } }, baseRev: 0 }, tA); ok(r.j.rev === 1, "save rev1");
  r = await call("/api/save", "PUT", { data: { v: 1, save: { phase: "x" } }, baseRev: 0 }, tA); ok(r.s === 409 && r.j.conflict && r.j.data.save.phase === "a2_canal", "conflict detected");
  r = await call("/api/save", "PUT", { data: { v: 1, save: { phase: "a3_city" } }, baseRev: 1 }, tA); ok(r.j.rev === 2, "save rev2");
  r = await call("/api/save", "PUT", { data: { big: "x".repeat(70000) }, baseRev: 2 }, tA); ok(r.s === 413, "oversized save rejected");
  // --- admin
  r = await call("/api/admin/users", "GET", null, null, { "x-admin-key": "wrong-wrong-wrong" }); ok(r.s === 403, "wrong admin key");
  r = await call("/api/admin/reset", "POST", { u: B }, null, { "x-admin-key": ADMIN }); ok(r.j && r.j.code && r.j.code.length === 8, "admin reset code");
  const code = r.j.code;
  r = await call("/api/reset", "POST", { u: B, code: "AAAAAAAA", p: "new-password-99" }); ok(r.s === 400, "bad reset code rejected");
  r = await call("/api/reset", "POST", { u: B, code: code.toLowerCase(), p: "new-password-99" }); ok(r.s === 200 && r.j.token, "reset with code (case-insensitive) clears lock");
  const tB2 = r.j.token;
  r = await call("/api/me", "GET", null, tB); ok(r.s === 401, "old sessions killed by reset");
  r = await call("/api/reset", "POST", { u: B, code, p: "another-pass-77" }); ok(r.s === 400, "reset code is single-use");
  r = await call("/api/admin/users", "GET", null, null, { "x-admin-key": ADMIN }); ok(Array.isArray(r.j) && r.j.some(x => x.u === A) && !JSON.stringify(r.j).includes("hash"), "admin list has no hashes");
  // --- rooms
  r = await call("/api/room", "POST", {}, tA); ok(r.j && /^[A-Z]{4}$/.test(r.j.code) && !/[AEIOUY]/.test(r.j.code), "room code " + JSON.stringify(r.j));
  const code4 = r.j.code;
  let bad = null; try { await sock(code4, "garbage-token-garbage-token"); } catch (e) { bad = e; } ok(!!bad, "ws with bad token refused");
  const a = await sock(code4, tA); let m = await a.wait(x => x.t === "room"); ok(m && m.host === A && m.roster.length === 1, "A joined as host");
  const b = await sock(code4, tB2); m = await b.wait(x => x.t === "room"); ok(m && m.roster.length === 2, "B joined");
  b.send({ t: "char", char: "rowan" }); m = await b.wait(x => x.t === "room" && x.roster.find(p => p.u === B).char === "rowan", 1500); ok(!m, "B can't steal A's character");
  b.send({ t: "char", char: "nadia" }); m = await b.wait(x => x.t === "room" && x.roster.find(p => p.u === B).char === "nadia"); ok(!!m, "B picks nadia");
  a.send({ t: "start" }); m = await a.wait(x => x.t === "sys"); ok(m && /ready/.test(m.msg), "start blocked until ready");
  b.send({ t: "ready", r: true }); await b.wait(x => x.t === "room" && x.roster.find(p => p.u === B).ready);
  b.send({ t: "start" }); m = await b.wait(x => x.t === "start", 800); ok(!m, "non-host can't start");
  a.send({ t: "start", map: "nettest" }); m = await b.wait(x => x.t === "start"); ok(m && m.map === "nettest", "game started");
  // positions + proximity say
  a.send({ t: "st", x: 100, y: 100, m: "nettest" }); m = await b.wait(x => x.t === "ps" && x.u === A); ok(m && m.x === 100, "state relayed");
  b.send({ t: "st", x: 130, y: 100, m: "nettest" }); await a.wait(x => x.t === "ps");
  a.send({ t: "say", ph: 3 }); m = await b.wait(x => x.t === "say"); ok(m && m.u === A && m.ph === 3, "say heard nearby, with name");
  b.send({ t: "st", x: 900, y: 100, m: "nettest" }); await a.wait(x => x.t === "ps");
  a.send({ t: "say", ph: 4 }); m = await b.wait(x => x.t === "say", 800); ok(!m, "say NOT heard far away");
  a.send({ t: "rad", ph: 2 }); m = await b.wait(x => x.t === "rad"); ok(m && !m.u && m.col && m.q <= 1, "radio has no name, has colour " + JSON.stringify(m));
  b.send({ t: "chan", ch: 3 }); await sleep(100); a.send({ t: "rad", ph: 5 }); m = await b.wait(x => x.t === "rad", 800); ok(!m, "other channel doesn't hear");
  b.send({ t: "chan", ch: 1 });
  // give needs proximity
  a.send({ t: "give", to: B, item: "water" }); m = await a.wait(x => x.t === "gave"); ok(m && !m.ok && m.far, "give refused when far");
  b.send({ t: "st", x: 120, y: 100, m: "nettest" }); await a.wait(x => x.t === "ps");
  a.send({ t: "give", to: B, item: "water" }); m = await b.wait(x => x.t === "gift"); ok(m && m.from === A && m.item === "water", "gift delivered");
  // pickups: first come
  a.send({ t: "pick", id: "p7" }); b.send({ t: "pick", id: "p7" });
  const ga = await a.wait(x => x.t === "got" && x.id === "p7"); const gb = await b.wait(x => x.t === "gone" && x.id === "p7");
  ok(ga && ga.by === A && gb, "pickup race: exactly one winner");
  // host-only messages
  b.send({ t: "ws", h: [[1, 2, 3]] }); m = await a.wait(x => x.t === "ws", 600); ok(!m, "non-host can't send world");
  a.send({ t: "ws", h: [[1, 2, 3]] }); m = await b.wait(x => x.t === "ws"); ok(!!m, "host world relayed");
  b.send({ t: "hh", id: 1, dmg: 10, fx: 1, fy: 0, kb: 60 }); m = await a.wait(x => x.t === "hh"); ok(m && m.by === B, "hit forwarded to host");
  // host migration
  a.ws.close(); m = await b.wait(x => x.t === "host"); ok(m && m.u === B, "host migrates to B");
  // rejoin gets resume
  const a2 = await sock(code4, tA); m = await a2.wait(x => x.t === "start"); ok(m && m.resume && m.taken.p7 === A, "rejoin resumes with pickup state");
  m = await b.wait(x => x.t === "need"); ok(m && m.u === A, "host asked to resync newcomer");
  // full room
  const extra = [];
  for (let i = 0; i < 3; i++) { const rr = await call("/api/register", "POST", { u: uniq + "x" + i, p: PW + i }); extra.push(rr.j.token); }
  const c3 = await sock(code4, extra[0]); const c4 = await sock(code4, extra[1]); await sleep(200);
  let full = null; try { await sock(code4, extra[2]); } catch (e) { full = e; } ok(!!full, "fifth player refused");
  // rate limiting: 200 messages at once, most dropped silently, socket survives
  for (let i = 0; i < 200; i++) b.send({ t: "ping", c: i });
  await sleep(600); const pongs = b.inbox.filter(x => x.t === "pong").length; ok(pongs >= 40 && pongs < 120, "rate limit (got " + pongs + " pongs of 200)");
  // usage meter
  r = await call("/api/admin/usage", "GET", null, null, { "x-admin-key": ADMIN }); ok(r.j && r.j.days && r.j.days.length >= 1, "usage meter " + JSON.stringify(r.j && r.j.days && r.j.days[0]));
  r = await call("/api/status"); ok(r.j && typeof r.j.used === "number", "status");
  // echo test endpoint
  const e = await new Promise(res => { const w = new WebSocket(BASE.replace("http", "ws") + "/ws/echo"); w.onopen = () => w.send("hi"); w.onmessage = ev => { res(ev.data); w.close(); }; w.onerror = () => res(null); });
  ok(e === "hi", "echo socket");
  [a2, b, c3, c4].forEach(s => s.ws.close());
  console.log(`\n${passes} passed, ${fails} failed`);
  process.exit(fails ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
